package com.grwtomb.extractor

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var parseJob: Job? = null
    private var lastAuto: String? = null
    private val logBuf = StringBuilder()

    private fun log(s: String) {
        synchronized(logBuf) {
            logBuf.appendLine(s)
            if (logBuf.length > 8000) logBuf.delete(0, logBuf.length - 8000)
        }
    }

    private fun dumpLog(): String = synchronized(logBuf) { logBuf.toString() }

    /** 界面上只显示简短提示；详细原因在日志里（可复制） */
    private fun errorText(e: Throwable): String = friendly(classify(e))

    private val busy get() = _state.value.phase == Phase.Downloading

    /** 手动输入/编辑：停止输入 0.7 秒后自动解析 */
    fun onInput(text: String) {
        _state.update { it.copy(input = text) }
        parseJob?.cancel()
        if (busy) return
        val url = extractUrl(text)
        if (url == null) {
            _state.update { it.copy(phase = Phase.Idle, meta = null, error = null) }
            return
        }
        parseJob = viewModelScope.launch {
            delay(700)
            parse(url)
        }
    }

    /** 点"粘贴"按钮 / 从其他 App 分享进来：立即解析 */
    fun onPaste(text: String) {
        if (busy) return
        val url = extractUrl(text)
        _state.update { it.copy(input = url ?: text) }
        parseJob?.cancel()
        if (url == null) return
        parseJob = viewModelScope.launch { parse(url) }
    }

    /** 回到前台时发现剪贴板里有新链接：自动填入并解析 */
    fun onClipboard(text: String) {
        if (busy) return
        val url = extractUrl(text) ?: return
        if (url == lastAuto || url == extractUrl(_state.value.input)) return
        lastAuto = url
        onPaste(url)
    }

    private suspend fun parse(url: String) {
        _state.update {
            it.copy(phase = Phase.Parsing, error = null, meta = null, saved = emptyList())
        }
        try {
            val meta = Engine.resolve(app, url, this::log)
            _state.update {
                it.copy(
                    phase = Phase.Ready, meta = meta, error = null,
                    quality = meta.heights.firstOrNull() ?: 0, video = true, cover = false, progress = 0f,
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            log("FAIL: ${e.message}")
            _state.update {
                it.copy(phase = Phase.Error, error = errorText(e), log = dumpLog())
            }
        }
    }

    fun setQuality(q: Int) = _state.update { it.copy(quality = q) }
    fun setVideo(on: Boolean) = _state.update { it.copy(video = on) }
    fun setCover(on: Boolean) = _state.update { it.copy(cover = on) }

    fun download() {
        val s = _state.value
        val meta = s.meta ?: return
        if (s.phase != Phase.Ready) return
        if (!(s.video || s.cover)) return

        _state.update { it.copy(phase = Phase.Downloading, progress = 0f, error = null) }
        DownloadService.start(app)
        viewModelScope.launch {
            var lastP = 0f
            try {
                val saved = Downloader.run(
                    app, meta,
                    Downloader.Options(s.quality, s.video, s.cover),
                    this@MainViewModel::log,
                ) { p ->
                    if (p - lastP >= 0.01f) {
                        lastP = p
                        _state.update { it.copy(progress = p) }
                        DownloadService.progress(app, p)
                    }
                }
                _state.update { it.copy(phase = Phase.Done, progress = 1f, saved = saved) }
                delay(2600)
                _state.update { if (it.phase == Phase.Done) it.copy(phase = Phase.Ready, progress = 0f) else it }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                log("DOWNLOAD FAIL: ${e.message}")
                _state.update {
                    it.copy(phase = Phase.Ready, progress = 0f, error = errorText(e), log = dumpLog())
                }
            } finally {
                DownloadService.stop(app)
            }
        }
    }
}
