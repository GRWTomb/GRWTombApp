package com.grwtomb.extractor

import android.content.Context
import org.json.JSONObject

/** 读取 <meta property|name="xxx" content="..."> */
internal fun metaContent(html: String, name: String): String? {
    val n = Regex.escape(name)
    val a = Regex("""<meta[^>]+(?:property|name)=["']$n["'][^>]*content=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    val b = Regex("""<meta[^>]+content=["']([^"']+)["'][^>]*(?:property|name)=["']$n["']""", RegexOption.IGNORE_CASE)
    return (a.find(html) ?: b.find(html))?.groupValues?.get(1)?.replace("&amp;", "&")
}

private fun unescapeJs(s: String) =
    s.replace("\\u0025", "%").replace("\\u0026", "&").replace("\\u002F", "/").replace("\\u003D", "=")
        .replace("\\/", "/").replace("&amp;", "&")

private fun shortSide(w: Int, h: Int): Int = if (w > 0 && h > 0) minOf(w, h) else 0

// ───────────────────────── YouTube ─────────────────────────
// 使用官方 App 同款的 innertube 接口（无需登录）。YouTube 对第三方限制较多，成功率取决于平台当前策略。

internal object YouTube {
    private class Client(val name: String, val num: String, val version: String, val ua: String, val json: String)

    private val CLIENTS = listOf(
        Client(
            "ANDROID_VR", "28", "1.60.19",
            "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
            """{"clientName":"ANDROID_VR","clientVersion":"1.60.19","deviceMake":"Oculus","deviceModel":"Quest 3","androidSdkVersion":32,"osName":"Android","osVersion":"12L","hl":"en","gl":"US"}""",
        ),
        Client(
            "IOS", "5", "19.45.4",
            "com.google.ios.youtube/19.45.4 (iPhone16,2; U; CPU iOS 18_1_0 like Mac OS X;)",
            """{"clientName":"IOS","clientVersion":"19.45.4","deviceMake":"Apple","deviceModel":"iPhone16,2","osName":"iPhone","osVersion":"18.1.0.22B83","hl":"en","gl":"US"}""",
        ),
        Client(
            "ANDROID", "3", "19.44.38",
            "com.google.android.youtube/19.44.38 (Linux; U; Android 11) gzip",
            """{"clientName":"ANDROID","clientVersion":"19.44.38","androidSdkVersion":30,"osName":"Android","osVersion":"11","hl":"en","gl":"US"}""",
        ),
    )

    fun resolve(url: String, log: (String) -> Unit): VideoMeta {
        val id = Regex("""(?:[?&]v=|youtu\.be/|/shorts/|/embed/|/live/)([A-Za-z0-9_-]{11})""").find(url)?.groupValues?.get(1)
            ?: throw ExtractError(Kind.UNSUPPORTED, "没有找到 YouTube 视频编号")
        var lastErr = ""
        for (c in CLIENTS) {
            val body = JSONObject()
                .put("context", JSONObject().put("client", JSONObject(c.json)))
                .put("videoId", id)
                .put("contentCheckOk", true)
                .put("racyCheckOk", true)
                .toString()
            val r = runCatching {
                Http.postJson(
                    "https://www.youtube.com/youtubei/v1/player?prettyPrint=false", body,
                    mapOf(
                        "User-Agent" to c.ua, "X-YouTube-Client-Name" to c.num, "X-YouTube-Client-Version" to c.version,
                        "Origin" to "https://www.youtube.com", "Accept-Language" to "en-US,en;q=0.9",
                    ),
                )
            }.getOrNull()
            if (r == null) { log("→ ${c.name}：请求失败"); continue }
            val j = runCatching { JSONObject(r.body) }.getOrNull()
            if (j == null) { log("→ ${c.name}：HTTP ${r.code}，返回的不是 JSON"); continue }
            val ps = j.optJSONObject("playabilityStatus")
            val status = ps?.optString("status").orEmpty()
            val reason = ps?.optString("reason").orEmpty()
            if (status != "OK") {
                log("→ ${c.name}：$status $reason")
                lastErr = reason.ifBlank { status }
                continue
            }
            val meta = build(url, id, j, c.ua)
            if (meta != null) {
                log("→ 使用 ${c.name} 客户端，画质：" + meta.heights.joinToString("/"))
                return meta
            }
            log("→ ${c.name}：没有可直接下载的格式（可能需要签名）")
        }
        val low = lastErr.lowercase()
        throw when {
            "sign in" in low || "bot" in low || "age" in low -> ExtractError(Kind.LOGIN, "YouTube 要求验证身份：$lastErr")
            "unavailable" in low || "private" in low || "removed" in low -> ExtractError(Kind.REMOVED, "YouTube：$lastErr")
            else -> ExtractError(Kind.BLOCKED, "YouTube 没有返回可下载的视频流：$lastErr")
        }
    }

    private fun build(url: String, id: String, j: JSONObject, ua: String): VideoMeta? {
        val sd = j.optJSONObject("streamingData") ?: return null
        fun fmts(key: String): List<JSONObject> {
            val a = sd.optJSONArray(key) ?: return emptyList()
            return (0 until a.length()).mapNotNull { a.optJSONObject(it) }
        }
        fun direct(f: JSONObject) = f.optString("url").takeIf { it.startsWith("http") }

        val adaptive = fmts("adaptiveFormats")
        val muxed = fmts("formats")
        val audio = adaptive.filter { it.optString("mimeType").startsWith("audio/mp4") && direct(it) != null }
            .maxByOrNull { it.optLong("bitrate") }
        val audioUrls = audio?.let { listOf(direct(it)!!) }

        val streams = ArrayList<Stream>()
        if (audioUrls != null) {
            val byH = LinkedHashMap<Int, JSONObject>()
            for (f in adaptive) {
                val mt = f.optString("mimeType")
                // 只取 H.264：系统自带的合并工具能处理，手机也都能播放
                if (!mt.startsWith("video/mp4") || !mt.contains("avc1") || direct(f) == null) continue
                val h = f.optInt("height")
                if (h <= 0) continue
                val cur = byH[h]
                if (cur == null || f.optLong("bitrate") > cur.optLong("bitrate")) byH[h] = f
            }
            for ((h, f) in byH) streams.add(Stream(h, listOf(direct(f)!!), audioUrls))
        }
        // 带声音的完整格式：补充与兜底
        var fallback: String? = null
        var fbH = 0
        for (f in muxed) {
            val u = direct(f) ?: continue
            val h = f.optInt("height")
            if (f.optString("mimeType").startsWith("video/mp4") && h > fbH) { fbH = h; fallback = u }
        }
        if (fallback != null && streams.none { it.height == fbH }) streams.add(Stream(fbH, listOf(fallback), null))
        if (streams.isEmpty()) return null

        val vd = j.optJSONObject("videoDetails")
        val thumbs = vd?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
        val thumb = thumbs?.optJSONObject(thumbs.length() - 1)?.optString("url")?.takeIf { it.startsWith("http") }
            ?: "https://i.ytimg.com/vi/$id/hqdefault.jpg"
        return VideoMeta(
            url = url, title = vd?.optString("title").orEmpty().ifBlank { "YouTube $id" }, thumbnail = thumb,
            durationSec = vd?.optString("lengthSeconds")?.toLongOrNull() ?: 0,
            heights = streams.map { it.height }.filter { it > 0 }.distinct().sortedDescending(),
            subLangs = emptyList(), streams = streams, fallbackMp4 = fallback,
            headers = mapOf("User-Agent" to ua),
        )
    }
}

// ───────────────────────── X（Twitter） ─────────────────────────
// 使用推文嵌入组件所用的公开接口，无需登录。仅公开推文可用。

internal object Twitter {
    private fun tokenOf(id: String): String {
        val d = (id.toDouble() / 1e15) * Math.PI
        val ip = d.toLong()
        val sb = StringBuilder(java.lang.Long.toString(ip, 36))
        var f = d - ip
        repeat(11) {
            f *= 36
            val dg = f.toInt()
            sb.append(Character.forDigit(dg, 36))
            f -= dg
        }
        return sb.toString().replace("0", "").replace(".", "")
    }

    fun resolve(url: String, log: (String) -> Unit): VideoMeta {
        var target = url
        if (hostOf(url) == "t.co") target = Http.get(null, url, mapOf("User-Agent" to Http.UA_MOBILE)).finalUrl
        val id = Regex("""status(?:es)?/(\d{5,})""").find(target)?.groupValues?.get(1)
            ?: throw ExtractError(Kind.UNSUPPORTED, "没有找到推文编号")

        var j: JSONObject? = null
        for (t in listOf(tokenOf(id), "a").distinct()) {
            val r = runCatching {
                Http.get(
                    null, "https://cdn.syndication.twimg.com/tweet-result?id=$id&lang=en&token=$t",
                    mapOf("User-Agent" to Http.UA_PC, "Referer" to "https://platform.twitter.com/"),
                )
            }.getOrNull()
            log("→ 推文接口 HTTP ${r?.code}，${r?.body?.length ?: 0} 字节")
            val jo = r?.body?.let { runCatching { JSONObject(it) }.getOrNull() }
            if (jo != null && jo.length() > 1) { j = jo; break }
        }
        val tweet = j ?: throw ExtractError(Kind.BLOCKED, "没有取到推文数据（推文不存在或不是公开的）")

        val media = tweet.optJSONArray("mediaDetails")
        var m: JSONObject? = null
        if (media != null) for (i in 0 until media.length()) {
            val o = media.optJSONObject(i) ?: continue
            if (o.optString("type") == "video" || o.optString("type") == "animated_gif") { m = o; break }
        }
        if (m == null) {
            val q = tweet.optJSONObject("quoted_tweet")?.optJSONArray("mediaDetails")
            if (q != null) for (i in 0 until q.length()) {
                val o = q.optJSONObject(i) ?: continue
                if (o.optString("type") == "video" || o.optString("type") == "animated_gif") { m = o; break }
            }
        }
        val vm = m ?: throw ExtractError(Kind.UNSUPPORTED, "这条推文里没有视频")
        val info = vm.optJSONObject("video_info")
        val variants = info?.optJSONArray("variants")
        val byH = LinkedHashMap<Int, Pair<Long, String>>()
        if (variants != null) for (i in 0 until variants.length()) {
            val v = variants.optJSONObject(i) ?: continue
            if (v.optString("content_type") != "video/mp4") continue
            val u = v.optString("url").takeIf { it.startsWith("http") } ?: continue
            val dim = Regex("""/(\d{2,4})x(\d{2,4})/""").find(u)
            val h = if (dim != null) shortSide(dim.groupValues[1].toInt(), dim.groupValues[2].toInt()) else 0
            val br = v.optLong("bitrate")
            val cur = byH[h]
            if (cur == null || br > cur.first) byH[h] = br to u
        }
        if (byH.isEmpty()) throw ExtractError(Kind.OTHER, "推文里没有可下载的 mp4 地址")
        val streams = byH.map { (h, p) -> Stream(h, listOf(p.second)) }
        val text = tweet.optString("text").replace(Regex("""https?://t\.co/\w+"""), "").trim()
        val user = tweet.optJSONObject("user")?.optString("name").orEmpty()
        log("→ X 解析成功：" + streams.map { it.height }.sortedDescending().joinToString("/"))
        return VideoMeta(
            url = target, title = text.ifBlank { "X 视频 $user".trim() }, thumbnail = vm.optString("media_url_https").takeIf { it.startsWith("http") },
            durationSec = (info?.optLong("duration_millis") ?: 0L) / 1000, heights = streams.map { it.height }.filter { it > 0 }.distinct().sortedDescending(),
            subLangs = emptyList(), streams = streams, headers = mapOf("User-Agent" to Http.UA_PC),
        )
    }
}

// ───────────────────────── TikTok ─────────────────────────

internal object TikTok {
    fun resolve(url: String, log: (String) -> Unit): VideoMeta {
        val s = HttpSession()
        val pc = mapOf("User-Agent" to Http.UA_PC, "Referer" to "https://www.tiktok.com/")
        fun idOf(u: String) = Regex("""/video/(\d{10,})""").find(u)?.groupValues?.get(1)
        if (url.contains("/photo/")) throw ExtractError(Kind.UNSUPPORTED, "这是图文作品，暂不支持")
        var id = idOf(url)
        if (id == null) {
            val r = Http.get(s, url, pc)
            log("→ 短链已展开：${hostOf(url)} → ${hostOf(r.finalUrl)}")
            if (r.finalUrl.contains("/photo/")) throw ExtractError(Kind.UNSUPPORTED, "这是图文作品，暂不支持")
            id = idOf(r.finalUrl)
        }
        if (id == null) throw ExtractError(Kind.UNSUPPORTED, "没有找到 TikTok 视频编号")

        val r = Http.get(s, "https://www.tiktok.com/@_/video/$id", pc)
        log("→ TikTok 页面 HTTP ${r.code}，${r.body.length} 字节，Cookie ${s.cookies.size} 条")
        val json = jsonAfter(r.body, "__UNIVERSAL_DATA_FOR_REHYDRATION__")
            ?: throw ExtractError(Kind.BLOCKED, "TikTok 没有返回视频数据（可能需要验证，或所在地区受限）")
        val root = runCatching { JSONObject(json) }.getOrNull()
            ?: throw ExtractError(Kind.OTHER, "TikTok 页面数据解析失败")
        val item = findObj(root) {
            val v = it.optJSONObject("video")
            it.has("desc") && v != null && (v.has("playAddr") || v.has("bitrateInfo") || v.has("downloadAddr"))
        } ?: throw ExtractError(Kind.BLOCKED, "TikTok 数据里没有视频（可能已删除、私密或受限）")

        val v = item.getJSONObject("video")
        val byH = LinkedHashMap<Int, Pair<Boolean, List<String>>>() // 高度 → (是否 H.264, 地址)
        val br = v.optJSONArray("bitrateInfo")
        if (br != null) for (i in 0 until br.length()) {
            val b = br.optJSONObject(i) ?: continue
            val pa = b.optJSONObject("PlayAddr") ?: continue
            val urls = pa.optJSONArray("UrlList").strings()
            if (urls.isEmpty()) continue
            val h = shortSide(pa.optInt("Width"), pa.optInt("Height"))
            val h264 = b.optString("CodecType").contains("h264", ignoreCase = true)
            val cur = byH[h]
            if (cur == null || (!cur.first && h264)) byH[h] = h264 to urls
        }
        if (byH.isEmpty()) {
            val urls = listOf(v.optString("playAddr"), v.optString("downloadAddr")).filter { it.startsWith("http") }
            if (urls.isEmpty()) throw ExtractError(Kind.OTHER, "TikTok 数据里没有播放地址")
            byH[shortSide(v.optInt("width"), v.optInt("height"))] = true to urls
        }
        val streams = byH.map { (h, p) -> Stream(h, p.second) }
        log("→ TikTok 解析成功：" + streams.map { it.height }.sortedDescending().joinToString("/"))
        val cookie = s.header()
        return VideoMeta(
            url = "https://www.tiktok.com/@_/video/$id", title = item.optString("desc").ifBlank { "TikTok 视频" },
            thumbnail = listOf("cover", "originCover", "dynamicCover").map { v.optString(it) }.firstOrNull { it.startsWith("http") },
            durationSec = v.optLong("duration"), heights = streams.map { it.height }.filter { it > 0 }.distinct().sortedDescending(),
            subLangs = emptyList(), streams = streams,
            headers = buildMap {
                put("User-Agent", Http.UA_PC)
                put("Referer", "https://www.tiktok.com/")
                if (cookie != null) put("Cookie", cookie)
            },
        )
    }
}

// ───────────────────────── Facebook ─────────────────────────
// 只支持公开视频（读取网页里的播放地址）；需要登录的视频无法获取。

internal object Facebook {
    private fun pick(t: String, vararg keys: String): String? {
        for (k in keys) {
            Regex(""""$k"\s*:\s*"(https:[^"]+)"""").find(t)?.groupValues?.get(1)?.let { return it }
        }
        return null
    }

    fun resolve(url: String, log: (String) -> Unit): VideoMeta {
        val s = HttpSession()
        val r = Http.get(
            s, url,
            mapOf(
                "User-Agent" to Http.UA_PC, "Accept" to "text/html,application/xhtml+xml",
                "Accept-Language" to "en-US,en;q=0.9", "Sec-Fetch-Mode" to "navigate", "Sec-Fetch-Dest" to "document",
            ),
        )
        log("→ Facebook 页面 HTTP ${r.code}，${hostOf(url)} → ${hostOf(r.finalUrl)}，${r.body.length} 字节")
        val t = unescapeJs(r.body)
        val hd = pick(t, "browser_native_hd_url", "playable_url_quality_hd", "hd_src_no_ratelimit", "hd_src")
        val sd = pick(t, "browser_native_sd_url", "playable_url", "sd_src_no_ratelimit", "sd_src")
            ?: Regex(""""progressive_url"\s*:\s*"(https:[^"]+)"""").find(t)?.groupValues?.get(1)
        if (hd == null && sd == null) {
            val needLogin = r.finalUrl.contains("login", ignoreCase = true) || t.contains("You must log in", ignoreCase = true)
            throw ExtractError(
                if (needLogin) Kind.LOGIN else Kind.BLOCKED,
                if (needLogin) "Facebook 要求登录后才能查看" else "Facebook 页面里没有找到视频地址（可能不是公开视频）",
            )
        }
        val streams = ArrayList<Stream>()
        if (hd != null) streams.add(Stream(720, listOf(hd)))
        if (sd != null && sd != hd) streams.add(Stream(360, listOf(sd)))
        log("→ Facebook 解析成功：" + streams.joinToString("/") { "${it.height}p" })
        val title = (metaContent(r.body, "og:title") ?: titleTag(r.body)).ifBlank { "Facebook 视频" }
        return VideoMeta(
            url = r.finalUrl, title = title, thumbnail = metaContent(r.body, "og:image")?.takeIf { it.startsWith("http") },
            durationSec = 0, heights = streams.map { it.height }, subLangs = emptyList(), streams = streams,
            headers = mapOf("User-Agent" to Http.UA_PC, "Referer" to "https://www.facebook.com/"),
        )
    }
}

// ───────────────────────── 小红书 ─────────────────────────

internal object Xhs {
    private fun fix(u: String) = if (u.startsWith("//")) "https:$u" else u

    private fun noteFrom(html: String): JSONObject? {
        val raw = jsonAfter(html, "__INITIAL_STATE__") ?: return null
        // 页面里的 JSON 含有 undefined，需要先替换成 null
        val root = runCatching { JSONObject(raw.replace("undefined", "null")) }.getOrNull() ?: return null
        return findObj(root) {
            it.optJSONObject("video")?.has("media") == true && (it.has("title") || it.has("desc"))
        }
    }

    private fun fromNote(page: String, note: JSONObject, log: (String) -> Unit): VideoMeta {
        val video = note.getJSONObject("video")
        val stream = video.optJSONObject("media")?.optJSONObject("stream")
        val byH = LinkedHashMap<Int, List<String>>()
        for (codec in listOf("h264", "h265", "av1")) {
            val arr = stream?.optJSONArray(codec) ?: continue
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val urls = (listOf(o.optString("masterUrl")) + (o.optJSONArray("backupUrls")?.let { a ->
                    (0 until a.length()).map { a.optString(it) }
                } ?: emptyList())).filter { it.isNotBlank() }.map { fix(it) }.filter { it.startsWith("http") }
                if (urls.isEmpty()) continue
                val h = shortSide(o.optInt("width"), o.optInt("height"))
                if (!byH.containsKey(h)) byH[h] = urls
            }
        }
        if (byH.isEmpty()) throw ExtractError(Kind.OTHER, "小红书数据里没有视频地址")
        val streams = byH.map { (h, u) -> Stream(h, u) }
        val cover = note.optJSONArray("imageList")?.optJSONObject(0)?.optString("urlDefault")?.let { fix(it) }
            ?.takeIf { it.startsWith("http") }
        log("→ 小红书解析成功：" + streams.map { it.height }.sortedDescending().joinToString("/"))
        return VideoMeta(
            url = page, title = note.optString("title").ifBlank { note.optString("desc") }.ifBlank { "小红书视频" }.take(80),
            thumbnail = cover, durationSec = video.optJSONObject("capa")?.optLong("duration") ?: 0,
            heights = streams.map { it.height }.filter { it > 0 }.distinct().sortedDescending(),
            subLangs = emptyList(), streams = streams,
            headers = mapOf("User-Agent" to Http.UA_MOBILE, "Referer" to "https://www.xiaohongshu.com/"),
        )
    }

    suspend fun resolve(ctx: Context, url: String, log: (String) -> Unit): VideoMeta {
        val s = HttpSession()
        val r = Http.get(s, url, mapOf("User-Agent" to Http.UA_MOBILE, "Accept-Language" to "zh-CN,zh;q=0.9"))
        log("→ 小红书页面 HTTP ${r.code}，${hostOf(url)} → ${hostOf(r.finalUrl)}，${r.body.length} 字节，标题「${titleTag(r.body).take(24)}」")
        noteFrom(r.body)?.let { return fromNote(r.finalUrl, it, log) }
        if (r.body.contains("imageList") && !r.body.contains("masterUrl")) {
            throw ExtractError(Kind.UNSUPPORTED, "这是图文笔记，暂不支持")
        }

        log("→ 页面里没有视频数据，改用 WebView 打开")
        val js = "(function(){var v=document.querySelector('video');var s=v&&(v.currentSrc||v.src);" +
            "if(s&&s.indexOf('http')==0)return {videoSrc:s,title:document.title,poster:v.poster};return null})()"
        val got = WebData.evalJson(ctx, r.finalUrl, Http.UA_MOBILE, js, 25_000L)
        log("→ WebView 结果：${got?.take(100) ?: "空（超时，或需要登录/验证）"}")
        val o = got?.let { runCatching { JSONObject(it) }.getOrNull() }
        val src = o?.optString("videoSrc").orEmpty()
        if (src.startsWith("http")) {
            return VideoMeta(
                url = r.finalUrl, title = o?.optString("title").orEmpty().removeSuffix(" - 小红书").ifBlank { "小红书视频" },
                thumbnail = o?.optString("poster")?.takeIf { it.startsWith("http") }, durationSec = 0,
                heights = emptyList(), subLangs = emptyList(), streams = listOf(Stream(0, listOf(src))),
                headers = mapOf("User-Agent" to Http.UA_MOBILE, "Referer" to "https://www.xiaohongshu.com/"),
            )
        }
        throw ExtractError(Kind.BLOCKED, "小红书没有返回视频数据（可能需要登录，或是图文笔记）")
    }
}
