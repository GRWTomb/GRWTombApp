package com.grwtomb.extractor

import java.net.URI

private val URL_RE = Regex("""https?://[^\s<>"'，。！？）】]+""")

/** 从任意文本（比如各平台的"分享口令"）里抽出第一个链接 */
fun extractUrl(s: String): String? =
    URL_RE.find(s)?.value
        ?.trimEnd('.', ',', ';', ':', '!', '?', ')', '）')
        ?.takeIf { it.length > 10 && it.substringAfter("://").contains('.') }

/** 将抖音旧分享页转换为标准视频页；短链由 CookieBridge 的 WebView 跟随跳转。 */
fun normalizeVideoUrl(url: String): String {
    return try {
        val uri = URI(url.trim())
        val host = uri.host?.lowercase()?.removePrefix("www.") ?: return url
        if (host == "m.bilibili.com" || host == "bilibili.com") {
            // b23.tv 短链会被手机 WebView 展开成 m.bilibili.com；yt-dlp 只认 www.bilibili.com，
            // 否则会退回通用网页解析器（只有标题和封面，没有视频流）。
            val path = uri.path ?: return url
            val p = Regex("""(?:^|[?&])p=(\d+)""").find(uri.rawQuery ?: "")?.groupValues?.get(1)
            val suffix = if (p != null && p != "1") "?p=$p" else ""
            return when {
                Regex("""^/video/[aAbB][vV]\w+/?$""").matches(path) ->
                    "https://www.bilibili.com" + path.trimEnd('/') + suffix
                path.startsWith("/bangumi/play/") -> "https://www.bilibili.com$path"
                else -> url
            }
        }
        if (host == "iesdouyin.com" || host == "douyin.com") {
            val match = Regex("""^/share/video/(\d+)(?:/)?$""").matchEntire(uri.path ?: "")
            val id = match?.groupValues?.get(1) ?: return url
            "https://www.douyin.com/video/$id"
        } else {
            url
        }
    } catch (_: Throwable) {
        url
    }
}

fun hostOf(url: String): String =
    runCatching { URI(url).host?.lowercase()?.removePrefix("www.") }.getOrNull().orEmpty()

fun safeName(title: String): String =
    title.replace(Regex("""[\\/:*?"<>|\u0000-\u001f]"""), "_").take(80).trim().ifBlank { "video" }

fun formatDuration(sec: Long): String {
    if (sec <= 0) return ""
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun qualityLabel(h: Int): String = when {
    h >= 4320 -> "8K"
    h >= 2160 -> "4K"
    h >= 1440 -> "2K"
    else -> "${h}p"
}

/** 把异常归类，用来决定提示语 */
fun classify(t: Throwable): Kind {
    if (t is ExtractError) return t.kind
    if (t is java.net.UnknownHostException || t is java.net.SocketTimeoutException ||
        t is java.net.ConnectException || t is javax.net.ssl.SSLException
    ) return Kind.NETWORK
    return Kind.OTHER
}

fun friendly(kind: Kind): String = when (kind) {
    Kind.NETWORK -> "网络不稳定，请稍后再试"
    Kind.LOGIN -> "需要登录，暂时无法提取"
    Kind.UNSUPPORTED -> "暂不支持这个链接"
    Kind.REMOVED -> "视频不可用或已被删除"
    Kind.ENGINE -> "初始化失败，请重启应用"
    Kind.BLOCKED, Kind.OTHER -> "提取失败，请稍后再试"
}
