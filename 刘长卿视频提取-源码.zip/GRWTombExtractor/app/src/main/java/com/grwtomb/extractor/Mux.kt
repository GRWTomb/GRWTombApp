package com.grwtomb.extractor

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer

/** 用系统自带的 MediaExtractor / MediaMuxer 合并音视频轨，不需要 ffmpeg */
object Mux {
    /**
     * @param inputs 每项：文件 + 要取的轨道类型前缀（"video/" 或 "audio/"）
     * 按时间戳交错写入，输出 mp4（只有音频时即 m4a）
     */
    fun mux(inputs: List<Pair<File, String>>, out: File) {
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val extractors = ArrayList<MediaExtractor>()
        var started = false
        try {
            val outTracks = ArrayList<Int>()
            for ((file, prefix) in inputs) {
                val ex = MediaExtractor()
                extractors.add(ex)
                ex.setDataSource(file.absolutePath)
                var track = -1
                for (i in 0 until ex.trackCount) {
                    val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME).orEmpty()
                    if (mime.startsWith(prefix)) { track = i; break }
                }
                if (track < 0) throw IllegalStateException("找不到 $prefix 轨道")
                ex.selectTrack(track)
                outTracks.add(muxer.addTrack(ex.getTrackFormat(track)))
            }
            muxer.start()
            started = true

            val buf = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            val active = BooleanArray(extractors.size) { true }
            while (true) {
                // 选当前时间戳最小的轨道写入，保证音视频交错
                var pick = -1
                var best = Long.MAX_VALUE
                for (i in extractors.indices) {
                    if (!active[i]) continue
                    val t = extractors[i].sampleTime
                    if (t < 0) { active[i] = false; continue }
                    if (t < best) { best = t; pick = i }
                }
                if (pick < 0) break
                val ex = extractors[pick]
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) { active[pick] = false; continue }
                info.set(0, n, ex.sampleTime, ex.sampleFlags)
                muxer.writeSampleData(outTracks[pick], buf, info)
                ex.advance()
            }
        } finally {
            extractors.forEach { runCatching { it.release() } }
            if (started) runCatching { muxer.stop() }
            runCatching { muxer.release() }
        }
    }
}
