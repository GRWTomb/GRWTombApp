package com.grwtomb.extractor.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.grwtomb.extractor.MainViewModel
import com.grwtomb.extractor.Phase
import com.grwtomb.extractor.UiState
import com.grwtomb.extractor.VideoMeta
import com.grwtomb.extractor.formatDuration
import com.grwtomb.extractor.qualityLabel
import kotlinx.coroutines.delay

private val SUPPORTED = listOf("哔哩哔哩", "抖音", "快手", "YouTube", "TikTok", "X", "Facebook", "小红书")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainScreen(vm: MainViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()
    val cs = MaterialTheme.colorScheme

    Surface(color = cs.background, modifier = Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
        ) {
            Spacer(Modifier.height(44.dp))
            FadeIn {
                Text(
                    "刘长卿",
                    color = cs.onBackground,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 6.sp,
                )
            }
            Spacer(Modifier.height(28.dp))

            InputBar(s.input, onChange = vm::onInput, onPaste = vm::onPaste)
            Spacer(Modifier.height(18.dp))

            // 支持的平台：空闲或失败时显示，有结果后淡出
            AnimatedVisibility(
                visible = s.phase == Phase.Idle || s.phase == Phase.Error,
                enter = fadeIn(tween(400)),
                exit = fadeOut(tween(150)) + shrinkVertically(tween(200)),
            ) {
                Column {
                    Text("支持平台", color = cs.onSurfaceVariant, fontSize = 12.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        SUPPORTED.forEachIndexed { i, name -> PlatformTag(name, i) }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }

            // 解析中
            AnimatedVisibility(
                visible = s.phase == Phase.Parsing,
                enter = fadeIn(tween(250)),
                exit = fadeOut(tween(150)) + shrinkVertically(tween(200)),
            ) {
                Parsing()
            }

            // 解析失败
            AnimatedVisibility(
                visible = s.phase == Phase.Error,
                enter = fadeIn(tween(300)) + slideInVertically(tween(300, easing = FastOutSlowInEasing)) { it / 6 },
                exit = fadeOut(tween(150)),
            ) {
                ErrorNote(s.error.orEmpty(), s.log)
            }

            // 结果卡片
            AnimatedVisibility(
                visible = s.meta != null &&
                    (s.phase == Phase.Ready || s.phase == Phase.Downloading || s.phase == Phase.Done),
                enter = fadeIn(tween(350)) + slideInVertically(tween(400, easing = FastOutSlowInEasing)) { it / 10 },
                exit = fadeOut(tween(150)),
            ) {
                s.meta?.let { ResultCard(it, s, vm) }
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

/** 进入时淡入并轻微上移 */
@Composable
private fun FadeIn(content: @Composable () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(600, easing = FastOutSlowInEasing)) }
    Box(Modifier.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 16f }) { content() }
}

@Composable
private fun InputBar(value: String, onChange: (String) -> Unit, onPaste: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val clipboard = LocalClipboardManager.current
    var focused by remember { mutableStateOf(false) }
    val border by animateColorAsState(if (focused) cs.primary else cs.outlineVariant, tween(250), label = "inputBorder")
    val shape = RoundedCornerShape(16.dp)

    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(cs.surface)
            .border(1.dp, border, shape)
            .padding(start = 18.dp, end = 6.dp)
            .height(54.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = cs.onSurface, fontSize = 15.sp),
            cursorBrush = SolidColor(cs.primary),
            modifier = Modifier
                .weight(1f)
                .onFocusChanged { focused = it.isFocused },
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text("粘贴视频链接", color = cs.onSurfaceVariant, fontSize = 15.sp)
                    inner()
                }
            },
        )
        Text(
            if (value.isEmpty()) "粘贴" else "清除",
            color = cs.primary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable {
                    if (value.isEmpty()) clipboard.getText()?.text?.let(onPaste) else onChange("")
                }
                .padding(horizontal = 14.dp, vertical = 12.dp),
        )
    }
}

@Composable
private fun PlatformTag(text: String, index: Int) {
    val cs = MaterialTheme.colorScheme
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index * 50L)
        a.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
    }
    Text(
        text,
        color = cs.onSurfaceVariant,
        fontSize = 13.sp,
        modifier = Modifier
            .graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 10f }
            .clip(RoundedCornerShape(50))
            .border(1.dp, cs.outlineVariant, RoundedCornerShape(50))
            .padding(horizontal = 13.dp, vertical = 6.dp),
    )
}

@Composable
private fun Parsing() {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "parsing")
    val pulse by t.animateFloat(
        initialValue = 0.45f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    Column {
        LinearProgressIndicator(
            modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(50)),
            color = cs.primary,
            trackColor = cs.outlineVariant,
        )
        Spacer(Modifier.height(12.dp))
        Text("正在解析", color = cs.onSurfaceVariant, fontSize = 13.sp, modifier = Modifier.graphicsLayer { alpha = pulse })
    }
}

@Composable
private fun ErrorNote(message: String, log: String) {
    val cs = MaterialTheme.colorScheme
    val clipboard = LocalClipboardManager.current
    Column(Modifier.padding(top = 4.dp)) {
        Text(message, color = cs.error, fontSize = 14.sp)
        if (log.isNotBlank()) {
            Text(
                "复制日志",
                color = cs.onSurfaceVariant,
                fontSize = 12.sp,
                modifier = Modifier
                    .padding(top = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { clipboard.setText(AnnotatedString(log)) }
                    .padding(vertical = 6.dp, horizontal = 2.dp),
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ResultCard(meta: VideoMeta, s: UiState, vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val locked = s.phase != Phase.Ready
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .animateContentSize(tween(300, easing = FastOutSlowInEasing))
            .clip(shape)
            .background(cs.surface)
            .border(1.dp, cs.outlineVariant, shape)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        if (meta.thumbnail != null) {
            Box(Modifier.clip(RoundedCornerShape(14.dp))) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current).data(meta.thumbnail).crossfade(400).build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .background(cs.surfaceVariant),
                )
                val d = formatDuration(meta.durationSec)
                if (d.isNotEmpty()) {
                    Text(
                        d,
                        color = Color.White,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(alpha = 0.55f))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                }
            }
        }
        Text(
            meta.title,
            maxLines = 2,
            color = cs.onSurface,
            fontSize = 16.sp,
            lineHeight = 22.sp,
            fontWeight = FontWeight.Medium,
        )

        // 提取内容
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // 视频和封面至少保留一个
            Pill("视频", s.video, !locked) { if (s.cover || !s.video) vm.setVideo(!s.video) }
            Pill("封面", s.cover, !locked) { if (s.video || !s.cover) vm.setCover(!s.cover) }
        }

        // 画质：只列出真实可选的档位，默认选最高
        AnimatedVisibility(visible = s.video && meta.heights.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("画质", color = cs.onSurfaceVariant, fontSize = 12.sp, letterSpacing = 1.sp)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    meta.heights.forEach { h ->
                        Pill(qualityLabel(h), s.quality == h, !locked) { vm.setQuality(h) }
                    }
                }
            }
        }

        if (s.phase == Phase.Ready && s.error != null) {
            ErrorNote(s.error, s.log)
        }

        DownloadButton(
            phase = s.phase,
            progress = s.progress,
            canStart = s.video || s.cover,
            onClick = vm::download,
        )
    }
}

/** 胶囊选项：选中时底色、文字、描边一起渐变，按下时轻微缩小 */
@Composable
private fun Pill(text: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val bg by animateColorAsState(if (selected) cs.secondaryContainer else Color.Transparent, tween(220), label = "pillBg")
    val fg by animateColorAsState(if (selected) cs.onSecondaryContainer else cs.onSurfaceVariant, tween(220), label = "pillFg")
    val br by animateColorAsState(if (selected) cs.primary.copy(alpha = 0.55f) else cs.outlineVariant, tween(220), label = "pillBr")
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(stiffness = 500f), label = "pillScale")
    val shape = RoundedCornerShape(50)
    Text(
        text,
        color = fg,
        fontSize = 14.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier
            .scale(scale)
            .clip(shape)
            .background(bg)
            .border(1.dp, br, shape)
            .clickable(interactionSource = interaction, indication = null, enabled = enabled) { onClick() }
            .padding(horizontal = 18.dp, vertical = 9.dp),
    )
}

@Composable
private fun DownloadButton(phase: Phase, progress: Float, canStart: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(300), label = "progress")
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val active = phase == Phase.Ready && canStart
    val container by animateColorAsState(
        when {
            phase == Phase.Done -> DoneColor
            phase == Phase.Downloading -> cs.secondaryContainer
            !canStart -> cs.outlineVariant
            else -> cs.primary
        },
        tween(350), label = "btnColor",
    )
    val scale by animateFloatAsState(if (pressed && active) 0.98f else 1f, spring(stiffness = 500f), label = "btnScale")
    val shape = RoundedCornerShape(15.dp)

    Box(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .scale(scale)
            .clip(shape)
            .background(container)
            .clickable(interactionSource = interaction, indication = null, enabled = active) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        if (phase == Phase.Downloading) {
            Box(
                Modifier
                    .align(Alignment.CenterStart)
                    .fillMaxHeight()
                    .fillMaxWidth(p)
                    .background(cs.primary.copy(alpha = 0.30f)),
            )
        }
        AnimatedContent(
            targetState = phase,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(150)) },
            label = "btnText",
        ) { ph ->
            Text(
                when (ph) {
                    Phase.Downloading -> "${(progress * 100).toInt()}%"
                    Phase.Done -> "已保存"
                    else -> "下载"
                },
                color = when {
                    ph == Phase.Done -> Color.White
                    ph == Phase.Downloading -> cs.onSecondaryContainer
                    canStart -> cs.onPrimary
                    else -> cs.onSurfaceVariant
                },
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}
