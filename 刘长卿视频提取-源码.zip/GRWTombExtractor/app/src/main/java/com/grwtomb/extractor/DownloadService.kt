package com.grwtomb.extractor

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** 只负责"保活 + 通知栏进度"：下载进行时切到后台也不会被系统杀掉 */
class DownloadService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureChannel(this)
        ServiceCompat.startForeground(
            this, ID, build(this, 0f), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
        )
        return START_NOT_STICKY
    }

    companion object {
        private const val ID = 1001
        private const val CH = "download"
        private var lastPct = -1

        fun start(ctx: Context) {
            lastPct = -1
            ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, DownloadService::class.java))
        }

        @SuppressLint("MissingPermission")
        fun progress(ctx: Context, p: Float) {
            val pct = (p * 100).toInt()
            if (pct == lastPct) return
            lastPct = pct
            try {
                NotificationManagerCompat.from(ctx).notify(ID, build(ctx, p))
            } catch (e: SecurityException) {
                // 用户没授予通知权限：忽略，下载照常进行
            }
        }

        private fun ensureChannel(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH, "下载进度", NotificationManager.IMPORTANCE_LOW),
            )
        }

        private fun build(ctx: Context, p: Float): Notification {
            val pct = (p * 100).toInt()
            return NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("刘长卿 正在提取")
                .setContentText("$pct%")
                .setProgress(100, pct, false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build()
        }
    }
}
