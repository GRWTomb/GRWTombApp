package com.grwtomb.extractor.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// 冷色调：雾蓝灰背景 + 一个柔和的蓝作为主色，完成态用青绿
private val Light = lightColorScheme(
    primary = Color(0xFF3A7BD5),
    onPrimary = Color.White,
    background = Color(0xFFF5F8FB),
    onBackground = Color(0xFF0F1B2D),
    surface = Color.White,
    onSurface = Color(0xFF0F1B2D),
    surfaceVariant = Color(0xFFEEF3F8),
    onSurfaceVariant = Color(0xFF64748B),
    secondaryContainer = Color(0xFFE6F0FB),
    onSecondaryContainer = Color(0xFF1F5FAD),
    outline = Color(0xFFCBD5E1),
    outlineVariant = Color(0xFFE2E8F0),
    error = Color(0xFFD64545),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF6EA8F0),
    onPrimary = Color(0xFF0A1522),
    background = Color(0xFF0A1017),
    onBackground = Color(0xFFE6EDF5),
    surface = Color(0xFF111A24),
    onSurface = Color(0xFFE6EDF5),
    surfaceVariant = Color(0xFF16212D),
    onSurfaceVariant = Color(0xFF8FA1B5),
    secondaryContainer = Color(0xFF17263A),
    onSecondaryContainer = Color(0xFFA9CBF7),
    outline = Color(0xFF2A3A4D),
    outlineVariant = Color(0xFF1C2835),
    error = Color(0xFFF08A8A),
)

/** 下载完成时的青绿色 */
val DoneColor = Color(0xFF2BAE9A)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        content = content,
    )
}
