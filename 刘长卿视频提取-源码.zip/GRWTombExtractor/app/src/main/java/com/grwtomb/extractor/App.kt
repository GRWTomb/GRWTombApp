package com.grwtomb.extractor

import android.app.Application

class App : Application()
