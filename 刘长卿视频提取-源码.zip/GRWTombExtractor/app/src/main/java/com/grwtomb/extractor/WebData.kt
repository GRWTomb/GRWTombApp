package com.grwtomb.extractor

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONTokener
import kotlin.coroutines.resume

/**
 * 兜底方案：用本应用的 WebView 打开页面（真实浏览器环境，能通过大部分反爬），
 * 轮询执行一段 JS 表达式（如 window._ROUTER_DATA），拿到 JSON 字符串后返回。
 */
object WebData {
    suspend fun evalJson(ctx: Context, url: String, ua: String, expr: String, timeoutMs: Long = 20_000L): String? =
        withContext(Dispatchers.Main) {
            withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<String?> { cont ->
                    val handler = Handler(Looper.getMainLooper())
                    val web = WebView(ctx.applicationContext)
                    var done = false
                    var attempts = 0

                    fun finish(v: String?) {
                        if (done) return
                        done = true
                        runCatching { web.stopLoading() }
                        runCatching { web.destroy() }
                        if (cont.isActive) cont.resume(v)
                    }

                    fun decode(raw: String?): String? {
                        if (raw == null || raw == "null") return null
                        return runCatching { JSONTokener(raw).nextValue() as? String }.getOrNull()
                            ?.takeIf { it.isNotBlank() && it != "null" }
                    }

                    fun poll() {
                        handler.postDelayed({
                            if (done) return@postDelayed
                            attempts++
                            val js = "(function(){try{return JSON.stringify($expr)}catch(e){return null}})()"
                            web.evaluateJavascript(js) { raw ->
                                val s = decode(raw)
                                if (s != null) finish(s)
                                else if (!done && attempts < 25) poll()
                                else finish(null)
                            }
                        }, 800L)
                    }

                    web.settings.javaScriptEnabled = true
                    web.settings.domStorageEnabled = true
                    web.settings.userAgentString = ua
                    web.webViewClient = WebViewClient()
                    cont.invokeOnCancellation { handler.post { finish(null) } }
                    web.loadUrl(url)
                    poll()
                }
            }
        }
}
