package com.grwtomb.extractor

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class App : Application() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        Engine.init(this, scope)                      // 后台初始化引擎，不阻塞界面
        scope.launch { Engine.autoUpdate(this@App) }  // 启动即静默更新引擎
    }
}
