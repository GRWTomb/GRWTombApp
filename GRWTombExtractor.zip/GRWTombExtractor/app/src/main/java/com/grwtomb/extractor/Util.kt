package com.grwtomb.extractor

import java.net.URI

// 链接只可能由 ASCII 可见字符组成：遇到中文、中文标点（、」”【 等）、空格就在那里截断。
// 以前用“排除几个中文标点”的写法，链接后面紧跟「、」之类就会把它带进来，
// 导致 URI 解析失败、主机名变空，小红书被当成未知网站。
private val URL_RE = Regex("""https?://[A-Za-z0-9\-._~:/?#\[\]@!$&'()*+,;=%]+""")

/** 从任意文本（比如各平台的"分享口令"）里抽出第一个链接 */
fun extractUrl(s: String): String? =
    URL_RE.find(s)?.value
        ?.trimEnd('.', ',', ';', ':', '!', '?', ')', '\'')
        ?.takeIf { it.length > 10 && it.substringAfter("://").contains('.') }

/** 将抖音旧分享页转换为标准视频页；短链由 CookieBridge 的 WebView 跟随跳转。 */
fun normalizeVideoUrl(url: String): String {
    return try {
        val uri = URI(url.trim())
        val host = uri.host?.lowercase()?.removePrefix("www.") ?: return url
        if (host == "m.bilibili.com" || host == "bilibili.com") {
            // b23.tv 短链会被手机 WebView 展开成 m.bilibili.com；yt-dlp 只认 www.bilibili.com，
            // 否则会退回通用网页解析器（只有标题和封面，没有视频流）。
            val path = uri.path ?: return url
            val p = Regex("""(?:^|[?&])p=(\d+)""").find(uri.rawQuery ?: "")?.groupValues?.get(1)
            val suffix = if (p != null && p != "1") "?p=$p" else ""
            return when {
                Regex("""^/video/[aAbB][vV]\w+/?$""").matches(path) ->
                    "https://www.bilibili.com" + path.trimEnd('/') + suffix
                path.startsWith("/bangumi/play/") -> "https://www.bilibili.com$path"
                else -> url
            }
        }
        if (host == "iesdouyin.com" || host == "douyin.com") {
            val match = Regex("""^/share/video/(\d+)(?:/)?$""").matchEntire(uri.path ?: "")
            val id = match?.groupValues?.get(1) ?: return url
            "https://www.douyin.com/video/$id"
        } else {
            url
        }
    } catch (_: Throwable) {
        url
    }
}

const val RETRY_LATER = "请稍后再试"

private val HOST_RE = Regex("""^[a-zA-Z][a-zA-Z0-9+.\-]*://(?:[^/?#@]*@)?([^/?#:]+)""")

/** 取主机名。URI 解析失败（链接里有非法字符）时退回正则，保证不会返回空串而误判成未知网站 */
fun hostOf(url: String): String {
    val viaUri = runCatching { URI(url.trim()).host?.lowercase()?.removePrefix("www.") }.getOrNull()
    if (!viaUri.isNullOrEmpty()) return viaUri
    return HOST_RE.find(url.trim())?.groupValues?.get(1)?.lowercase()?.removePrefix("www.").orEmpty()
}

/** 小红书的各种域名（含国际版 RedNote、短链） */
fun isXhsHost(h: String): Boolean =
    h.endsWith("xiaohongshu.com") || h.endsWith("xhslink.com") || h.endsWith("xhs.cn") ||
        h.endsWith("rednote.com") || h.endsWith("rednotecdn.com")

fun safeName(title: String): String =
    title.replace(Regex("""[\\/:*?"<>|\u0000-\u001f]"""), "_").take(80).trim().ifBlank { "video" }

fun formatDuration(sec: Long): String {
    if (sec <= 0) return ""
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun qualityLabel(h: Int): String = when {
    h >= 4320 -> "8K"
    h >= 2160 -> "4K"
    h >= 1440 -> "2K"
    else -> "${h}p"
}

/** 把引擎抛出的英文错误归类，用来决定重试策略和提示语 */
fun classify(t: Throwable): Kind {
    if (t is ExtractError) return t.kind
    if (t is java.net.UnknownHostException || t is java.net.SocketTimeoutException ||
        t is java.net.ConnectException || t is javax.net.ssl.SSLException
    ) return Kind.NETWORK
    val m = (t.message ?: "").lowercase()
    return when {
        listOf(
            "timed out", "timeout", "name or service not known", "network is unreachable",
            "connection reset", "connection refused", "temporary failure in name resolution",
            "urlopen error", "no route to host", "unable to resolve host",
        ).any { it in m } -> Kind.NETWORK

        "unsupported url" in m -> Kind.UNSUPPORTED

        // 不要把所有包含 cookies 的错误都判定为“必须登录”。
        // yt-dlp 的 extractor 经常会提示 fresh cookies；这类错误应先走
        // Engine 的 stable/nightly 自动更新重试，而不是直接终止。
        listOf(
            "sign in to confirm", "please log in", "login required", "log in required",
            "authentication required", "requires authentication", "private video",
            "members-only", "confirm your age", "age-restricted", "registered users only",
            "http error 401",
        ).any { it in m } -> Kind.LOGIN

        listOf(
            "video unavailable", "has been removed", "been deleted", "no longer available",
            "does not exist", "is not available",
        ).any { it in m } -> Kind.REMOVED

        // 平台风控 / 拒绝请求（B 站常见 412、-352；其他站 403）。更新引擎可能有用，所以不立即终止。
        listOf("http error 412", "http error 403", "http error 429", "-352", "-412", "precondition failed")
            .any { it in m } -> Kind.BLOCKED

        else -> Kind.OTHER
    }
}

/** 取引擎原始报错的最后一条有效行，用于在界面上显示真实原因 */
fun detail(t: Throwable): String {
    val line = (t.message ?: "").lines().map { it.trim() }.lastOrNull { it.isNotEmpty() } ?: return ""
    return line.take(160)
}

fun friendly(kind: Kind): String = when (kind) {
    Kind.NETWORK, Kind.BLOCKED -> RETRY_LATER
    Kind.LOGIN -> "该内容需要登录，无法提取"
    Kind.UNSUPPORTED -> "暂不支持这个链接，请用视频页面的完整链接"
    Kind.REMOVED -> "视频不可用，可能已删除或不公开"
    Kind.ENGINE -> "解析引擎初始化失败，请重启应用"
    Kind.OTHER -> "提取失败，请确认链接是视频页面"
}
