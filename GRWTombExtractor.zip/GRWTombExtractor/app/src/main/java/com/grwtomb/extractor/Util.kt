package com.grwtomb.extractor

import java.net.URI

private val URL_RE = Regex("""https?://[^\s<>"'，。！？）】]+""")

/** 从任意文本（比如各平台的"分享口令"）里抽出第一个链接 */
fun extractUrl(s: String): String? =
    URL_RE.find(s)?.value
        ?.trimEnd('.', ',', ';', ':', '!', '?', ')', '）')
        ?.takeIf { it.length > 10 && it.substringAfter("://").contains('.') }

fun hostOf(url: String): String =
    runCatching { URI(url).host?.lowercase()?.removePrefix("www.") }.getOrNull().orEmpty()

fun safeName(title: String): String =
    title.replace(Regex("""[\\/:*?"<>|\u0000-\u001f]"""), "_").take(80).trim().ifBlank { "video" }

fun formatDuration(sec: Long): String {
    if (sec <= 0) return ""
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun qualityLabel(h: Int): String = when {
    h >= 4320 -> "8K"
    h >= 2160 -> "4K"
    h >= 1440 -> "2K"
    else -> "${h}p"
}

/** 把引擎抛出的英文错误归类，用来决定重试策略和提示语 */
fun classify(t: Throwable): Kind {
    if (t is ExtractError) return t.kind
    val m = (t.message ?: "").lowercase()
    return when {
        listOf(
            "timed out", "timeout", "name or service not known", "network is unreachable",
            "connection reset", "connection refused", "temporary failure in name resolution",
            "urlopen error", "no route to host", "unable to resolve host",
        ).any { it in m } -> Kind.NETWORK

        "unsupported url" in m -> Kind.UNSUPPORTED

        listOf(
            "sign in", "log in", "login", "cookies", "private video", "members-only",
            "confirm your age", "age-restricted", "registered users", "requires authentication",
            "http error 401",
        ).any { it in m } -> Kind.LOGIN

        listOf(
            "video unavailable", "has been removed", "been deleted", "no longer available",
            "does not exist", "is not available",
        ).any { it in m } -> Kind.REMOVED

        else -> Kind.OTHER
    }
}

fun friendly(kind: Kind): String = when (kind) {
    Kind.NETWORK -> "网络连接不稳定，请检查网络后重试"
    Kind.LOGIN -> "该内容需要登录或会员权限，暂时无法提取"
    Kind.UNSUPPORTED -> "暂不支持这个链接，请确认是视频页面的完整链接"
    Kind.REMOVED -> "视频不可用，可能已被删除或设为私密"
    Kind.ENGINE -> "解析引擎初始化失败，请重启应用"
    Kind.OTHER -> "已自动更新引擎并重试，该平台暂时无法解析。通常几天内会随引擎更新自动恢复，稍后再试即可"
}
