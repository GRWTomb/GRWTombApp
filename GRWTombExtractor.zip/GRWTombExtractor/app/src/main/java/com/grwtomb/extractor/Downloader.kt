package com.grwtomb.extractor

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object Downloader {
    const val AUTO = 0   // 自动：最高 1080p
    const val AUDIO = -1 // 仅音频

    data class Options(
        val quality: Int,
        val video: Boolean,
        val cover: Boolean,
        val subs: Boolean,
        val subLang: String?,
    )

    /** 下载到私有缓存 → 写入系统相册/下载目录 → 清理缓存。返回已保存的文件名。 */
    suspend fun run(
        ctx: Context,
        meta: VideoMeta,
        opt: Options,
        log: (String) -> Unit,
        onProgress: (Float) -> Unit,
    ): List<String> = withContext(Dispatchers.IO) {
        val dir = File(ctx.cacheDir, "job-${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val targetUrl = normalizeVideoUrl(meta.url)
            val downloadMeta = if (targetUrl == meta.url) meta else meta.copy(url = targetUrl)
            val session = CookieBridge.obtain(ctx, targetUrl)
            log(if (session.cookieCount > 0) "→ 下载会话已准备：${session.cookieCount} 条 Cookie" else "→ 未获取到网页 Cookie，继续尝试公开链接下载")
            try {
                Engine.withAutoFix(ctx, log) { exec(downloadMeta, opt, dir, onProgress, session) }
            } finally {
                session.close()
            }

            val files = dir.listFiles().orEmpty().filter {
                it.isFile && it.length() > 0 &&
                    !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") && !it.name.endsWith(".temp")
            }
            if (files.isEmpty()) throw ExtractError(Kind.OTHER, "没有生成任何文件")
            onProgress(0.99f)
            files.map { Saver.save(ctx, it) }
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun exec(meta: VideoMeta, opt: Options, dir: File, onProgress: (Float) -> Unit, session: CookieBridge.Session) {
        val req = YoutubeDLRequest(meta.url)
        session.applyTo(req)
        req.addOption("--no-playlist")
        req.addOption("--no-mtime")
        req.addOption("-o", "${dir.absolutePath}/%(title).80s [%(id)s].%(ext)s")
        req.addOption("--socket-timeout", "20")
        req.addOption("--retries", "5")
        req.addOption("--fragment-retries", "5")

        var stages = 1
        if (opt.video) {
            if (opt.quality == AUDIO) {
                req.addOption("-f", "bestaudio[ext=m4a]/bestaudio/best")
                req.addOption("-x")
                req.addOption("--audio-format", "best") // 不重新编码，直接取原始音轨
            } else {
                val h = if (opt.quality > 0) opt.quality else 1080
                req.addOption("-f", "bv*[height<=$h]+ba/b[height<=$h]/bv*+ba/b")
                req.addOption("-S", "res,ext:mp4:m4a") // 同分辨率优先 mp4/m4a，兼容性最好
                req.addOption("--merge-output-format", "mp4")
                stages = 2 // 视频流 + 音频流
            }
        } else {
            req.addOption("--skip-download")
        }
        if (opt.cover) {
            req.addOption("--write-thumbnail")
            req.addOption("--convert-thumbnails", "jpg")
        }
        if (opt.subs && opt.subLang != null) {
            req.addOption("--write-subs")
            req.addOption("--write-auto-subs")
            req.addOption("--sub-langs", opt.subLang)
            req.addOption("--convert-subs", "srt")
        }

        var stage = 0
        var best = 0f
        YoutubeDL.getInstance().execute(req, null) { p, _, line ->
            if (line.contains("[download] Destination:")) stage++
            val base = (stage - 1).coerceAtLeast(0)
            val frac = ((base + p.coerceIn(0f, 100f) / 100f) / stages).coerceIn(0f, 0.98f)
            if (frac > best) { // 进度只增不减，避免两条流切换时倒退
                best = frac
                onProgress(best)
            }
        }
    }
}
