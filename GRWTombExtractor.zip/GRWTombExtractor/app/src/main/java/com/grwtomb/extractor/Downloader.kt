package com.grwtomb.extractor

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

object Downloader {
    const val AUTO = 0   // 自动：最高 1080p
    const val AUDIO = -1 // 仅音频

    data class Options(
        val quality: Int,
        val video: Boolean,
        val cover: Boolean,
        val subs: Boolean,
        val subLang: String?,
    )

    private fun pickStream(streams: List<Stream>, quality: Int): Stream? {
        val sorted = streams.sortedByDescending { it.height }
        if (sorted.isEmpty()) return null
        return if (quality > 0) {
            sorted.minByOrNull { abs(it.height - quality) }
        } else {
            sorted.firstOrNull { it.height <= 1080 } ?: sorted.last()
        }
    }

    /** 下载到私有缓存 → 写入系统相册/下载目录 → 清理缓存。返回已保存的文件名。 */
    suspend fun run(
        ctx: Context,
        meta: VideoMeta,
        opt: Options,
        log: (String) -> Unit,
        onProgress: (Float) -> Unit,
    ): List<String> = withContext(Dispatchers.IO) {
        val dir = File(ctx.cacheDir, "job-${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val base = safeName(meta.title)
            val out = ArrayList<File>()

            if (opt.cover && meta.thumbnail != null) {
                try {
                    val ext = Regex("""\.(jpg|jpeg|png|webp)""", RegexOption.IGNORE_CASE)
                        .find(meta.thumbnail.substringBefore('?'))?.groupValues?.get(1)?.lowercase() ?: "jpg"
                    val f = File(dir, "$base.$ext")
                    Http.download(listOf(meta.thumbnail), f, meta.headers) { }
                    out.add(f)
                    log("→ 封面已下载")
                } catch (t: Throwable) {
                    log("✗ 封面下载失败：${t.message}")
                    if (!opt.video) throw t
                }
            }

            if (opt.video) {
                out.add(if (opt.quality == AUDIO) downloadAudio(meta, dir, base, log, onProgress)
                        else downloadVideo(meta, opt.quality, dir, base, log, onProgress))
            }

            if (out.isEmpty()) throw ExtractError(Kind.OTHER, "没有生成任何文件")
            onProgress(0.99f)
            out.map { Saver.save(ctx, it) }
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun downloadVideo(
        meta: VideoMeta, quality: Int, dir: File, base: String,
        log: (String) -> Unit, onProgress: (Float) -> Unit,
    ): File {
        val s = pickStream(meta.streams, quality) ?: throw ExtractError(Kind.OTHER, "没有可下载的视频流")
        val outFile = File(dir, "$base.mp4")
        val audioUrls = s.audioUrls
        if (audioUrls == null) {
            log("→ 下载 ${if (s.height > 0) "${s.height}p " else ""}完整视频")
            Http.download(s.videoUrls, outFile, meta.headers) { onProgress(it * 0.98f) }
            return outFile
        }

        val v = File(dir, "v.tmp")
        val a = File(dir, "a.tmp")
        log("→ 下载 ${s.height}p 视频流 + 音频流")
        Http.download(s.videoUrls, v, meta.headers) { onProgress(it * 0.85f) }
        Http.download(audioUrls, a, meta.headers) { onProgress(0.85f + it * 0.13f) }
        try {
            Mux.mux(listOf(v to "video/", a to "audio/"), outFile)
            log("→ 音视频已合并")
        } catch (t: Throwable) {
            log("✗ 合并失败：${t.message}")
            outFile.delete()
            val fb = meta.fallbackMp4 ?: throw ExtractError(Kind.OTHER, "音视频合并失败：${t.message}")
            log("→ 改下载 mp4 兜底版（画质较低）")
            Http.download(listOf(fb), outFile, meta.headers) { onProgress(it * 0.98f) }
        } finally {
            v.delete(); a.delete()
        }
        return outFile
    }

    private fun downloadAudio(
        meta: VideoMeta, dir: File, base: String,
        log: (String) -> Unit, onProgress: (Float) -> Unit,
    ): File {
        val s = pickStream(meta.streams, 0) ?: throw ExtractError(Kind.OTHER, "没有可下载的流")
        val outFile = File(dir, "$base.m4a")
        val tmp = File(dir, "a.tmp")
        val audioUrls = s.audioUrls
        if (audioUrls != null) {
            log("→ 下载音频流")
            Http.download(audioUrls, tmp, meta.headers) { onProgress(it * 0.95f) }
            try {
                Mux.mux(listOf(tmp to "audio/"), outFile)
            } catch (t: Throwable) {
                log("✗ 音频封装失败，直接保存原始音轨：${t.message}")
                tmp.copyTo(outFile, overwrite = true)
            }
        } else {
            // 抖音、快手等只有带画面的完整 mp4：把里面的音轨抽出来
            log("→ 下载完整视频并抽取音轨")
            Http.download(s.videoUrls, tmp, meta.headers) { onProgress(it * 0.9f) }
            try {
                Mux.mux(listOf(tmp to "audio/"), outFile)
            } catch (t: Throwable) {
                throw ExtractError(Kind.OTHER, "抽取音轨失败：${t.message}")
            }
        }
        tmp.delete()
        return outFile
    }
}
