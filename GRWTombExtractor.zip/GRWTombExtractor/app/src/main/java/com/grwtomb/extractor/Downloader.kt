package com.grwtomb.extractor

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

object Downloader {
    const val BEST = 0 // 没有画质列表时（快手、通用页面）：取最高可用

    data class Options(
        val quality: Int,
        val video: Boolean,
        val cover: Boolean,
        val subs: Boolean,
        val subLang: String?,
    )

    /** 候选顺序：先选中的画质，再依次降一档，最后才试更高的 */
    private fun orderStreams(streams: List<Stream>, quality: Int): List<Stream> {
        val sorted = streams.sortedByDescending { it.height }
        if (sorted.isEmpty()) return emptyList()
        if (quality <= 0) return sorted
        val first = sorted.minByOrNull { abs(it.height - quality) }!!
        val lower = sorted.filter { it.height < first.height }
        val higher = sorted.filter { it.height > first.height }.reversed()
        return listOf(first) + lower + higher
    }

    /** 文件头像不像视频：mp4/mov 的 ftyp 等盒子，或 webm */
    private fun looksLikeVideo(f: File): Boolean {
        if (f.length() < 2048) return false
        val b = ByteArray(12)
        val n = f.inputStream().use { it.read(b) }
        if (n < 12) return false
        val tag = String(b, 4, 4, Charsets.ISO_8859_1)
        if (tag in setOf("ftyp", "moov", "mdat", "free", "wide", "skip", "styp", "pnot")) return true
        return b[0] == 0x1A.toByte() && b[1] == 0x45.toByte() && b[2] == 0xDF.toByte()
    }

    /** 下载到私有缓存 → 写入系统相册/下载目录 → 清理缓存。返回已保存的文件名。 */
    suspend fun run(
        ctx: Context,
        meta: VideoMeta,
        opt: Options,
        log: (String) -> Unit,
        onProgress: (Float) -> Unit,
    ): List<String> = withContext(Dispatchers.IO) {
        val dir = File(ctx.cacheDir, "job-${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val base = safeName(meta.title)
            val out = ArrayList<File>()

            if (opt.cover && meta.thumbnail != null) {
                try {
                    val ext = Regex("""\.(jpg|jpeg|png|webp)""", RegexOption.IGNORE_CASE)
                        .find(meta.thumbnail.substringBefore('?'))?.groupValues?.get(1)?.lowercase() ?: "jpg"
                    val f = File(dir, "$base.$ext")
                    Http.download(listOf(meta.thumbnail), f, meta.headers) { }
                    out.add(f)
                    log("→ 封面已下载")
                } catch (t: Throwable) {
                    log("✗ 封面下载失败：${t.message}")
                    if (!opt.video) throw t
                }
            }

            if (opt.video) {
                out.add(downloadVideo(meta, opt.quality, dir, base, log, onProgress))
            }

            if (out.isEmpty()) throw ExtractError(Kind.OTHER, "没有生成任何文件")
            onProgress(0.99f)
            out.map { Saver.save(ctx, it) }
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun downloadVideo(
        meta: VideoMeta, quality: Int, dir: File, base: String,
        log: (String) -> Unit, onProgress: (Float) -> Unit,
    ): File {
        val order = orderStreams(meta.streams, quality)
        if (order.isEmpty()) throw ExtractError(Kind.OTHER, "没有可下载的视频流")
        var last: Throwable? = null
        for ((i, s) in order.withIndex()) {
            try {
                if (i > 0) log("→ 这一档下载失败，改试 ${if (s.height > 0) "${s.height}p" else "其他画质"}")
                return downloadStream(meta, s, dir, base, log, onProgress)
            } catch (e: kotlin.coroutines.cancellation.CancellationException) {
                throw e
            } catch (t: Throwable) {
                log("✗ ${s.height}p 失败：${t.message}")
                last = t
            }
        }
        throw last ?: ExtractError(Kind.OTHER, "下载失败")
    }

    private fun downloadStream(
        meta: VideoMeta, s: Stream, dir: File, base: String,
        log: (String) -> Unit, onProgress: (Float) -> Unit,
    ): File {
        val outFile = File(dir, "$base.mp4")
        val audioUrls = s.audioUrls
        if (audioUrls == null) {
            log("→ 下载 ${if (s.height > 0) "${s.height}p " else ""}完整视频")
            Http.download(s.videoUrls, outFile, meta.headers, this::looksLikeVideo) { onProgress(it * 0.98f) }
            return outFile
        }

        val v = File(dir, "v.tmp")
        val a = File(dir, "a.tmp")
        log("→ 下载 ${s.height}p 视频流 + 音频流")
        Http.download(s.videoUrls, v, meta.headers, this::looksLikeVideo) { onProgress(it * 0.85f) }
        Http.download(audioUrls, a, meta.headers, this::looksLikeVideo) { onProgress(0.85f + it * 0.13f) }
        try {
            Mux.mux(listOf(v to "video/", a to "audio/"), outFile)
            log("→ 音视频已合并")
        } catch (t: Throwable) {
            log("✗ 合并失败：${t.message}")
            outFile.delete()
            val fb = meta.fallbackMp4 ?: throw ExtractError(Kind.OTHER, "音视频合并失败：${t.message}")
            log("→ 改下载 mp4 兜底版（画质较低）")
            Http.download(listOf(fb), outFile, meta.headers, this::looksLikeVideo) { onProgress(it * 0.98f) }
        } finally {
            v.delete(); a.delete()
        }
        return outFile
    }
}
