package com.grwtomb.extractor.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.animation.fadeIn
import androidx.compose.animation.togetherWith
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.grwtomb.extractor.MainViewModel
import com.grwtomb.extractor.Phase
import com.grwtomb.extractor.UiState
import com.grwtomb.extractor.VideoMeta
import com.grwtomb.extractor.formatDuration
import com.grwtomb.extractor.qualityLabel

private val Soft = tween<Float>(320, easing = FastOutSlowInEasing)

@Composable
fun MainScreen(vm: MainViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current

    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val intro by animateFloatAsState(if (shown) 1f else 0f, tween(600, easing = FastOutSlowInEasing), label = "intro")

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .alpha(intro),
        ) {
            Spacer(Modifier.height((44 - 8 * intro).dp))
            Text(
                "刘长卿",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 3.sp,
            )
            Spacer(Modifier.height(20.dp))

            OutlinedTextField(
                value = s.input,
                onValueChange = vm::onInput,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("粘贴视频链接") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                ),
                trailingIcon = {
                    TextButton(onClick = {
                        if (s.input.isEmpty()) {
                            clipboard.getText()?.text?.let(vm::onPasteButton)
                        } else {
                            vm.onInput("")
                        }
                    }) { Text(if (s.input.isEmpty()) "粘贴" else "清除") }
                },
            )

            // 使用说明：只在空闲时显示
            AnimatedVisibility(
                visible = s.phase == Phase.Idle && s.input.isEmpty(),
                enter = fadeIn(tween(300)) + expandVertically(tween(300)),
                exit = fadeOut(tween(150)) + shrinkVertically(tween(200)),
            ) {
                Text(
                    "粘贴链接 → 选画质 → 下载\n也可以在其他 App 点分享，选「刘长卿」",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(top = 18.dp, start = 4.dp),
                )
            }

            // 解析中：一条细线
            AnimatedVisibility(
                visible = s.phase == Phase.Parsing,
                enter = fadeIn(tween(300)) + expandVertically(tween(300)),
                exit = fadeOut(tween(200)) + shrinkVertically(tween(250)),
            ) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .padding(top = 18.dp)
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(50)),
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )
            }

            // 解析失败
            AnimatedVisibility(
                visible = s.phase == Phase.Error,
                enter = fadeIn(tween(300)) + slideInVertically(tween(350, easing = FastOutSlowInEasing)) { it / 6 } + expandVertically(),
                exit = fadeOut(tween(200)) + shrinkVertically(),
            ) {
                ErrorNote(s.error.orEmpty(), s.log, Modifier.padding(top = 16.dp))
            }

            // 结果卡片
            AnimatedVisibility(
                visible = s.meta != null &&
                    (s.phase == Phase.Ready || s.phase == Phase.Downloading || s.phase == Phase.Done),
                enter = fadeIn(tween(350)) + slideInVertically(tween(400, easing = FastOutSlowInEasing)) { it / 6 } + expandVertically(tween(400)),
                exit = fadeOut(tween(200)) + shrinkVertically(tween(250)),
            ) {
                s.meta?.let { ResultCard(it, s, vm, Modifier.padding(top = 18.dp)) }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ErrorNote(text: String, log: String, modifier: Modifier = Modifier) {
    val clipboard = LocalClipboardManager.current
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Text(text, color = MaterialTheme.colorScheme.error, fontSize = 14.sp)
        if (log.isNotBlank()) {
            TextButton(onClick = { clipboard.setText(AnnotatedString(log)) }) { Text("复制日志") }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ResultCard(meta: VideoMeta, s: UiState, vm: MainViewModel, modifier: Modifier = Modifier) {
    val locked = s.phase != Phase.Ready
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(14.dp)
            .animateContentSize(tween(300, easing = FastOutSlowInEasing)),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (meta.thumbnail != null) {
            Box(Modifier.clip(RoundedCornerShape(14.dp))) {
                AsyncImage(
                    model = meta.thumbnail,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant),
                )
                val d = formatDuration(meta.durationSec)
                if (d.isNotEmpty()) {
                    Text(
                        d,
                        color = Color.White,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xCC0B1217))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                }
            }
        }
        Text(
            meta.title,
            maxLines = 2,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )

        // 提取内容：视频 / 封面 / 字幕
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = s.video, enabled = !locked, onClick = { vm.setVideo(!s.video) },
                label = { Text("视频") })
            FilterChip(selected = s.cover, enabled = !locked, onClick = { vm.setCover(!s.cover) },
                label = { Text("封面") })
            FilterChip(
                selected = s.subs,
                enabled = !locked && meta.subLangs.isNotEmpty(),
                onClick = { vm.setSubs(!s.subs) },
                label = { Text(if (meta.subLangs.isEmpty()) "字幕（无）" else "字幕") },
            )
        }

        // 画质：只列平台实际给出的档位
        AnimatedVisibility(
            visible = s.video && meta.heights.isNotEmpty(),
            enter = fadeIn(tween(250)) + expandVertically(tween(300)),
            exit = fadeOut(tween(150)) + shrinkVertically(tween(250)),
        ) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                meta.heights.forEach { h ->
                    FilterChip(selected = s.quality == h, enabled = !locked,
                        onClick = { vm.setQuality(h) }, label = { Text(qualityLabel(h)) })
                }
            }
        }

        // 字幕语言
        AnimatedVisibility(
            visible = s.subs && meta.subLangs.isNotEmpty(),
            enter = fadeIn(tween(250)) + expandVertically(tween(300)),
            exit = fadeOut(tween(150)) + shrinkVertically(tween(250)),
        ) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                meta.subLangs.forEach { l ->
                    FilterChip(selected = s.subLang == l, enabled = !locked,
                        onClick = { vm.setSubLang(l) }, label = { Text(l) })
                }
            }
        }

        s.error?.let { ErrorNote(it, s.log) }

        DownloadButton(
            phase = s.phase,
            progress = s.progress,
            canStart = s.video || s.cover || (s.subs && s.subLang != null),
            onClick = vm::download,
        )
    }
}

@Composable
private fun DownloadButton(
    phase: Phase,
    progress: Float,
    canStart: Boolean,
    onClick: () -> Unit,
) {
    val done = phase == Phase.Done
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = when {
            pressed -> 0.97f
            done -> 1.03f
            else -> 1f
        },
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = 380f),
        label = "bounce",
    )
    val p by animateFloatAsState(progress, tween(400, easing = FastOutSlowInEasing), label = "progress")
    Button(
        onClick = { if (phase == Phase.Ready) onClick() },
        enabled = phase != Phase.Ready || canStart,
        interactionSource = src,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .scale(scale),
    ) {
        AnimatedContent(
            targetState = phase,
            transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
            label = "btn",
        ) { st ->
            when (st) {
                Phase.Downloading -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        progress = { p },
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.5.dp,
                        color = LocalContentColor.current,
                        trackColor = LocalContentColor.current.copy(alpha = 0.25f),
                    )
                    Spacer(Modifier.size(10.dp))
                    Text("${(p * 100).toInt()}%")
                }
                Phase.Done -> Text("已保存 ✓")
                else -> Text("下载")
            }
        }
    }
}
