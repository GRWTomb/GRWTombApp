package com.grwtomb.extractor.ui

import androidx.compose.foundation.background
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** 一团雾：中心位置（占宽高的比例）、半径（占屏幕宽度的比例）、颜色 */
private class Fog(val x: Float, val y: Float, val r: Float, val color: Color)

/**
 * 浅色雾化渐变背景：近白的底色上，蓝 / 绿 / 白三种颜色的柔和光团无规则地散落，
 * 边缘完全融化（径向渐变到透明），没有任何硬边。
 * 只在尺寸变化时重绘，滚动内容时不会重复计算。
 */
private val Fogs = listOf(
    // 蓝
    Fog(0.02f, 0.03f, 0.85f, Color(0xFFBCD3FF).copy(alpha = 0.80f)),
    Fog(0.88f, 0.40f, 0.65f, Color(0xFFCFE0FF).copy(alpha = 0.60f)),
    Fog(0.98f, 0.82f, 0.70f, Color(0xFFC5DAFF).copy(alpha = 0.55f)),
    // 绿（薄荷 / 青）
    Fog(1.00f, 0.13f, 0.75f, Color(0xFFB8F0DE).copy(alpha = 0.75f)),
    Fog(0.00f, 0.52f, 0.70f, Color(0xFFC4F1D9).copy(alpha = 0.60f)),
    Fog(0.30f, 0.95f, 0.80f, Color(0xFFBDEBE8).copy(alpha = 0.65f)),
    // 白：压在彩色光团上面，把颜色“化”开，保持整体偏白
    Fog(0.42f, 0.20f, 0.55f, Color.White.copy(alpha = 0.95f)),
    Fog(0.35f, 0.68f, 0.55f, Color.White.copy(alpha = 0.85f)),
    Fog(0.75f, 0.62f, 0.45f, Color.White.copy(alpha = 0.70f)),
)

fun Modifier.fogBackground(): Modifier = this
    .background(Brush.verticalGradient(listOf(Color(0xFFFAFCFF), Color(0xFFF3F7FC))))
    .drawBehind {
        for (f in Fogs) {
            val center = Offset(size.width * f.x, size.height * f.y)
            val radius = size.width * f.r
            drawCircle(
                brush = Brush.radialGradient(
                    0f to f.color,
                    0.5f to f.color.copy(alpha = f.color.alpha * 0.45f),
                    1f to Color.Transparent,
                    center = center,
                    radius = radius,
                ),
                radius = radius,
                center = center,
            )
        }
    }
