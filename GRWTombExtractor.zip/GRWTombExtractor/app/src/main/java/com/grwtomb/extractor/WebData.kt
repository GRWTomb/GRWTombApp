package com.grwtomb.extractor

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONTokener
import java.util.Collections
import kotlin.coroutines.resume

/**
 * 兜底方案：用本应用的 WebView 打开页面（真实浏览器环境，能通过大部分反爬），
 * 轮询执行一段 JS 表达式（如 window._ROUTER_DATA），拿到 JSON 字符串后返回。
 */
object WebData {
    /** WebView 里该站点当前的 Cookie（TikTok 下载视频需要） */
    fun cookies(url: String): String? =
        runCatching { android.webkit.CookieManager.getInstance().getCookie(url) }.getOrNull()

    suspend fun evalJson(ctx: Context, url: String, ua: String, expr: String, timeoutMs: Long = 20_000L): String? =
        withContext(Dispatchers.Main) {
            withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<String?> { cont ->
                    val handler = Handler(Looper.getMainLooper())
                    val web = WebView(ctx.applicationContext)
                    var done = false
                    var attempts = 0

                    fun finish(v: String?) {
                        if (done) return
                        done = true
                        runCatching { web.stopLoading() }
                        runCatching { web.destroy() }
                        if (cont.isActive) cont.resume(v)
                    }

                    fun decode(raw: String?): String? {
                        if (raw == null || raw == "null") return null
                        return runCatching { JSONTokener(raw).nextValue() as? String }.getOrNull()
                            ?.takeIf { it.isNotBlank() && it != "null" }
                    }

                    fun poll() {
                        handler.postDelayed({
                            if (done) return@postDelayed
                            attempts++
                            val js = "(function(){try{return JSON.stringify($expr)}catch(e){return null}})()"
                            web.evaluateJavascript(js) { raw ->
                                val s = decode(raw)
                                if (s != null) finish(s)
                                else if (!done && attempts < 25) poll()
                                else finish(null)
                            }
                        }, 800L)
                    }

                    web.settings.javaScriptEnabled = true
                    web.settings.domStorageEnabled = true
                    web.settings.userAgentString = ua
                    web.webViewClient = WebViewClient()
                    cont.invokeOnCancellation { handler.post { finish(null) } }
                    web.loadUrl(url)
                    poll()
                }
            }
        }

    /** 嗅探结果：网页真正请求到的视频地址 */
    class Sniffed(val urls: List<String>, val title: String?, val poster: String?, val cookie: String?)

    private fun isVideoRequest(u: String): Boolean {
        val l = u.lowercase()
        if (!l.startsWith("http")) return false
        val path = l.substringBefore('?')
        if (path.endsWith(".m3u8") || path.endsWith(".ts") || path.endsWith(".js") || path.endsWith(".css") ||
            path.endsWith(".jpg") || path.endsWith(".png") || path.endsWith(".webp") || path.endsWith(".gif") ||
            path.endsWith(".mpd") || path.endsWith(".m4s") || path.endsWith(".m4a")
        ) return false
        if ("bytestart=" in l || "mime_type=audio" in l || "mime=audio" in l) return false
        return path.endsWith(".mp4") || path.endsWith(".mov") || path.endsWith(".webm") ||
            "mime_type=video_mp4" in l || "mime=video%2fmp4" in l ||
            "aweme/v1/play" in l || "/video/tos/" in l || "douyinvod.com" in l
    }

    /**
     * 通用兜底：用 WebView 像真实浏览器一样打开页面并自动静音播放，
     * 抓取页面实际请求到的 mp4 地址（以及 <video> 标签的地址）。
     * 对大多数“数据藏在脚本里、HTTP 取不到”的网站有效。
     */
    suspend fun sniff(ctx: Context, url: String, ua: String, timeoutMs: Long = 25_000L): Sniffed? =
        withContext(Dispatchers.Main) {
            withTimeoutOrNull(timeoutMs) {
                suspendCancellableCoroutine<Sniffed?> { cont ->
                    val handler = Handler(Looper.getMainLooper())
                    val web = WebView(ctx.applicationContext)
                    val found = Collections.synchronizedList(ArrayList<String>())
                    var done = false
                    var attempts = 0
                    var title: String? = null
                    var poster: String? = null

                    fun finish() {
                        if (done) return
                        done = true
                        val list = synchronized(found) { found.distinct() }
                        val cookie = runCatching { android.webkit.CookieManager.getInstance().getCookie(url) }.getOrNull()
                        runCatching { web.stopLoading() }
                        runCatching { web.destroy() }
                        if (cont.isActive) {
                            cont.resume(if (list.isEmpty()) null else Sniffed(list, title, poster, cookie))
                        }
                    }

                    val js = "(function(){try{var v=document.querySelector('video');" +
                        "if(v){v.muted=true;var p=v.play();if(p&&p.catch)p.catch(function(){});}" +
                        "var s=v?(v.currentSrc||v.src):'';" +
                        "return JSON.stringify({src:(s&&s.indexOf('http')==0)?s:'',title:document.title,poster:v?v.poster:''})" +
                        "}catch(e){return null}})()"

                    fun poll() {
                        handler.postDelayed({
                            if (done) return@postDelayed
                            attempts++
                            web.evaluateJavascript(js) { raw ->
                                val text = runCatching { JSONTokener(raw).nextValue() as? String }.getOrNull()
                                val o = text?.let { runCatching { org.json.JSONObject(it) }.getOrNull() }
                                if (o != null) {
                                    o.optString("src").takeIf { it.startsWith("http") }?.let { found.add(it) }
                                    o.optString("title").takeIf { it.isNotBlank() }?.let { title = it }
                                    o.optString("poster").takeIf { it.startsWith("http") }?.let { poster = it }
                                }
                                // 找到后再多等一轮，让更高清的请求也进来
                                val has = synchronized(found) { found.isNotEmpty() }
                                if (!done) {
                                    if (has && attempts >= 3) finish()
                                    else if (attempts >= 30) finish()
                                    else poll()
                                }
                            }
                        }, 800L)
                    }

                    web.settings.javaScriptEnabled = true
                    web.settings.domStorageEnabled = true
                    web.settings.mediaPlaybackRequiresUserGesture = false
                    web.settings.userAgentString = ua
                    web.webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                            val u = request?.url?.toString()
                            if (u != null && isVideoRequest(u)) found.add(u)
                            return null
                        }
                    }
                    cont.invokeOnCancellation { handler.post { finish() } }
                    web.loadUrl(url)
                    poll()
                }
            }
        }
}
