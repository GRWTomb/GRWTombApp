package com.grwtomb.extractor

/**
 * 一条可下载的流。
 * audioUrls == null：videoUrls 本身就是带声音的完整 mp4（抖音、快手、B 站 html5 mp4）
 * audioUrls != null：音视频分离（B 站 DASH），下载后在本地合并
 * 每组地址是候选列表：前一个失败就换下一个。
 */
data class Stream(
    val height: Int,
    val videoUrls: List<String>,
    val audioUrls: List<String>? = null,
)

/** 解析出的视频信息 */
data class VideoMeta(
    val url: String,
    val title: String,
    val thumbnail: String?,
    val durationSec: Long,
    val heights: List<Int>,
    val subLangs: List<String>,
    val streams: List<Stream> = emptyList(),
    /** 合并失败时的兜底：带声音的完整 mp4（画质较低） */
    val fallbackMp4: String? = null,
    /** 下载媒体文件时要带的请求头（如 B 站的 Referer） */
    val headers: Map<String, String> = emptyMap(),
)

enum class Phase { Idle, Parsing, Ready, Downloading, Done, Error }

data class UiState(
    val input: String = "",
    val phase: Phase = Phase.Idle,
    val meta: VideoMeta? = null,
    val error: String? = null,
    /** 0 = 自动(最高 1080p)，-1 = 仅音频，其余 = 指定高度 */
    val quality: Int = Downloader.AUTO,
    val video: Boolean = true,
    val cover: Boolean = false,
    val subs: Boolean = false,
    val subLang: String? = null,
    val progress: Float = 0f,
    val saved: List<String> = emptyList(),
    val log: String = "",
)

enum class Kind { NETWORK, LOGIN, UNSUPPORTED, REMOVED, ENGINE, BLOCKED, OTHER }

class ExtractError(val kind: Kind, message: String) : Exception(message)
