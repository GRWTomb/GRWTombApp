package com.grwtomb.extractor

/** 解析出的视频信息 */
data class VideoMeta(
    val url: String,
    val title: String,
    val thumbnail: String?,
    val durationSec: Long,
    val heights: List<Int>,
    val subLangs: List<String>,
)

enum class Phase { Idle, Parsing, Ready, Downloading, Done, Error }

data class UiState(
    val input: String = "",
    val phase: Phase = Phase.Idle,
    val meta: VideoMeta? = null,
    val error: String? = null,
    /** 0 = 自动(最高 1080p)，-1 = 仅音频，其余 = 指定高度 */
    val quality: Int = Downloader.AUTO,
    val video: Boolean = true,
    val cover: Boolean = false,
    val subs: Boolean = false,
    val subLang: String? = null,
    val progress: Float = 0f,
    val saved: List<String> = emptyList(),
    val log: String = "",
)

enum class Kind { NETWORK, LOGIN, UNSUPPORTED, REMOVED, ENGINE, OTHER }

class ExtractError(val kind: Kind, message: String) : Exception(message)
