package com.grwtomb.extractor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import kotlin.math.min

/**
 * 自研解析：YouTube / X / TikTok / Facebook / 小红书。
 * 都只用公开页面或公开接口，没有第三方解析服务，也没有 yt-dlp。
 */

// ───────────────────────── 小工具 ─────────────────────────

private fun JSONArray?.strs(): List<String> {
    val a = this ?: return emptyList()
    return (0 until a.length()).mapNotNull { a.optString(it).takeIf { s -> s.startsWith("http") } }
}

private fun titleOf(html: String): String =
    Regex("""<title[^>]*>([^<]*)</title>""", RegexOption.IGNORE_CASE).find(html)?.groupValues?.get(1)
        ?.replace("&amp;", "&")?.trim().orEmpty()

private fun metaOf(html: String, name: String): String? {
    val n = Regex.escape(name)
    val a = Regex("""<meta[^>]+(?:property|name)=["']$n["'][^>]*content=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    val b = Regex("""<meta[^>]+content=["']([^"']+)["'][^>]*(?:property|name)=["']$n["']""", RegexOption.IGNORE_CASE)
    return (a.find(html) ?: b.find(html))?.groupValues?.get(1)
        ?.replace("&amp;", "&")?.replace("&#x2F;", "/")?.replace("&#064;", "@")
}

/** 页面内嵌 JSON 字符串里的转义（\/ & 等）还原 */
private fun jsonUnescape(s: String): String =
    runCatching { JSONObject("{\"v\":\"" + s + "\"}").getString("v") }
        .getOrElse { s.replace("\\/", "/").replace("\\u0026", "&").replace("\\u0025", "%") }

private fun shortSide(w: Int, h: Int): Int = if (w > 0 && h > 0) min(w, h) else 0

private fun looksBlocked(html: String): Boolean =
    listOf("captcha", "verify to continue", "slide to verify", "unusual traffic").any { html.contains(it, ignoreCase = true) }

// ───────────────────────── YouTube ─────────────────────────
// 走 InnerTube 的 player 接口，用手机/VR 客户端身份，返回的地址不需要解签名。
// 下载 avc1 视频流 + m4a 音频流，用系统 MediaMuxer 合并。

internal object YouTube {
    private class Client(val id: String, val ua: String, val body: JSONObject) {
        val name: String get() = body.getString("clientName")
        val version: String get() = body.getString("clientVersion")
    }

    private fun clients(): List<Client> = listOf(
        Client(
            "28",
            "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
            JSONObject().put("clientName", "ANDROID_VR").put("clientVersion", "1.60.19")
                .put("deviceMake", "Oculus").put("deviceModel", "Quest 3").put("androidSdkVersion", 32)
                .put("osName", "Android").put("osVersion", "12L").put("hl", "en").put("gl", "US"),
        ),
        Client(
            "28",
            "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 14; eureka-user Build/UP1A.231005.007.A1) gzip",
            JSONObject().put("clientName", "ANDROID_VR").put("clientVersion", "1.65.10")
                .put("deviceMake", "Oculus").put("deviceModel", "Quest 3").put("androidSdkVersion", 34)
                .put("osName", "Android").put("osVersion", "14").put("hl", "en").put("gl", "US"),
        ),
        Client(
            "5",
            "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            JSONObject().put("clientName", "IOS").put("clientVersion", "20.10.4")
                .put("deviceMake", "Apple").put("deviceModel", "iPhone16,2")
                .put("osName", "iPhone").put("osVersion", "18.3.2.22D82").put("hl", "en").put("gl", "US"),
        ),
        Client(
            "3",
            "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip",
            JSONObject().put("clientName", "ANDROID").put("clientVersion", "20.10.38")
                .put("androidSdkVersion", 30).put("osName", "Android").put("osVersion", "11")
                .put("hl", "en").put("gl", "US"),
        ),
    )

    private fun videoId(url: String): String? {
        val u = runCatching { URI(url.trim()) }.getOrNull() ?: return null
        val host = u.host?.lowercase().orEmpty()
        val path = u.path.orEmpty()
        if (host == "youtu.be") return path.trim('/').substringBefore('/').takeIf { it.length == 11 }
        Regex("""(?:^|[?&])v=([\w-]{11})""").find(u.rawQuery.orEmpty())?.let { return it.groupValues[1] }
        return Regex("""/(?:shorts|live|embed|v)/([\w-]{11})""").find(path)?.groupValues?.get(1)
    }

    private fun usable(a: JSONArray?): List<JSONObject> {
        val arr = a ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
            .filter { it.optString("url").startsWith("http") }
    }

    /** 从 player 返回的 JSON 里挑出可用的流；没有可直接下载的流时返回 null */
    private fun build(j: JSONObject, id: String, ua: String, log: (String) -> Unit): VideoMeta? {
        val details = j.optJSONObject("videoDetails")
        if (details?.optBoolean("isLive") == true) throw ExtractError(Kind.UNSUPPORTED, "暂不支持直播")
        val sd = j.optJSONObject("streamingData")
        val adaptive = usable(sd?.optJSONArray("adaptiveFormats"))
        val progressive = usable(sd?.optJSONArray("formats"))
            .filter { it.optString("mimeType").startsWith("video/mp4") }
            .sortedByDescending { it.optInt("height") }

        val videos = adaptive.filter {
            val m = it.optString("mimeType")
            m.startsWith("video/mp4") && m.contains("avc1")
        }
        val audio = adaptive.filter { it.optString("mimeType").startsWith("audio/mp4") }
            .sortedWith(
                compareByDescending<JSONObject> { it.optJSONObject("audioTrack")?.optBoolean("audioIsDefault", true) ?: true }
                    .thenByDescending { it.optLong("bitrate") },
            )
            .firstOrNull()?.optString("url")

        val streams = ArrayList<Stream>()
        if (audio != null) {
            videos.groupBy { it.optInt("height") }.filterKeys { it > 0 }.forEach { (h, list) ->
                // 同一档里码率高的排前面，其余作为备用地址
                val sorted = list.sortedByDescending { it.optLong("bitrate") }.map { it.optString("url") }
                streams.add(Stream(h, sorted, listOf(audio)))
            }
        }
        for (p in progressive) {
            val h = p.optInt("height")
            if (h > 0 && streams.none { it.height == h }) streams.add(Stream(h, listOf(p.optString("url")), null))
        }
        if (streams.isEmpty()) return null

        val thumbs = details?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
        val thumb = thumbs?.optJSONObject((thumbs.length() - 1).coerceAtLeast(0))?.optString("url")
            ?: "https://i.ytimg.com/vi/$id/hqdefault.jpg"
        val heights = streams.map { it.height }.distinct().sortedDescending().take(8)
        log("→ YouTube 解析成功：${heights.joinToString("/") { "${it}p" }}")
        return VideoMeta(
            url = "https://www.youtube.com/watch?v=$id",
            title = details?.optString("title").orEmpty().ifBlank { "YouTube 视频" },
            thumbnail = thumb,
            durationSec = details?.optString("lengthSeconds")?.toLongOrNull() ?: 0,
            heights = heights, subLangs = emptyList(), streams = streams.sortedByDescending { it.height },
            fallbackMp4 = progressive.firstOrNull()?.optString("url"),
            headers = mapOf("User-Agent" to ua),
        )
    }

    fun resolve(url: String, log: (String) -> Unit): VideoMeta {
        val id = videoId(url) ?: throw ExtractError(Kind.UNSUPPORTED, "没能从链接里找到 YouTube 视频编号")
        var firstKind: Kind? = null
        var firstMsg = ""

        // 先打开一次网页：拿 visitorData（带上它，被当作机器人的概率明显更低），顺便留一份网页里的播放数据备用
        var visitor: String? = null
        var pagePlayer: JSONObject? = null
        try {
            val pg = Http.get(
                null, "https://www.youtube.com/watch?v=$id&hl=en",
                mapOf("User-Agent" to Http.UA_PC, "Accept-Language" to "en-US,en;q=0.9", "Cookie" to "CONSENT=YES+1; SOCS=CAI"),
            )
            visitor = Regex(""""visitorData"\s*:\s*"([^"]+)"""").find(pg.body)?.groupValues?.get(1)
            pagePlayer = jsonAfter(pg.body, "ytInitialPlayerResponse")?.let { runCatching { JSONObject(it) }.getOrNull() }
            log("→ YouTube 网页 HTTP ${pg.code}，visitorData=${visitor != null}，网页播放数据=${pagePlayer != null}")
        } catch (t: Throwable) {
            log("→ YouTube 网页请求失败：${t.message}")
        }

        for (c in clients()) {
            val client = JSONObject(c.body.toString())
            visitor?.let { client.put("visitorData", it) }
            val body = JSONObject()
                .put("context", JSONObject().put("client", client))
                .put("videoId", id)
                .put("contentCheckOk", true)
                .put("racyCheckOk", true)
                .put(
                    "playbackContext",
                    JSONObject().put("contentPlaybackContext", JSONObject().put("html5Preference", "HTML5_PREF_WANTS")),
                )
            val headers = HashMap<String, String>()
            headers["User-Agent"] = c.ua
            headers["X-YouTube-Client-Name"] = c.id
            headers["X-YouTube-Client-Version"] = c.version
            headers["Origin"] = "https://www.youtube.com"
            headers["Accept-Language"] = "en-US,en;q=0.9"
            visitor?.let { headers["X-Goog-Visitor-Id"] = it }
            val r = try {
                Http.postJson("https://www.youtube.com/youtubei/v1/player?prettyPrint=false", body.toString(), headers)
            } catch (t: Throwable) {
                log("→ YouTube ${c.name} ${c.version}：请求失败 ${t.message}")
                if (firstKind == null) { firstKind = Kind.NETWORK; firstMsg = t.message.orEmpty() }
                continue
            }
            val j = runCatching { JSONObject(r.body) }.getOrNull()
            if (j == null) {
                log("→ YouTube ${c.name}：HTTP ${r.code}，返回的不是 JSON")
                if (firstKind == null) { firstKind = Kind.BLOCKED; firstMsg = "HTTP ${r.code}" }
                continue
            }
            val ps = j.optJSONObject("playabilityStatus")
            val status = ps?.optString("status").orEmpty()
            val reason = ps?.optString("reason").orEmpty()
            log("→ YouTube ${c.name} ${c.version}：$status $reason".trim())
            if (status != "OK") {
                if (firstKind == null) {
                    firstKind = when {
                        status == "ERROR" -> Kind.REMOVED
                        status == "LOGIN_REQUIRED" && reason.contains("bot", ignoreCase = true) -> Kind.BLOCKED
                        status == "LOGIN_REQUIRED" -> Kind.LOGIN
                        else -> Kind.OTHER
                    }
                    firstMsg = reason
                }
                // 视频本身不存在：换客户端也没用
                if (status == "ERROR" && reason.contains("unavailable", ignoreCase = true)) break
                continue
            }
            build(j, id, c.ua, log)?.let { return it }
            log("→ YouTube ${c.name}：没有可直接下载的流（可能需要签名或验证）")
            if (firstKind == null) { firstKind = Kind.BLOCKED; firstMsg = "no streams" }
        }

        // 最后试网页里内嵌的播放数据（少数视频的地址不需要解签名）
        pagePlayer?.let { pj ->
            if (pj.optJSONObject("playabilityStatus")?.optString("status") == "OK") {
                build(pj, id, Http.UA_PC, log)?.let { return it }
            }
        }

        val kind = firstKind ?: Kind.BLOCKED
        log("→ YouTube 最终失败：$kind $firstMsg")
        throw ExtractError(
            kind,
            when (kind) {
                Kind.REMOVED -> "视频不可用，可能已被删除或设为私密"
                Kind.LOGIN -> "该视频需要登录才能观看（年龄限制或私密）"
                else -> "YouTube 没有返回可下载的地址"
            },
        )
    }
}

// ───────────────────────── X（Twitter） ─────────────────────────
// 公开的 syndication 接口，公开推文直接给出 mp4 各档地址（带声音）。

internal object Twitter {
    private fun idOf(u: String): String? =
        Regex("""/status(?:es)?/(\d{5,})""").find(u)?.groupValues?.get(1)
            ?: Regex("""/i/web/status/(\d{5,})""").find(u)?.groupValues?.get(1)

    private fun randomToken(): String {
        val chars = "123456789abcdefghijklmnopqrstuvwxyz"
        return (1..10).map { chars.random() }.joinToString("")
    }

    fun resolve(url: String, log: (String) -> Unit): VideoMeta {
        var id = idOf(url)
        if (id == null) {
            val r = Http.get(null, url, mapOf("User-Agent" to Http.UA_PC))
            log("→ 短链已展开：${hostOf(url)} → ${hostOf(r.finalUrl)}")
            id = idOf(r.finalUrl) ?: throw ExtractError(Kind.UNSUPPORTED, "没能从链接里找到推文编号")
        }
        val hdr = mapOf("User-Agent" to Http.UA_PC, "Referer" to "https://platform.twitter.com/", "Accept" to "application/json")
        var r = Http.get(null, "https://cdn.syndication.twimg.com/tweet-result?id=$id&lang=en&token=${randomToken()}", hdr)
        // 接口偶尔抽风（空返回 / 限流）：换个 token 再试两次
        var tries = 1
        while (tries < 3 && r.code != 404 && (r.body.isBlank() || r.code == 429 || r.code in 500..599)) {
            Thread.sleep(700L * tries)
            r = Http.get(null, "https://cdn.syndication.twimg.com/tweet-result?id=$id&lang=en&token=${randomToken()}", hdr)
            tries++
        }
        log("→ X 接口 HTTP ${r.code}，${r.body.length} 字节，尝试 $tries 次")
        if (r.code == 404) throw ExtractError(Kind.REMOVED, "推文不存在、已删除或不公开")
        if (r.code == 429 || r.code in 500..599) throw ExtractError(Kind.BLOCKED, "X 接口暂时拒绝请求 HTTP ${r.code}")
        val j = runCatching { JSONObject(r.body) }.getOrNull()
            ?: throw ExtractError(Kind.BLOCKED, "X 接口没有返回数据（HTTP ${r.code}）")
        if (j.optString("__typename") == "TweetTombstone" || j.has("tombstone")) {
            throw ExtractError(Kind.LOGIN, "这条推文需要登录才能查看")
        }

        class V(val url: String, val bitrate: Long, val height: Int)
        val variants = ArrayList<V>()
        var cover: String? = null
        var dur = 0L
        var hasPhoto = false

        fun addVariants(arr: JSONArray?) {
            if (arr == null) return
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val type = o.optString("content_type").ifBlank { o.optString("type") }
                val u = o.optString("url").ifBlank { o.optString("src") }
                if (!type.contains("mp4") || !u.startsWith("http")) continue
                val m = Regex("""/(\d{2,4})x(\d{2,4})/""").find(u)
                val h = if (m != null) shortSide(m.groupValues[1].toInt(), m.groupValues[2].toInt()) else 0
                variants.add(V(u, o.optLong("bitrate"), h))
            }
        }

        val media = j.optJSONArray("mediaDetails")
        if (media != null) for (i in 0 until media.length()) {
            val m = media.optJSONObject(i) ?: continue
            if (m.optString("type") == "photo") { hasPhoto = true; continue }
            val vi = m.optJSONObject("video_info") ?: continue
            if (variants.isEmpty()) {
                addVariants(vi.optJSONArray("variants"))
                cover = m.optString("media_url_https").takeIf { it.startsWith("http") }
                dur = vi.optLong("duration_millis") / 1000
            }
        }
        if (variants.isEmpty()) {
            val legacy = j.optJSONObject("video")
            addVariants(legacy?.optJSONArray("variants"))
            cover = cover ?: legacy?.optString("poster")?.takeIf { it.startsWith("http") }
        }
        if (variants.isEmpty()) {
            if (hasPhoto) throw ExtractError(Kind.UNSUPPORTED, "这条推文只有图片，暂不支持")
            throw ExtractError(Kind.UNSUPPORTED, "这条推文里没有视频")
        }

        val streams = ArrayList<Stream>()
        val withH = variants.filter { it.height > 0 }
        if (withH.isNotEmpty()) {
            withH.groupBy { it.height }.forEach { (h, l) ->
                streams.add(Stream(h, l.sortedByDescending { it.bitrate }.map { it.url }, null))
            }
        } else {
            streams.add(Stream(0, variants.sortedByDescending { it.bitrate }.map { it.url }, null))
        }
        val heights = streams.map { it.height }.filter { it > 0 }.distinct().sortedDescending()
        val text = j.optString("text").replace(Regex("""https?://t\.co/\w+"""), "").trim()
        val user = j.optJSONObject("user")?.optString("name").orEmpty()
        val title = text.ifBlank { user.ifBlank { "X 视频" } }.lines().first().take(80)
        log("→ X 解析成功：${variants.size} 个版本")
        return VideoMeta(
            url = "https://x.com/i/status/$id", title = title, thumbnail = cover, durationSec = dur,
            heights = heights, subLangs = emptyList(), streams = streams,
            headers = mapOf("User-Agent" to Http.UA_PC),
        )
    }
}

// ───────────────────────── TikTok ─────────────────────────
// 读网页里内嵌的 __UNIVERSAL_DATA_FOR_REHYDRATION__；下载时要带上页面给的 Cookie。

internal object TikTok {
    private const val DATA_ID = "__UNIVERSAL_DATA_FOR_REHYDRATION__"

    private fun idOf(u: String): String? =
        Regex("""/(?:video|photo)/(\d{8,})""").find(u)?.groupValues?.get(1)
            ?: Regex("""[?&]share_item_id=(\d{8,})""").find(u)?.groupValues?.get(1)

    private fun scriptJson(html: String): String? =
        Regex("""<script[^>]*id=["']$DATA_ID["'][^>]*>(.*?)</script>""", RegexOption.DOT_MATCHES_ALL)
            .find(html)?.groupValues?.get(1)

    private fun itemOf(root: JSONObject, log: (String) -> Unit): JSONObject? {
        val vd = root.optJSONObject("__DEFAULT_SCOPE__")?.optJSONObject("webapp.video-detail")
        val code = vd?.optInt("statusCode", 0) ?: 0
        if (code != 0) {
            log("→ TikTok statusCode=$code ${vd?.optString("statusMsg").orEmpty()}")
            if (code == 10204 || code == 10216 || code == 10222) throw ExtractError(Kind.REMOVED, "视频不存在、已删除或不公开")
            if (code == 10101) throw ExtractError(Kind.BLOCKED, "TikTok 暂时拒绝请求")
        }
        return vd?.optJSONObject("itemInfo")?.optJSONObject("itemStruct")
            ?: findObj(root) { it.has("desc") && it.optJSONObject("video")?.has("playAddr") == true }
    }

    suspend fun resolve(ctx: Context, url: String, log: (String) -> Unit): VideoMeta {
        val s = HttpSession()
        val pcHeaders = mapOf(
            "User-Agent" to Http.UA_PC, "Accept" to "text/html,application/xhtml+xml",
            "Accept-Language" to "en-US,en;q=0.9",
        )
        var page = url
        var id = idOf(url)
        if (id == null) {
            val r = Http.get(s, url, pcHeaders)
            log("→ 短链已展开：${hostOf(url)} → ${hostOf(r.finalUrl)}")
            id = idOf(r.finalUrl) ?: throw ExtractError(Kind.UNSUPPORTED, "没能从链接里找到视频编号（可能是主页、直播或图文）")
            page = r.finalUrl.substringBefore('?')
        }
        if (!page.contains("/video/")) page = "https://www.tiktok.com/@_/video/$id"

        var item: JSONObject? = null
        var cookie: String? = null
        // 电脑版、手机版页面各试一次（风控对两种身份的态度不一样）
        for ((label, ua) in listOf("电脑版" to Http.UA_PC, "手机版" to Http.UA_MOBILE)) {
            if (item != null) break
            val r = runCatching { Http.get(s, page, pcHeaders + ("User-Agent" to ua)) }.getOrNull() ?: continue
            log("→ TikTok $label 页面 HTTP ${r.code}，${r.body.length} 字节，疑似验证=${looksBlocked(r.body)}")
            val js = scriptJson(r.body)
            if (js != null) {
                val root = runCatching { JSONObject(js) }.getOrNull()
                if (root != null) item = itemOf(root, log)
            } else {
                log("→ 页面里没有 $DATA_ID")
            }
            cookie = s.header()
        }

        // 嵌入式播放页：数据结构简单，风控也宽松
        if (item == null) {
            val er = runCatching { Http.get(s, "https://www.tiktok.com/embed/v2/$id", pcHeaders) }.getOrNull()
            if (er != null) {
                log("→ TikTok 嵌入页 HTTP ${er.code}，${er.body.length} 字节")
                val js = Regex("""<script[^>]*id=["']__FRONTITY_CONNECT_STATE__["'][^>]*>(.*?)</script>""", RegexOption.DOT_MATCHES_ALL)
                    .find(er.body)?.groupValues?.get(1)
                val root = js?.let { runCatching { JSONObject(it) }.getOrNull() }
                val infos = root?.let { rt ->
                    findObj(rt) { it.optJSONObject("video")?.optJSONArray("urls") != null && it.has("text") }
                }
                if (infos != null) {
                    val vv = infos.getJSONObject("video")
                    val meta = vv.optJSONObject("videoMeta")
                    val urls = vv.optJSONArray("urls")
                    val first = JSONObject()
                        .put("PlayAddr", JSONObject().put("UrlList", urls)
                            .put("Width", meta?.optInt("width") ?: 0).put("Height", meta?.optInt("height") ?: 0))
                        .put("CodecType", "h264").put("Bitrate", 0)
                    item = JSONObject()
                        .put("desc", infos.optString("text"))
                        .put("video", JSONObject()
                            .put("bitrateInfo", JSONArray().put(first))
                            .put("cover", infos.optJSONArray("covers")?.optString(0).orEmpty())
                            .put("duration", meta?.optLong("duration") ?: 0))
                    log("→ 从嵌入页拿到视频数据")
                }
                cookie = s.header() ?: cookie
            }
        }

        if (item == null) {
            log("→ HTTP 方式没取到数据，改用 WebView 打开")
            val expr = "JSON.parse(document.getElementById('$DATA_ID').textContent)"
            val got = WebData.evalJson(ctx, page, Http.UA_PC, expr, 25_000L)
            log("→ WebView 结果：${got?.let { "${it.length} 字符" } ?: "空（超时或需要验证）"}")
            if (got != null) {
                val root = runCatching { JSONObject(got) }.getOrNull()
                if (root != null) item = itemOf(root, log)
                cookie = WebData.cookies("https://www.tiktok.com") ?: cookie
            }
        }

        val it0 = item ?: throw ExtractError(Kind.BLOCKED, "没有取到 TikTok 视频数据（可能被平台验证拦截）")
        if (it0.optJSONObject("imagePost") != null) throw ExtractError(Kind.UNSUPPORTED, "这是图文作品，暂不支持")
        val v = it0.optJSONObject("video") ?: throw ExtractError(Kind.OTHER, "TikTok 数据里没有 video 字段")

        // 按画质分组：优先 h264（兼容性好），同档里码率高的优先
        class Cand(val height: Int, val urls: List<String>, val h264: Boolean, val bitrate: Long)
        val cands = ArrayList<Cand>()
        val br = v.optJSONArray("bitrateInfo")
        if (br != null) for (i in 0 until br.length()) {
            val o = br.optJSONObject(i) ?: continue
            val pa = o.optJSONObject("PlayAddr") ?: continue
            val urls = pa.optJSONArray("UrlList").strs()
            if (urls.isEmpty()) continue
            val h = shortSide(pa.optInt("Width"), pa.optInt("Height"))
            cands.add(Cand(h, urls, o.optString("CodecType").contains("h264", true), o.optLong("Bitrate")))
        }
        val mainH = shortSide(v.optInt("width"), v.optInt("height"))
        val mainUrls = listOf(v.optString("downloadAddr"), v.optString("playAddr")).filter { it.startsWith("http") }
        if (mainUrls.isNotEmpty()) cands.add(Cand(mainH, mainUrls, false, 0))
        if (cands.isEmpty()) throw ExtractError(Kind.OTHER, "TikTok 数据里没有播放地址")

        val streams = cands.groupBy { it.height }.map { (h, l) ->
            val sorted = l.sortedWith(compareByDescending<Cand> { it.h264 }.thenByDescending { it.bitrate })
            Stream(h, sorted.flatMap { it.urls }.distinct(), null)
        }.sortedByDescending { it.height }

        val heights = streams.map { it.height }.filter { it > 0 }
        val cover = listOf("originCover", "cover", "dynamicCover").map { v.optString(it) }.firstOrNull { it.startsWith("http") }
        log("→ TikTok 解析成功：${heights.joinToString("/") { "${it}p" }}")
        val h = HashMap<String, String>()
        h["User-Agent"] = Http.UA_PC
        h["Referer"] = "https://www.tiktok.com/"
        cookie?.let { h["Cookie"] = it }
        return VideoMeta(
            url = page, title = it0.optString("desc").ifBlank { "TikTok 视频" }.lines().first().take(80),
            thumbnail = cover, durationSec = v.optLong("duration"),
            heights = heights, subLangs = emptyList(), streams = streams, headers = h,
        )
    }
}

// ───────────────────────── Facebook ─────────────────────────
// 公开视频页里直接带 HD / SD 的 mp4 地址。需要登录的视频无法获取。

internal object Facebook {
    private val HD = listOf("browser_native_hd_url", "playable_url_quality_hd", "hd_src_no_ratelimit", "hd_src")
    private val SD = listOf("browser_native_sd_url", "playable_url", "sd_src_no_ratelimit", "sd_src")
    private const val BOT_UA = "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"

    private fun grab(html: String, keys: List<String>): String? {
        for (k in keys) {
            val re = Regex("(?:\"" + k + "\"|\\b" + k + "\\b)\\s*[:=]\\s*\"((?:[^\"\\\\]|\\\\.)*)\"")
            for (m in re.findAll(html)) {
                val u = jsonUnescape(m.groupValues[1])
                if (u.startsWith("http")) return u
            }
        }
        return null
    }

    private fun idOf(u: String): String? =
        Regex("""(?:/videos/(?:[\w.-]+/)?|/reel/|/watch/?\?v=|[?&]v=|video_id=|/share/[vr]/)(\d{6,})""").find(u)?.groupValues?.get(1)

    fun resolve(url: String, log: (String) -> Unit): VideoMeta {
        val s = HttpSession()
        val headers = mapOf(
            "User-Agent" to Http.UA_PC, "Accept" to "text/html,application/xhtml+xml",
            "Accept-Language" to "en-US,en;q=0.9", "Sec-Fetch-Mode" to "navigate",
        )
        val r = Http.get(s, url.replace("//m.facebook.com", "//www.facebook.com").replace("//web.facebook.com", "//www.facebook.com"), headers)
        log("→ Facebook 页面 HTTP ${r.code}，${hostOf(url)} → ${hostOf(r.finalUrl)}，${r.body.length} 字节")
        var hd = grab(r.body, HD)
        var sd = grab(r.body, SD)
        var title = metaOf(r.body, "og:title") ?: titleOf(r.body)
        var cover = metaOf(r.body, "og:image")

        // 换几种页面形态再试：标准播放页、旧版 video.php、手机版、嵌入播放器
        if (hd == null && sd == null) {
            val id = idOf(r.finalUrl) ?: idOf(url)
            if (id != null) {
                val canonical = java.net.URLEncoder.encode("https://www.facebook.com/video.php?v=$id", "UTF-8")
                val variants = listOf(
                    "https://www.facebook.com/watch/?v=$id" to Http.UA_PC,
                    "https://www.facebook.com/video.php?v=$id" to Http.UA_PC,
                    "https://m.facebook.com/watch/?v=$id" to Http.UA_MOBILE,
                    "https://www.facebook.com/plugins/video.php?href=$canonical&show_text=false" to Http.UA_PC,
                )
                for ((u, ua) in variants) {
                    val v = runCatching { Http.get(s, u, headers + ("User-Agent" to ua)) }.getOrNull() ?: continue
                    hd = grab(v.body, HD)
                    sd = grab(v.body, SD)
                    log("→ 备用页面 ${hostOf(u)}${u.substringAfter(hostOf(u)).take(24)}：HTTP ${v.code}，${v.body.length} 字节，找到=${hd != null || sd != null}")
                    if (hd != null || sd != null) {
                        if (title.isBlank()) title = metaOf(v.body, "og:title") ?: titleOf(v.body)
                        cover = cover ?: metaOf(v.body, "og:image")
                        break
                    }
                }
            }
        }

        if (hd == null && sd == null) {
            log("→ 页面里没有视频地址，改用分享预览身份再试一次")
            val b = runCatching { Http.get(null, r.finalUrl, mapOf("User-Agent" to BOT_UA)) }.getOrNull()
            if (b != null) {
                log("→ 预览页 HTTP ${b.code}，${b.body.length} 字节")
                sd = listOf("og:video:secure_url", "og:video:url", "og:video")
                    .firstNotNullOfOrNull { metaOf(b.body, it) }?.takeIf { it.startsWith("http") }
                title = metaOf(b.body, "og:title") ?: title
                cover = metaOf(b.body, "og:image") ?: cover
            }
        }
        if (hd == null && sd == null) {
            val body = r.body.lowercase()
            when {
                r.finalUrl.contains("/login") || "login_form" in body || "log in to facebook" in body ->
                    throw ExtractError(Kind.LOGIN, "这个视频需要登录 Facebook 才能查看")
                "this content isn't available" in body || "content isn't available" in body ->
                    throw ExtractError(Kind.REMOVED, "视频不可用，可能已删除或不公开")
                else -> throw ExtractError(Kind.BLOCKED, "没有取到 Facebook 视频地址（可能被平台限制）")
            }
        }

        val streams = ArrayList<Stream>()
        // 页面不给具体分辨率，HD 按 720p、SD 按 360p 标注
        if (hd != null) streams.add(Stream(720, listOf(hd), null))
        if (sd != null && sd != hd) streams.add(Stream(360, listOf(sd), null))
        val heights = streams.map { it.height }
        log("→ Facebook 解析成功：${if (hd != null) "HD " else ""}${if (sd != null) "SD" else ""}")
        return VideoMeta(
            url = r.finalUrl, title = title.ifBlank { "Facebook 视频" }.lines().first().take(80),
            thumbnail = cover?.takeIf { it.startsWith("http") }, durationSec = 0,
            heights = if (streams.size > 1) heights else emptyList(), subLangs = emptyList(), streams = streams,
            headers = mapOf("User-Agent" to Http.UA_PC, "Referer" to "https://www.facebook.com/"),
        )
    }
}

// ───────────────────────── 小红书 ─────────────────────────
// 读笔记页里的 __INITIAL_STATE__，取 video.media.stream；失败时退回 og:video。

internal object Xhs {
    private fun idOf(u: String): String? =
        Regex("""/(?:explore|discovery/item|item|video)/([0-9a-f]{24})""", RegexOption.IGNORE_CASE).find(u)?.groupValues?.get(1)
            ?: Regex("""[?&]noteId=([0-9a-f]{24})""", RegexOption.IGNORE_CASE).find(u)?.groupValues?.get(1)

    /** 分享短链落地页有时只在 HTML/内嵌状态中包含笔记 ID，最终 URL 本身没有 ID。 */
    private fun idFromHtml(html: String): String? {
        val patterns = listOf(
            Regex("""/(?:explore|discovery/item|item|video)/([0-9a-f]{24})""", RegexOption.IGNORE_CASE),
            Regex("""[\"'](?:noteId|note_id|note_id_str)[\"']\s*[:=]\s*[\"']([0-9a-f]{24})[\"']""", RegexOption.IGNORE_CASE),
            Regex("""[?&]noteId=([0-9a-f]{24})""", RegexOption.IGNORE_CASE),
        )
        return patterns.firstNotNullOfOrNull { it.find(html)?.groupValues?.get(1) }
    }

    private fun parseState(html: String): JSONObject? {
        val raw = jsonAfter(html, "__INITIAL_STATE__") ?: return null
        val fixed = raw.replace(Regex("""(?<=[:\[,])\s*undefined(?=\s*[,}\]])"""), "null")
        return runCatching { JSONObject(fixed) }.getOrNull()
    }

    private fun noteOf(root: JSONObject): JSONObject? =
        findObj(root) { it.optJSONObject("video")?.optJSONObject("media") != null && (it.has("title") || it.has("desc")) }

    fun hasImagesOnly(root: JSONObject): Boolean =
        findObj(root) { (it.optJSONArray("imageList")?.length() ?: 0) > 0 && (it.has("title") || it.has("desc")) } != null

    private fun fromNote(page: String, note: JSONObject, log: (String) -> Unit): VideoMeta {
        val video = note.getJSONObject("video")
        val stream = video.optJSONObject("media")?.optJSONObject("stream")
        class Cand(val height: Int, val urls: List<String>, val h264: Boolean, val size: Long)
        val cands = ArrayList<Cand>()
        if (stream != null) for (codec in listOf("h264", "h265", "av1", "h266")) {
            val arr = stream.optJSONArray(codec) ?: continue
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val urls = (listOf(o.optString("masterUrl")) + o.optJSONArray("backupUrls").strs())
                    .filter { it.startsWith("http") }
                if (urls.isEmpty()) continue
                cands.add(Cand(shortSide(o.optInt("width"), o.optInt("height")), urls, codec == "h264", o.optLong("size")))
            }
        }
        if (cands.isEmpty()) throw ExtractError(Kind.OTHER, "小红书数据里没有视频流")

        val originKey = video.optJSONObject("consumer")?.optString("originVideoKey").orEmpty()
        val streams = cands.groupBy { it.height }.map { (h, l) ->
            val sorted = l.sortedWith(compareByDescending<Cand> { it.h264 }.thenByDescending { it.size })
            Stream(h, sorted.flatMap { it.urls }.distinct(), null)
        }.sortedByDescending { it.height }.toMutableList()
        // 无水印原始地址：只对最高档加到最前，失败会自动换后面的
        if (originKey.isNotBlank() && streams.isNotEmpty()) {
            val top = streams[0]
            streams[0] = Stream(top.height, listOf("https://sns-video-bd.xhscdn.com/$originKey") + top.videoUrls, null)
        }
        val heights = streams.map { it.height }.filter { it > 0 }
        val cover = note.optJSONArray("imageList")?.optJSONObject(0)
            ?.let { it.optString("urlDefault").ifBlank { it.optString("urlPre") } }
            ?.let { if (it.startsWith("//")) "https:$it" else it }
            ?.takeIf { it.startsWith("http") }
        val dur = video.optJSONObject("capa")?.optLong("duration")
            ?: video.optJSONObject("media")?.optJSONObject("video")?.optLong("duration") ?: 0L
        log("→ 小红书解析成功：${heights.joinToString("/") { "${it}p" }}")
        return VideoMeta(
            url = page,
            title = note.optString("title").ifBlank { note.optString("desc") }.ifBlank { "小红书视频" }.lines().first().take(80),
            thumbnail = cover, durationSec = if (dur > 1000) dur / 1000 else dur,
            heights = heights, subLangs = emptyList(), streams = streams,
            headers = mapOf("User-Agent" to Http.UA_PC, "Referer" to "https://www.xiaohongshu.com/"),
        )
    }

    suspend fun resolve(ctx: Context, url: String, log: (String) -> Unit): VideoMeta {
        val s = HttpSession()
        val pc = mapOf("User-Agent" to Http.UA_PC, "Accept" to "text/html,application/xhtml+xml")
        var r = Http.get(s, url, pc)
        log("→ 小红书页面 HTTP ${r.code}，${hostOf(url)} → ${hostOf(r.finalUrl)}，${r.body.length} 字节")
        var page = r.finalUrl
        val id = idOf(page) ?: idOf(url) ?: idFromHtml(r.body)
            ?: metaOf(r.body, "og:url")?.let(::idOf)
            ?: throw ExtractError(Kind.UNSUPPORTED, "网页已打开（HTTP ${r.code}），但 URL 和页面内容中都没有找到 24 位笔记编号")
        if (!page.startsWith("http") || r.body.isEmpty() || idOf(page) == null) {
            // 短链落地页可能返回 HTTP 200，但 URL 不是笔记页；根据 HTML 中提取的 ID 规范化为笔记页。
            val token = Regex("""[?&]xsec_token=([^&\"']+)""").find(page)?.groupValues?.get(1)
                ?: Regex("""[?&]xsec_token=([^&\"']+)""").find(url)?.groupValues?.get(1)
                ?: Regex("""[?&]xsec_token=([^&\"']+)""").find(r.body)?.groupValues?.get(1)
            page = "https://www.xiaohongshu.com/explore/$id" + (if (token != null) "?xsec_token=$token&xsec_source=pc_share" else "")
            r = Http.get(s, page, pc)
            log("→ 按笔记编号重新请求网页版 HTTP ${r.code}，${r.body.length} 字节")
        }
        if (r.code == 461 || r.code == 471) throw ExtractError(Kind.BLOCKED, "小红书要求验证，稍后再试")

        var root = parseState(r.body)
        var note = root?.let { noteOf(it) }
        if (note == null) {
            // 换手机身份再取一次：分享链接常常只对手机页放行
            val rm = runCatching { Http.get(s, page, mapOf("User-Agent" to Http.UA_MOBILE)) }.getOrNull()
            if (rm != null) {
                log("→ 手机版页面 HTTP ${rm.code}，${rm.body.length} 字节")
                val rootM = parseState(rm.body)
                val noteM = rootM?.let { noteOf(it) }
                if (noteM != null) { root = rootM; note = noteM; r = rm }
            }
        }
        if (note != null) return fromNote(page, note, log)
        log("→ 页面里没有视频数据；有 __INITIAL_STATE__=${root != null}")

        // 退回 og:video
        val og = metaOf(r.body, "og:video")?.takeIf { it.startsWith("http") }
        if (og != null) {
            log("→ 使用页面的 og:video")
            return VideoMeta(
                url = page, title = (metaOf(r.body, "og:title") ?: titleOf(r.body)).ifBlank { "小红书视频" }
                    .removeSuffix(" - 小红书").take(80),
                thumbnail = metaOf(r.body, "og:image")?.takeIf { it.startsWith("http") }, durationSec = 0,
                heights = emptyList(), subLangs = emptyList(), streams = listOf(Stream(0, listOf(og), null)),
                headers = mapOf("User-Agent" to Http.UA_PC, "Referer" to "https://www.xiaohongshu.com/"),
            )
        }

        log("→ 改用 WebView 打开")
        val got = WebData.evalJson(ctx, page, Http.UA_PC, "window.__INITIAL_STATE__", 25_000L)
        log("→ WebView 结果：${got?.let { "${it.length} 字符" } ?: "空（超时或需要验证）"}")
        val wroot = got?.let { runCatching { JSONObject(it) }.getOrNull() }
        val wnote = wroot?.let { noteOf(it) }
        if (wnote != null) return fromNote(page, wnote, log)
        if (root != null && hasImagesOnly(root) || wroot != null && hasImagesOnly(wroot)) {
            throw ExtractError(Kind.UNSUPPORTED, "这是图文笔记，暂不支持（只支持视频）")
        }
        if (r.body.contains("login", ignoreCase = true) && r.body.length < 5000) {
            throw ExtractError(Kind.BLOCKED, "小红书要求登录或验证，稍后再试")
        }
        throw ExtractError(Kind.BLOCKED, "没有取到小红书视频数据（可能被验证拦截，或链接缺少访问令牌）")
    }
}
