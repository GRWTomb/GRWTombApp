package com.grwtomb.extractor

import android.os.SystemClock
import kotlin.coroutines.AbstractCoroutineContextElement
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.coroutineContext

/**
 * 一次解析的“总截止时间”，放在协程上下文里。
 * 各个兜底步骤（WebView 等）用它来压缩自己的等待时间：时间不够就直接放弃，
 * 保证整个解析一定在预算内给出结果（成功，或者“请稍后再试”）。
 */
class Deadline(val atMs: Long) : AbstractCoroutineContextElement(Deadline) {
    companion object Key : CoroutineContext.Key<Deadline>
}

/** 距离截止还剩多少毫秒；没有设置截止时间时视为无限 */
suspend fun timeLeftMs(): Long {
    val d = coroutineContext[Deadline] ?: return Long.MAX_VALUE
    return d.atMs - SystemClock.elapsedRealtime()
}
