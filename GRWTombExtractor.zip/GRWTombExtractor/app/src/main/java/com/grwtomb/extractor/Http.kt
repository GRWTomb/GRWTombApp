package com.grwtomb.extractor

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** 一次解析过程内共用的简易 Cookie 容器（只存名值，足够 B 站 / 快手这类场景） */
class HttpSession {
    val cookies = LinkedHashMap<String, String>()

    fun header(): String? =
        if (cookies.isEmpty()) null else cookies.entries.joinToString("; ") { "${it.key}=${it.value}" }

    fun store(c: HttpURLConnection) {
        for ((k, v) in c.headerFields) {
            if (k == null || !k.equals("set-cookie", ignoreCase = true)) continue
            for (line in v) {
                val kv = line.substringBefore(';')
                val i = kv.indexOf('=')
                if (i > 0) cookies[kv.substring(0, i).trim()] = kv.substring(i + 1).trim()
            }
        }
    }
}

/** 不依赖任何第三方库的 HTTP 工具：手动跟随重定向、带 Cookie、下载到文件 */
object Http {
    const val UA_PC =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    const val UA_MOBILE =
        "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"

    class Resp(val code: Int, val finalUrl: String, val body: String)

    private class Conn(val c: HttpURLConnection?, val url: String, val code: Int)

    private fun open(url0: String, headers: Map<String, String>, session: HttpSession?): Conn {
        var url = url0
        repeat(10) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 8_000
            c.readTimeout = 15_000
            for ((k, v) in headers) c.setRequestProperty(k, v)
            session?.header()?.let { c.setRequestProperty("Cookie", it) }
            val code = c.responseCode
            session?.store(c)
            if (code !in 300..399 || code == 304) return Conn(c, url, code)

            val loc = c.getHeaderField("Location")?.trim()
            c.disconnect()
            if (loc.isNullOrEmpty()) return Conn(null, url, code)
            val next = runCatching { URL(URL(url), loc).toString() }.getOrDefault(loc)
            // 跳到 App 专用协议（如 snssdk://）时停下，把它当作最终地址返回
            if (!next.startsWith("http", ignoreCase = true)) return Conn(null, next, code)
            url = next
        }
        throw IOException("重定向次数过多")
    }

    /** GET 并返回文本；网络异常、5xx、429 时自动重试一次 */
    fun get(session: HttpSession?, url: String, headers: Map<String, String> = emptyMap()): Resp {
        var last: Throwable? = null
        for (i in 1..2) {
            try {
                val r = getOnce(session, url, headers)
                if (i == 1 && (r.code == 429 || r.code in 500..599)) {
                    Thread.sleep(900)
                    continue
                }
                return r
            } catch (e: IOException) {
                last = e
                if (i == 1) Thread.sleep(700)
            }
        }
        throw last ?: IOException("请求失败")
    }

    /** GET 并返回文本；自动跟随重定向，finalUrl 为最终地址 */
    private fun getOnce(session: HttpSession?, url: String, headers: Map<String, String> = emptyMap()): Resp {
        val h = HashMap<String, String>()
        h["User-Agent"] = UA_PC
        h["Accept"] = "*/*"
        h["Accept-Language"] = "zh-CN,zh;q=0.9,en;q=0.8"
        h.putAll(headers)
        val conn = open(url, h, session)
        val c = conn.c ?: return Resp(conn.code, conn.url, "")
        try {
            val stream = if (conn.code >= 400) c.errorStream else c.inputStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            return Resp(conn.code, conn.url, body)
        } finally {
            c.disconnect()
        }
    }

    /** POST JSON（YouTube InnerTube 用） */
    fun postJson(url: String, json: String, headers: Map<String, String> = emptyMap()): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 8_000
            c.readTimeout = 15_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            return Resp(code, url, body)
        } finally {
            c.disconnect()
        }
    }

    /**
     * 依次尝试多个地址；每个地址换几种请求头再试（原样 → 带 Range → 只留 UA）。
     * validate 用来确认下载到的确实是视频（有些 CDN 会用 200 返回错误页）。
     * onFrac 回报 0..1 的进度。
     */
    fun download(
        urls: List<String>, dest: File, headers: Map<String, String>,
        validate: ((File) -> Boolean)? = null, onFrac: (Float) -> Unit,
    ) {
        var last: Throwable? = null
        val minimal = headers["User-Agent"]?.let { mapOf("User-Agent" to it) } ?: emptyMap()
        val variants = listOf(headers, headers + ("Range" to "bytes=0-"), minimal)
        for (u in urls) {
            for (h in variants) {
                try {
                    downloadOne(u, dest, h, onFrac)
                    if (validate != null && !validate(dest)) throw IOException("下载到的文件不是有效视频")
                    return
                } catch (t: Throwable) {
                    last = t
                    dest.delete()
                    // 地址本身已失效，换请求头也没用
                    if (t.message?.contains("HTTP 404") == true || t.message?.contains("HTTP 410") == true) break
                }
            }
        }
        throw last ?: IOException("没有可用的下载地址")
    }

    /** googlevideo 对一次性拉整个大文件会限速，按 8MB 分段请求 */
    private fun downloadRanged(url: String, dest: File, h: Map<String, String>, onFrac: (Float) -> Unit) {
        val chunk = 8L * 1024 * 1024
        var start = 0L
        var total = -1L
        dest.outputStream().use { out ->
            val buf = ByteArray(64 * 1024)
            while (total < 0 || start < total) {
                val hh = HashMap(h)
                hh["Range"] = "bytes=$start-${start + chunk - 1}"
                val conn = open(url, hh, null)
                val c = conn.c ?: throw IOException("下载地址跳转到了无法打开的协议")
                var got = 0L
                try {
                    if (conn.code !in 200..299) throw IOException("下载失败 HTTP ${conn.code}")
                    if (total < 0) {
                        total = c.getHeaderField("Content-Range")?.substringAfter('/')?.toLongOrNull()
                            ?: c.contentLengthLong
                    }
                    c.inputStream.use { input ->
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            got += n
                            if (total > 0) onFrac(((start + got).toFloat() / total).coerceIn(0f, 1f))
                        }
                    }
                } finally {
                    c.disconnect()
                }
                if (got == 0L || total <= 0) break
                start += got
            }
        }
        if (start == 0L && total <= 0) throw IOException("下载内容为空")
        if (total > 0 && start < total) throw IOException("下载不完整")
    }

    private fun downloadOne(url: String, dest: File, headers: Map<String, String>, onFrac: (Float) -> Unit) {
        val h = HashMap<String, String>()
        h["User-Agent"] = UA_PC
        h["Accept"] = "*/*"
        h.putAll(headers)
        if (url.contains("googlevideo.com")) return downloadRanged(url, dest, h, onFrac)
        val conn = open(url, h, null)
        val c = conn.c ?: throw IOException("下载地址跳转到了无法打开的协议")
        try {
            if (conn.code !in 200..299) throw IOException("下载失败 HTTP ${conn.code}")
            val type = c.contentType.orEmpty().lowercase()
            if (type.startsWith("text/") || type.contains("json")) {
                throw IOException("服务器返回的是网页而不是视频（$type）")
            }
            val total = c.contentLengthLong
            var done = 0L
            c.inputStream.use { input ->
                dest.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) onFrac((done.toFloat() / total).coerceIn(0f, 1f))
                    }
                }
            }
            if (done == 0L) throw IOException("下载内容为空")
        } finally {
            c.disconnect()
        }
    }
}
