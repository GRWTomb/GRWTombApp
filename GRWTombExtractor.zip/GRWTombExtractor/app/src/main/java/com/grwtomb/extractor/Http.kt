package com.grwtomb.extractor

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** 一次解析过程内共用的简易 Cookie 容器（只存名值，足够 B 站 / 快手这类场景） */
class HttpSession {
    val cookies = LinkedHashMap<String, String>()

    fun header(): String? =
        if (cookies.isEmpty()) null else cookies.entries.joinToString("; ") { "${it.key}=${it.value}" }

    fun store(c: HttpURLConnection) {
        for ((k, v) in c.headerFields) {
            if (k == null || !k.equals("set-cookie", ignoreCase = true)) continue
            for (line in v) {
                val kv = line.substringBefore(';')
                val i = kv.indexOf('=')
                if (i > 0) cookies[kv.substring(0, i).trim()] = kv.substring(i + 1).trim()
            }
        }
    }
}

/** 不依赖任何第三方库的 HTTP 工具：手动跟随重定向、带 Cookie、下载到文件 */
object Http {
    const val UA_PC =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    const val UA_MOBILE =
        "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"

    class Resp(val code: Int, val finalUrl: String, val body: String)

    private class Conn(val c: HttpURLConnection?, val url: String, val code: Int)

    private fun open(url0: String, headers: Map<String, String>, session: HttpSession?): Conn {
        var url = url0
        repeat(10) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15_000
            c.readTimeout = 25_000
            for ((k, v) in headers) c.setRequestProperty(k, v)
            session?.header()?.let { c.setRequestProperty("Cookie", it) }
            val code = c.responseCode
            session?.store(c)
            if (code !in 300..399 || code == 304) return Conn(c, url, code)

            val loc = c.getHeaderField("Location")?.trim()
            c.disconnect()
            if (loc.isNullOrEmpty()) return Conn(null, url, code)
            val next = runCatching { URL(URL(url), loc).toString() }.getOrDefault(loc)
            // 跳到 App 专用协议（如 snssdk://）时停下，把它当作最终地址返回
            if (!next.startsWith("http", ignoreCase = true)) return Conn(null, next, code)
            url = next
        }
        throw IOException("重定向次数过多")
    }

    /** GET 并返回文本；自动跟随重定向，finalUrl 为最终地址 */
    fun get(session: HttpSession?, url: String, headers: Map<String, String> = emptyMap()): Resp {
        val h = HashMap<String, String>()
        h["User-Agent"] = UA_PC
        h["Accept"] = "*/*"
        h["Accept-Language"] = "zh-CN,zh;q=0.9,en;q=0.8"
        h.putAll(headers)
        val conn = open(url, h, session)
        val c = conn.c ?: return Resp(conn.code, conn.url, "")
        try {
            val stream = if (conn.code >= 400) c.errorStream else c.inputStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            return Resp(conn.code, conn.url, body)
        } finally {
            c.disconnect()
        }
    }

    /** 依次尝试多个地址（每个重试 2 次），成功即返回；onFrac 回报 0..1 的进度 */
    fun download(urls: List<String>, dest: File, headers: Map<String, String>, onFrac: (Float) -> Unit) {
        var last: Throwable? = null
        for (u in urls) {
            for (attempt in 1..2) {
                try {
                    downloadOne(u, dest, headers, onFrac)
                    return
                } catch (t: Throwable) {
                    last = t
                    dest.delete()
                }
            }
        }
        throw last ?: IOException("没有可用的下载地址")
    }

    private fun downloadOne(url: String, dest: File, headers: Map<String, String>, onFrac: (Float) -> Unit) {
        val h = HashMap<String, String>()
        h["User-Agent"] = UA_PC
        h["Accept"] = "*/*"
        h.putAll(headers)
        val conn = open(url, h, null)
        val c = conn.c ?: throw IOException("下载地址跳转到了无法打开的协议")
        try {
            if (conn.code !in 200..299) throw IOException("下载失败 HTTP ${conn.code}")
            val type = c.contentType.orEmpty().lowercase()
            if (type.startsWith("text/") || type.contains("json")) {
                throw IOException("服务器返回的是网页而不是视频（$type）")
            }
            val total = c.contentLengthLong
            var done = 0L
            c.inputStream.use { input ->
                dest.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) onFrac((done.toFloat() / total).coerceIn(0f, 1f))
                    }
                }
            }
            if (done == 0L) throw IOException("下载内容为空")
        } finally {
            c.disconnect()
        }
    }
}
