package com.grwtomb.extractor

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * 为当前链接建立独立、匿名的 WebView 会话，让平台正常下发公开网页所需的会话 Cookie。
 * 不读取其他 App 的 Cookie，也不导入用户账号凭据。
 */
object CookieBridge {
    suspend fun obtain(ctx: Context, url: String): String? = withContext(Dispatchers.Main) {
        withTimeoutOrNull(15_000L) {
            suspendCancellableCoroutine<String?> { cont ->
                var web: WebView? = null
                try {
                    val view = WebView(ctx.applicationContext)
                    web = view
                    view.settings.javaScriptEnabled = true
                    view.settings.domStorageEnabled = true
                    view.webViewClient = object : WebViewClient() {
                        private var finished = false
                        override fun onPageFinished(v: WebView, pageUrl: String?) {
                            if (finished) return
                            finished = true
                            runCatching { CookieManager.getInstance().flush() }
                            val cookie = runCatching { CookieManager.getInstance().getCookie(url) }
                                .getOrNull()?.takeIf { it.isNotBlank() }
                            if (cont.isActive) cont.resume(cookie)
                        }
                    }
                    view.loadUrl(url)
                    cont.invokeOnCancellation { view.post { view.stopLoading(); view.destroy() } }
                } catch (_: Throwable) {
                    runCatching { web?.destroy() }
                    if (cont.isActive) cont.resume(null)
                }
            }
        }
    }
}
