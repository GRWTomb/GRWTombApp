package com.grwtomb.extractor

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.net.URI
import java.util.LinkedHashSet
import kotlin.coroutines.resume

/**
 * 建立短暂的本应用 WebView 网页会话，并把 WebView 可见的 Cookie 导出为临时 Netscape cookie jar。
 * 只读取本应用 WebView 的 Cookie；不读取其他 App 的数据，也不尝试绕过登录或平台验证。
 * Android CookieManager 不公开 Cookie 的原始 Domain/Path/Expires 元数据，因此导出时
 * 采用已访问主机的 host-only、HTTPS Cookie 记录；不能保证还原平台未公开的全部验证状态。
 */
object CookieBridge {
    data class Session(
        private val cookieFile: File?,
        val userAgent: String?,
        val referer: String,
        val cookieCount: Int,
    ) : AutoCloseable {
        fun applyTo(request: com.yausername.youtubedl_android.YoutubeDLRequest) {
            cookieFile?.takeIf { it.exists() && it.length() > 0L }?.let {
                request.addOption("--cookies", it.absolutePath)
            }
            userAgent?.takeIf { it.isNotBlank() }?.let {
                request.addOption("--user-agent", it)
            }
            referer.takeIf { it.startsWith("https://") }?.substringBefore('?')?.substringBefore('#')?.let {
                request.addOption("--referer", it)
            }
        }

        override fun close() {
            runCatching { cookieFile?.delete() }
        }
    }

    suspend fun obtain(ctx: Context, url: String): Session = withContext(Dispatchers.Main) {
        val app = ctx.applicationContext
        val result = withTimeoutOrNull(18_000L) {
            suspendCancellableCoroutine<Session?> { cont ->
                var web: WebView? = null
                val handler = Handler(Looper.getMainLooper())
                val visited = java.util.Collections.synchronizedSet(LinkedHashSet<String>())
                var pending: Runnable? = null
                var userAgent: String? = null

                fun remember(candidate: String?) {
                    val value = candidate?.takeIf { it.startsWith("https://", ignoreCase = true) } ?: return
                    synchronized(visited) {
                        if (visited.size < 80) visited.add(value)
                    }
                }

                fun cleanup(view: WebView?) {
                    pending?.let { handler.removeCallbacks(it) }
                    runCatching { view?.stopLoading() }
                    runCatching { view?.destroy() }
                }

                fun finish(view: WebView) {
                    if (!cont.isActive) return
                    runCatching { CookieManager.getInstance().flush() }
                    val rows = LinkedHashSet<String>()
                    val pages = synchronized(visited) { visited.toList() }
                    for (page in pages) {
                        val host = runCatching { URI(page).host?.lowercase() }.getOrNull() ?: continue
                        val raw = runCatching { CookieManager.getInstance().getCookie(page) }.getOrNull()
                            ?: continue
                        raw.split(';').forEach { part ->
                            val item = part.trim()
                            val split = item.indexOf('=')
                            if (split <= 0) return@forEach
                            val name = item.substring(0, split).trim()
                            val value = item.substring(split + 1).trim()
                            if (name.isEmpty() || name.any { it == '\t' || it == '\r' || it == '\n' } ||
                                value.any { it == '\t' || it == '\r' || it == '\n' }) return@forEach
                            // 每个实际访问到的主机单独记录；不会把一个域名的 Cookie 发给无关域名。
                            rows.add("$host\tFALSE\t/\tTRUE\t0\t$name\t$value")
                        }
                    }

                    val file = if (rows.isNotEmpty()) runCatching {
                        val candidate = File(app.cacheDir, "web-session-${System.nanoTime()}.cookies")
                        candidate.writeText("# Netscape HTTP Cookie File\n" + rows.joinToString("\n") + "\n")
                        val valid = candidate.isFile && candidate.length() > 32L &&
                            candidate.readLines().count { line -> line.isNotBlank() && !line.startsWith("#") } == rows.size
                        if (valid) candidate else {
                            candidate.delete()
                            null
                        }
                    }.getOrNull() else null

                    val session = Session(file, userAgent, url, if (file != null) rows.size else 0)
                    cleanup(view)
                    if (cont.isActive) cont.resume(session)
                }

                try {
                    val view = WebView(app)
                    web = view
                    view.settings.javaScriptEnabled = true
                    view.settings.domStorageEnabled = true
                    userAgent = view.settings.userAgentString
                    remember(url)
                    view.webViewClient = object : WebViewClient() {
                        override fun onPageStarted(v: WebView, pageUrl: String?, favicon: android.graphics.Bitmap?) {
                            remember(pageUrl)
                            pending?.let { handler.removeCallbacks(it) }
                            pending = null
                        }

                        override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                            remember(request.url.toString())
                            return false
                        }

                        override fun shouldInterceptRequest(v: WebView, request: WebResourceRequest): WebResourceResponse? {
                            // 同时记录页面实际请求过的 API/CDN 子域；Cookie 仍按各自主机隔离。
                            remember(request.url.toString())
                            return null
                        }

                        @Suppress("DEPRECATION")
                        override fun shouldOverrideUrlLoading(v: WebView, pageUrl: String): Boolean {
                            remember(pageUrl)
                            return false
                        }

                        override fun onPageFinished(v: WebView, pageUrl: String?) {
                            remember(pageUrl)
                            pending?.let { handler.removeCallbacks(it) }
                            // 等待页面脚本/重定向后的 Cookie 写入，而不是第一次 onPageFinished 就立即读取。
                            val task = Runnable { finish(v) }
                            pending = task
                            handler.postDelayed(task, 1_800L)
                        }
                    }
                    view.loadUrl(url)
                    cont.invokeOnCancellation { handler.post { cleanup(web) } }
                } catch (_: Throwable) {
                    cleanup(web)
                    if (cont.isActive) cont.resume(Session(null, userAgent, url, 0))
                }
            }
        }
        result ?: Session(null, null, url, 0)
    }
}
