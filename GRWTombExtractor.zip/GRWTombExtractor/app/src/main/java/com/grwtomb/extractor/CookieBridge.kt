package com.grwtomb.extractor

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.net.URI
import java.util.LinkedHashSet
import kotlin.coroutines.resume

/**
 * 建立短暂的本应用 WebView 网页会话，并把 WebView 可见的 Cookie 导出为临时 Netscape cookie jar。
 * 只读取本应用 WebView 的 Cookie；不读取其他 App 的数据，也不尝试绕过登录或平台验证。
 * Android CookieManager 不公开 Cookie 的原始 Domain/Path/Expires 元数据，因此导出时
 * 采用已访问主机的 host-only、HTTPS Cookie 记录；不能保证还原平台未公开的全部验证状态。
 */
object CookieBridge {
    data class Session(
        private val cookieFile: File?,
        val userAgent: String?,
        val referer: String,
        val cookieCount: Int,
        val resolvedUrl: String,
    ) : AutoCloseable {
        fun applyTo(request: com.yausername.youtubedl_android.YoutubeDLRequest) {
            cookieFile?.takeIf { it.exists() && it.length() > 0L }?.let {
                request.addOption("--cookies", it.absolutePath)
            }
            userAgent?.takeIf { it.isNotBlank() }?.let {
                request.addOption("--user-agent", it)
            }
            referer.takeIf { it.startsWith("https://") }?.substringBefore('?')?.substringBefore('#')?.let {
                request.addOption("--referer", it)
            }
        }

        override fun close() {
            runCatching { cookieFile?.delete() }
        }
    }

    suspend fun obtain(ctx: Context, url: String): Session = withContext(Dispatchers.Main) {
        val app = ctx.applicationContext
        val result = withTimeoutOrNull(25_000L) {
            suspendCancellableCoroutine<Session?> { cont ->
                var web: WebView? = null
                val handler = Handler(Looper.getMainLooper())
                val visited = java.util.Collections.synchronizedSet(LinkedHashSet<String>())
                var pending: Runnable? = null
                var userAgent: String? = null
                var loadStartedAt = android.os.SystemClock.elapsedRealtime()
                var lastObservedUrl = url
                var stableSince = 0L

                fun remember(candidate: String?) {
                    val value = candidate?.takeIf { it.startsWith("https://", ignoreCase = true) } ?: return
                    synchronized(visited) {
                        if (visited.size < 80) visited.add(value)
                    }
                }

                fun cleanup(view: WebView?) {
                    pending?.let { handler.removeCallbacks(it) }
                    runCatching { view?.stopLoading() }
                    runCatching { view?.destroy() }
                }

                fun finish(view: WebView) {
                    if (!cont.isActive) return
                    runCatching { CookieManager.getInstance().flush() }
                    val rows = LinkedHashSet<String>()
                    val pages = synchronized(visited) { visited.toList() }
                    for (page in pages) {
                        val host = runCatching { URI(page).host?.lowercase() }.getOrNull() ?: continue
                        val raw = runCatching { CookieManager.getInstance().getCookie(page) }.getOrNull()
                            ?: continue
                        raw.split(';').forEach { part ->
                            val item = part.trim()
                            val split = item.indexOf('=')
                            if (split <= 0) return@forEach
                            val name = item.substring(0, split).trim()
                            val value = item.substring(split + 1).trim()
                            if (name.isEmpty() || name.any { it == '\t' || it == '\r' || it == '\n' } ||
                                value.any { it == '\t' || it == '\r' || it == '\n' }) return@forEach
                            // 每个实际访问到的主机单独记录；不会把一个域名的 Cookie 发给无关域名。
                            rows.add("$host\tFALSE\t/\tTRUE\t0\t$name\t$value")
                        }
                    }

                    val file = if (rows.isNotEmpty()) runCatching {
                        val candidate = File(app.cacheDir, "web-session-${System.nanoTime()}.cookies")
                        candidate.writeText("# Netscape HTTP Cookie File\n" + rows.joinToString("\n") + "\n")
                        val valid = candidate.isFile && candidate.length() > 32L &&
                            candidate.readLines().count { line -> line.isNotBlank() && !line.startsWith("#") } == rows.size
                        if (valid) candidate else {
                            candidate.delete()
                            null
                        }
                    }.getOrNull() else null

                    // WebView 会自动跟随 v.douyin.com 等分享短链的跳转；
                    // 取最终页面地址交给解析器，而不是把短链原样交给 yt-dlp。
                    val finalUrl = lastObservedUrl
                        .takeIf { it.startsWith("https://", ignoreCase = true) }
                        ?: runCatching { view.url }.getOrNull()
                            ?.takeIf { it.startsWith("https://", ignoreCase = true) }
                        ?: url
                    remember(finalUrl)
                    val session = Session(file, userAgent, finalUrl, if (file != null) rows.size else 0, finalUrl)
                    cleanup(view)
                    if (cont.isActive) cont.resume(session)
                }

                try {
                    val view = WebView(app)
                    web = view
                    view.settings.javaScriptEnabled = true
                    view.settings.domStorageEnabled = true
                    userAgent = view.settings.userAgentString
                    remember(url)
                    fun pollRedirect(v: WebView) {
                        if (!cont.isActive) return
                        val current = runCatching { v.url }.getOrNull()
                        if (!current.isNullOrBlank() && current.startsWith("https://", ignoreCase = true)) {
                            remember(current)
                            lastObservedUrl = current
                        }
                        val elapsed = android.os.SystemClock.elapsedRealtime() - loadStartedAt
                        val currentHost = lastObservedUrl.let { runCatching { URI(it).host?.lowercase()?.removePrefix("www.") }.getOrNull() }
                        val originalHost = runCatching { URI(url).host?.lowercase()?.removePrefix("www.") }.getOrNull()
                        val leftShortDomain = originalHost == "v.douyin.com" && currentHost != null && currentHost != "v.douyin.com"
                        val now = android.os.SystemClock.elapsedRealtime()
                        if (leftShortDomain) {
                            if (stableSince == 0L) stableSince = now
                            // 等待跳转后的页面稳定，避免刚到中间页就交给解析器。
                            if (now - stableSince >= 1_200L) {
                                finish(v)
                                return
                            }
                        } else {
                            stableSince = 0L
                        }
                        if (elapsed >= 12_000L) {
                            finish(v)
                            return
                        }
                        val task = Runnable { pollRedirect(v) }
                        pending = task
                        handler.postDelayed(task, 500L)
                    }

                    view.webViewClient = object : WebViewClient() {
                        override fun onPageStarted(v: WebView, pageUrl: String?, favicon: android.graphics.Bitmap?) {
                            remember(pageUrl)
                            if (!pageUrl.isNullOrBlank() && pageUrl.startsWith("https://", ignoreCase = true)) lastObservedUrl = pageUrl
                            loadStartedAt = android.os.SystemClock.elapsedRealtime()
                            stableSince = 0L
                            pending?.let { handler.removeCallbacks(it) }
                            pending = null
                        }

                        override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                            remember(request.url.toString())
                            return false
                        }

                        override fun shouldInterceptRequest(v: WebView, request: WebResourceRequest): WebResourceResponse? {
                            // 同时记录页面实际请求过的 API/CDN 子域；Cookie 仍按各自主机隔离。
                            remember(request.url.toString())
                            return null
                        }

                        @Suppress("DEPRECATION")
                        override fun shouldOverrideUrlLoading(v: WebView, pageUrl: String): Boolean {
                            remember(pageUrl)
                            return false
                        }

                        override fun onPageFinished(v: WebView, pageUrl: String?) {
                            remember(pageUrl)
                            if (!pageUrl.isNullOrBlank() && pageUrl.startsWith("https://", ignoreCase = true)) lastObservedUrl = pageUrl
                            pending?.let { handler.removeCallbacks(it) }
                            // 抖音短链可能先加载中间页，再由脚本延迟跳转。
                            // 持续观察 WebView 当前 URL，直到离开短链域名并稳定，最长等待 12 秒。
                            val task = Runnable { pollRedirect(v) }
                            pending = task
                            handler.postDelayed(task, 500L)
                        }
                    }
                    view.loadUrl(url)
                    cont.invokeOnCancellation { handler.post { cleanup(web) } }
                } catch (_: Throwable) {
                    cleanup(web)
                    if (cont.isActive) cont.resume(Session(null, userAgent, url, 0, url))
                }
            }
        }
        result ?: Session(null, null, url, 0, url)
    }
}
