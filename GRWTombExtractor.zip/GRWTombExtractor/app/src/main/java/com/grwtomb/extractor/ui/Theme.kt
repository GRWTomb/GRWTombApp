package com.grwtomb.extractor.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// 冷色极简：雾白 / 深海蓝灰底，一个青蓝主色
private val Light = lightColorScheme(
    primary = Color(0xFF2F7D9A),
    onPrimary = Color.White,
    background = Color(0xFFF5F8FA),
    onBackground = Color(0xFF0F1A22),
    surface = Color(0xFFF5F8FA),
    onSurface = Color(0xFF0F1A22),
    surfaceVariant = Color(0xFFEAF0F4),
    onSurfaceVariant = Color(0xFF5B6B78),
    secondaryContainer = Color(0xFFD6E9F1),
    onSecondaryContainer = Color(0xFF1D5F78),
    outline = Color(0xFFC3D1DA),
    outlineVariant = Color(0xFFDCE5EB),
    error = Color(0xFFB4483C),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF7CC4DC),
    onPrimary = Color(0xFF07161C),
    background = Color(0xFF0B1217),
    onBackground = Color(0xFFE6EDF1),
    surface = Color(0xFF0B1217),
    onSurface = Color(0xFFE6EDF1),
    surfaceVariant = Color(0xFF142029),
    onSurfaceVariant = Color(0xFF91A2AE),
    secondaryContainer = Color(0xFF1B3542),
    onSecondaryContainer = Color(0xFFBFE6F3),
    outline = Color(0xFF2B3C48),
    outlineVariant = Color(0xFF1F2E38),
    error = Color(0xFFE8998F),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        content = content,
    )
}
