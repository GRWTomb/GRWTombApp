package com.grwtomb.extractor.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// 白底 + 一个主色
private val Accent = Color(0xFF2563EB)

private val Light = lightColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    background = Color.White,
    onBackground = Color(0xFF111827),
    surface = Color.White,
    onSurface = Color(0xFF111827),
    surfaceVariant = Color(0xFFF3F5F8),
    onSurfaceVariant = Color(0xFF6B7280),
    secondaryContainer = Color(0xFFE5EDFF),
    onSecondaryContainer = Color(0xFF1D4ED8),
    outline = Color(0xFFD7DCE3),
    outlineVariant = Color(0xFFE6E9EE),
    error = Color(0xFFD92D20),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF6B9BFF),
    onPrimary = Color(0xFF0B1220),
    background = Color(0xFF0E1116),
    onBackground = Color(0xFFE8EAEE),
    surface = Color(0xFF0E1116),
    onSurface = Color(0xFFE8EAEE),
    surfaceVariant = Color(0xFF1A1F27),
    onSurfaceVariant = Color(0xFF9AA3B2),
    secondaryContainer = Color(0xFF1E2A44),
    onSecondaryContainer = Color(0xFFB9CCFF),
    outline = Color(0xFF2E3541),
    outlineVariant = Color(0xFF232A34),
    error = Color(0xFFFF8A80),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        content = content,
    )
}
