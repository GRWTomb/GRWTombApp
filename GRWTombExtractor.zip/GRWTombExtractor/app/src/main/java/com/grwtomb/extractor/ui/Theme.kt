package com.grwtomb.extractor.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// 纯白为主：蓝绿只作为极淡的辅助色
private val Light = lightColorScheme(
    primary = Color(0xFF568D91),
    onPrimary = Color.White,
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF182224),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF182224),
    surfaceVariant = Color(0xFFFAFCFB),
    onSurfaceVariant = Color(0xFF687775),
    secondaryContainer = Color(0xFFF2F8F6),
    onSecondaryContainer = Color(0xFF456C68),
    outline = Color(0xFFE5ECE9),
    outlineVariant = Color(0xFFF0F3F2),
    error = Color(0xFFB4483C),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Light,
        content = content,
    )
}
