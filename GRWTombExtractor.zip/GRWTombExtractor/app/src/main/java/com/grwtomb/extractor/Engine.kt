package com.grwtomb.extractor

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.coroutines.cancellation.CancellationException
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * 自研解析层（不再使用 yt-dlp）：
 *  - B 站：公开 Web 接口（WBI 签名）→ DASH 音视频流，本地合并
 *  - 抖音：分享页内嵌的 _ROUTER_DATA；取不到时用 WebView 兜底
 *  - 快手：分享页内嵌的 INIT_STATE；取不到时用 WebView 兜底
 *  - YouTube / X / TikTok / Facebook / 小红书：见 Platforms.kt
 *  - 其他：尝试读取网页里的 og:video
 */
object Engine {
    suspend fun resolve(ctx: Context, url: String, log: (String) -> Unit): VideoMeta =
        withContext(Dispatchers.IO) {
            val h = hostOf(url)
            // 抖音经常临时失败（风控、页面没加载出来），多试几次；其他平台只在网络/风控类错误时多试一次
            val douyin = h.endsWith("douyin.com")
            val attempts = if (douyin) 3 else 2
            var last: Throwable? = null
            for (i in 1..attempts) {
                try {
                    return@withContext once(ctx, url, h, log)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    last = e
                    val k = classify(e)
                    val retry = k == Kind.NETWORK || k == Kind.BLOCKED || (douyin && k == Kind.OTHER)
                    if (!retry || i == attempts) break
                    log("→ 第 $i 次失败：${e.message?.take(80)}，自动重试")
                    delay(1500L * i)
                }
            }
            // 常规解析都失败了：最后用 WebView 打开页面，直接抓它实际播放的视频地址
            val err = last ?: ExtractError(Kind.OTHER, "解析失败")
            val k = classify(err)
            val known = isKnown(h)
            if (k == Kind.BLOCKED || k == Kind.OTHER || k == Kind.NETWORK || (k == Kind.UNSUPPORTED && !known)) {
                val m = runCatching { sniffMeta(ctx, url, h, log) }.getOrNull()
                if (m != null) return@withContext m
            }
            throw err
        }

    private fun isKnown(h: String): Boolean =
        h.endsWith("bilibili.com") || h == "b23.tv" || h.endsWith("douyin.com") || h.endsWith("kuaishou.com") ||
            h.endsWith("chenzhongtech.com") || h.endsWith("gifshow.com") || h == "youtu.be" || h.endsWith("youtube.com") ||
            h == "x.com" || h.endsWith(".x.com") || h.endsWith("twitter.com") || h == "t.co" || h.endsWith("tiktok.com") ||
            h.endsWith("facebook.com") || h == "fb.watch" || h.endsWith("fb.com") ||
            h.endsWith("xiaohongshu.com") || h.endsWith("xhslink.com")

    private suspend fun sniffMeta(ctx: Context, url: String, h: String, log: (String) -> Unit): VideoMeta? {
        // YouTube / B 站是分离的音视频流，嗅探拿不到完整文件，不走这条路
        if (h == "youtu.be" || h.endsWith("youtube.com") || h.endsWith("bilibili.com") || h == "b23.tv") return null
        var target = url
        var ua = Http.UA_PC
        when {
            h == "x.com" || h.endsWith(".x.com") || h.endsWith("twitter.com") || h == "t.co" -> {
                val id = Regex("""/status(?:es)?/(\d{5,})""").find(url)?.groupValues?.get(1) ?: return null
                target = "https://platform.twitter.com/embed/Tweet.html?id=$id"
            }
            h.endsWith("douyin.com") -> {
                Regex("""/video/(\d{8,})""").find(url)?.groupValues?.get(1)?.let {
                    target = "https://www.iesdouyin.com/share/video/$it/"
                }
                ua = Http.UA_MOBILE
            }
            h.endsWith("kuaishou.com") || h.endsWith("chenzhongtech.com") || h.endsWith("gifshow.com") -> ua = Http.UA_MOBILE
        }
        log("→ 常规解析失败，改用 WebView 抓取视频地址")
        val sn = WebData.sniff(ctx, target, ua, 28_000L)
        log("→ 抓取结果：${sn?.urls?.size ?: 0} 个地址")
        if (sn == null) return null
        val origin = runCatching { java.net.URI(target).let { "${it.scheme}://${it.host}/" } }.getOrDefault(target)
        val headers = HashMap<String, String>()
        headers["User-Agent"] = ua
        headers["Referer"] = origin
        sn.cookie?.let { headers["Cookie"] = it }
        val title = (sn.title ?: "").replace(Regex("""\s*[-|]\s*(抖音|TikTok|快手|小红书|Facebook|X)\s*$"""), "").trim()
            .ifBlank { "视频" }.take(80)
        return VideoMeta(
            url = url, title = title, thumbnail = sn.poster, durationSec = 0,
            heights = emptyList(), subLangs = emptyList(),
            streams = listOf(Stream(0, sn.urls, null)), headers = headers,
        )
    }

    private suspend fun once(ctx: Context, url: String, h: String, log: (String) -> Unit): VideoMeta = when {
        h.endsWith("bilibili.com") || h == "b23.tv" -> Bili.resolve(url, log)
        h.endsWith("douyin.com") -> Douyin.resolve(ctx, url, log)
        h.endsWith("kuaishou.com") || h.endsWith("chenzhongtech.com") || h.endsWith("gifshow.com") ->
            Kuaishou.resolve(ctx, url, log)
        h == "youtu.be" || h.endsWith("youtube.com") -> YouTube.resolve(url, log)
        h == "x.com" || h.endsWith(".x.com") || h.endsWith("twitter.com") || h == "t.co" -> Twitter.resolve(url, log)
        h.endsWith("tiktok.com") -> TikTok.resolve(ctx, url, log)
        h.endsWith("facebook.com") || h == "fb.watch" || h.endsWith("fb.com") -> Facebook.resolve(url, log)
        h.endsWith("xiaohongshu.com") || h.endsWith("xhslink.com") -> Xhs.resolve(ctx, url, log)
        else -> Generic.resolve(url, log)
    }
}

// ───────────────────────── 公共小工具 ─────────────────────────

/** 取 marker 之后第一个完整的 {...} JSON 对象（按括号配对，识别字符串里的括号） */
internal fun jsonAfter(text: String, marker: String): String? {
    val m = text.indexOf(marker)
    if (m < 0) return null
    val s = text.indexOf('{', m)
    if (s < 0) return null
    var depth = 0
    var inStr = false
    var esc = false
    for (i in s until text.length) {
        val c = text[i]
        if (inStr) {
            if (esc) esc = false else if (c == '\\') esc = true else if (c == '"') inStr = false
        } else when (c) {
            '"' -> inStr = true
            '{' -> depth++
            '}' -> {
                depth--
                if (depth == 0) return text.substring(s, i + 1)
            }
        }
    }
    return null
}

internal fun findObj(o: Any?, depth: Int = 0, pred: (JSONObject) -> Boolean): JSONObject? {
    if (depth > 14) return null
    when (o) {
        is JSONObject -> {
            if (pred(o)) return o
            for (k in o.keys()) findObj(o.opt(k), depth + 1, pred)?.let { return it }
        }
        is JSONArray -> {
            for (i in 0 until o.length()) findObj(o.opt(i), depth + 1, pred)?.let { return it }
        }
    }
    return null
}

private fun JSONArray?.strings(): List<String> {
    if (this == null) return emptyList()
    return (0 until length()).mapNotNull { optString(it).takeIf { s -> s.startsWith("http") } }
}

private fun titleTag(html: String): String =
    Regex("""<title[^>]*>([^<]*)</title>""", RegexOption.IGNORE_CASE).find(html)?.groupValues?.get(1)?.trim().orEmpty()

private fun looksLikeCaptcha(html: String): Boolean =
    listOf("captcha", "验证码", "滑动验证", "verify.snssdk", "slide to verify").any { html.contains(it, ignoreCase = true) }

// ───────────────────────── B 站 ─────────────────────────

private object Bili {
    private val MIXIN = intArrayOf(
        46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39,
        12, 38, 41, 13, 37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63,
        57, 62, 11, 36, 20, 34, 44, 52,
    )
    private val PC = mapOf(
        "User-Agent" to Http.UA_PC,
        "Referer" to "https://www.bilibili.com/",
        "Accept-Language" to "zh-CN,zh;q=0.9",
    )

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun query(p: Map<String, String>) = p.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }

    private fun sign(p: Map<String, String>, key: String): String {
        val m = HashMap(p)
        m["wts"] = (System.currentTimeMillis() / 1000).toString()
        val q = m.toSortedMap().entries.joinToString("&") {
            "${enc(it.key)}=${enc(it.value.filter { c -> c !in "!'()*" })}"
        }
        val md5 = MessageDigest.getInstance("MD5").digest((q + key).toByteArray())
            .joinToString("") { "%02x".format(it) }
        return "$q&w_rid=$md5"
    }

    private fun wbiKey(s: HttpSession): String? {
        val r = Http.get(s, "https://api.bilibili.com/x/web-interface/nav", PC)
        val w = JSONObject(r.body).optJSONObject("data")?.optJSONObject("wbi_img") ?: return null
        fun part(k: String) = w.optString(k).substringAfterLast('/').substringBefore('.')
        val raw = part("img_url") + part("sub_url")
        if (raw.length < 64) return null
        return MIXIN.map { raw[it] }.joinToString("").take(32)
    }

    private fun qnToHeight(qn: Int) = when (qn) {
        6 -> 240; 16 -> 360; 32 -> 480; 64, 74 -> 720
        80, 112, 116, 125, 126 -> 1080; 120 -> 2160; 127 -> 4320
        else -> 0
    }

    private fun urlsOf(o: JSONObject): List<String> {
        val out = ArrayList<String>()
        o.optString("baseUrl").ifBlank { o.optString("base_url") }.takeIf { it.startsWith("http") }?.let(out::add)
        (o.optJSONArray("backupUrl") ?: o.optJSONArray("backup_url")).strings().forEach(out::add)
        return out.distinct()
    }

    private fun playData(s: HttpSession, bvid: String, cid: Long, extra: Map<String, String>, wbi: String?, log: (String) -> Unit): JSONObject? {
        val base = mapOf("bvid" to bvid, "cid" to cid.toString()) + extra
        val tries = ArrayList<String>()
        if (wbi != null) tries.add("https://api.bilibili.com/x/player/wbi/playurl?" + sign(base, wbi))
        tries.add("https://api.bilibili.com/x/player/playurl?" + query(base))
        for (u in tries) {
            val r = runCatching { Http.get(s, u, PC) }.getOrNull() ?: continue
            val j = runCatching { JSONObject(r.body) }.getOrNull()
            if (j == null) { log("playurl HTTP ${r.code}（不是 JSON）"); continue }
            if (j.optInt("code") == 0) return j.optJSONObject("data")
            log("playurl code=${j.optInt("code")} ${j.optString("message")}")
        }
        return null
    }

    fun resolve(url: String, log: (String) -> Unit): VideoMeta {
        val s = HttpSession()
        fun bv(u: String) = Regex("""BV[0-9A-Za-z]{10}""").find(u)?.value
        fun av(u: String) = Regex("""(?i)/video/av(\d+)""").find(u)?.groupValues?.get(1)
        fun pOf(u: String) = Regex("""[?&]p=(\d+)""").find(u)?.groupValues?.get(1)?.toIntOrNull() ?: 1

        var bvid = bv(url)
        var aid = av(url)
        var p = pOf(url)
        if (bvid == null && aid == null) {
            val r = Http.get(s, url, mapOf("User-Agent" to Http.UA_MOBILE))
            log("→ 短链已展开：${hostOf(url)} → ${hostOf(r.finalUrl)}")
            bvid = bv(r.finalUrl); aid = av(r.finalUrl); p = pOf(r.finalUrl)
        }
        if (bvid == null && aid == null) throw ExtractError(Kind.UNSUPPORTED, "链接里没有找到 B 站视频编号（BV号）")

        // 先取游客 Cookie（buvid3/4），不带它接口常返回 403/412
        runCatching {
            val spi = JSONObject(Http.get(s, "https://api.bilibili.com/x/frontend/finger/spi", PC).body).optJSONObject("data")
            spi?.optString("b_3")?.takeIf { it.isNotBlank() }?.let { s.cookies["buvid3"] = it }
            spi?.optString("b_4")?.takeIf { it.isNotBlank() }?.let { s.cookies["buvid4"] = it }
        }
        log("→ 游客 Cookie：${s.cookies.size} 条")

        val viewUrl = "https://api.bilibili.com/x/web-interface/view?" + if (bvid != null) "bvid=$bvid" else "aid=$aid"
        val vr = Http.get(s, viewUrl, PC)
        val vj = runCatching { JSONObject(vr.body) }.getOrNull()
            ?: throw ExtractError(if (vr.code in 400..499) Kind.BLOCKED else Kind.OTHER, "B 站接口返回 HTTP ${vr.code}")
        val code = vj.optInt("code")
        if (code != 0) {
            val msg = vj.optString("message")
            throw when (code) {
                -404, 62002, 62004, 62012 -> ExtractError(Kind.REMOVED, "视频不可用：$msg")
                -352, -412, -799 -> ExtractError(Kind.BLOCKED, "B 站风控 code=$code $msg")
                else -> ExtractError(Kind.OTHER, "B 站接口 code=$code $msg")
            }
        }
        val d = vj.getJSONObject("data")
        val bid: String = d.optString("bvid").ifBlank { bvid.orEmpty() }
        val pages = d.optJSONArray("pages")
        val page = pages?.optJSONObject((p - 1).coerceAtLeast(0))
        val cid = page?.optLong("cid", 0L)?.takeIf { it > 0 } ?: d.optLong("cid")
        var title = d.optString("title").ifBlank { "bilibili" }
        if ((pages?.length() ?: 0) > 1) title += " P$p ${page?.optString("part").orEmpty()}".trimEnd()
        val thumb = d.optString("pic").takeIf { it.startsWith("http") }?.replace("http://", "https://")
        val dur = d.optLong("duration")

        val wbi = runCatching { wbiKey(s) }.getOrNull()
        log(if (wbi != null) "→ WBI 签名已就绪" else "→ WBI 密钥获取失败，改用无签名接口")

        val dashData = playData(
            s, bid, cid,
            mapOf("qn" to "127", "fnval" to "4048", "fnver" to "0", "fourk" to "1", "try_look" to "1"),
            wbi, log,
        )
        val html5Data = playData(
            s, bid, cid,
            mapOf("qn" to "64", "fnval" to "0", "fnver" to "0", "platform" to "html5", "high_quality" to "1"),
            wbi, log,
        )
        val fallbackUrl = html5Data?.optJSONArray("durl")?.optJSONObject(0)?.optString("url")
            ?.takeIf { it.startsWith("http") }

        val streams = ArrayList<Stream>()
        val dash = dashData?.optJSONObject("dash")
        if (dash != null) {
            val audios = dash.optJSONArray("audio")
            var bestAudio: JSONObject? = null
            if (audios != null) for (i in 0 until audios.length()) {
                val a = audios.getJSONObject(i)
                if (bestAudio == null || a.optLong("bandwidth") > bestAudio.optLong("bandwidth")) bestAudio = a
            }
            val audioUrls = bestAudio?.let { urlsOf(it) }?.takeIf { it.isNotEmpty() }
            val vids = dash.optJSONArray("video")
            val byHeight = LinkedHashMap<Int, JSONObject>()
            if (vids != null) for (i in 0 until vids.length()) {
                val v = vids.getJSONObject(i)
                val h = v.optInt("height").takeIf { it > 0 } ?: qnToHeight(v.optInt("id"))
                val cur = byHeight[h]
                // 优先 H.264(7)：兼容性最好；其次 HEVC(12)；AV1(13) 最后
                fun rank(o: JSONObject) = when (o.optInt("codecid")) { 7 -> 0; 12 -> 1; else -> 2 }
                if (cur == null || rank(v) < rank(cur) || (rank(v) == rank(cur) && v.optLong("bandwidth") > cur.optLong("bandwidth"))) {
                    byHeight[h] = v
                }
            }
            for ((h, v) in byHeight) {
                val u = urlsOf(v)
                if (u.isNotEmpty()) streams.add(Stream(h, u, audioUrls))
            }
        }
        if (streams.isEmpty() && fallbackUrl != null) {
            val h = qnToHeight(html5Data?.optInt("quality") ?: 0)
            streams.add(Stream(h, listOf(fallbackUrl), null))
        }
        if (streams.isEmpty()) {
            throw ExtractError(Kind.BLOCKED, "B 站没有返回任何视频流（可能被风控，或该视频需要登录）")
        }
        log("→ 解析到画质：" + streams.map { it.height }.sortedDescending().joinToString("/") +
            if (fallbackUrl != null) "（含 mp4 兜底）" else "")

        val canonical = "https://www.bilibili.com/video/$bid" + if (p > 1) "?p=$p" else ""
        return VideoMeta(
            url = canonical, title = title, thumbnail = thumb, durationSec = dur,
            heights = streams.map { it.height }.filter { it > 0 }.distinct().sortedDescending().take(6),
            subLangs = emptyList(), streams = streams, fallbackMp4 = fallbackUrl,
            headers = mapOf("Referer" to "https://www.bilibili.com/", "User-Agent" to Http.UA_PC),
        )
    }
}

// ───────────────────────── 抖音 ─────────────────────────

private object Douyin {
    private fun idOf(u: String): String? =
        Regex("""/video/(\d{8,})""").find(u)?.groupValues?.get(1)
            ?: Regex("""[?&](?:modal_id|aweme_id)=(\d{8,})""").find(u)?.groupValues?.get(1)

    private fun logFilter(res: JSONObject?, log: (String) -> Unit) {
        val f = res?.optJSONArray("filter_list")?.optJSONObject(0) ?: return
        log("→ 平台返回过滤原因：${f.optString("filter_reason")} ${f.optString("detail_msg")} ${f.optString("notice")}".trim())
    }

    private fun itemFrom(json: String, log: (String) -> Unit): JSONObject? {
        val root = runCatching { JSONObject(json) }.getOrNull()
        if (root == null) { log("→ _ROUTER_DATA 不是合法 JSON（${json.length} 字符）"); return null }
        val ld = root.optJSONObject("loaderData")
        if (ld != null) {
            log("→ loaderData：" + ld.keys().asSequence().joinToString(",").take(120))
            for (k in ld.keys()) {
                val node = ld.optJSONObject(k)
                val res = node?.optJSONObject("videoInfoRes")
                if (res == null) {
                    if (k != "video_layout") log("→ $k 内容：" + node.toString().take(300))
                    continue
                }
                val list = res.optJSONArray("item_list")
                if (list != null && list.length() > 0) return list.optJSONObject(0)
                log("→ $k 的 item_list 为空")
                logFilter(res, log)
            }
        } else {
            log("→ 没有 loaderData，顶层键：" + root.keys().asSequence().joinToString(",").take(120))
        }
        return findObj(root) { it.optJSONObject("video")?.has("play_addr") == true }
    }

    private fun build(
        page: String, title: String, cover: String?, rawUrls: List<String>, uri: String,
        w: Int, h: Int, dur: Long, log: (String) -> Unit,
    ): VideoMeta {
        val urls = ArrayList<String>()
        // 无水印 + 1080p 的常用地址放最前，失败会自动换后面的
        if (uri.isNotBlank() && !uri.startsWith("http")) {
            urls.add("https://aweme.snssdk.com/aweme/v1/play/?video_id=$uri&ratio=1080p&line=0")
        }
        urls.addAll(rawUrls.map { it.replace("/playwm/", "/play/") })
        if (urls.isEmpty()) throw ExtractError(Kind.OTHER, "抖音数据里没有播放地址")
        val short = if (w > 0 && h > 0) minOf(w, h) else 0
        log("→ 抖音解析成功：${urls.size} 个候选地址，${short}p")
        return VideoMeta(
            url = page, title = title.ifBlank { "抖音视频" }, thumbnail = cover, durationSec = dur,
            heights = if (short > 0) listOf(short) else emptyList(), subLangs = emptyList(),
            streams = listOf(Stream(short, urls.distinct(), null)),
            headers = mapOf("User-Agent" to Http.UA_MOBILE, "Referer" to "https://www.douyin.com/"),
        )
    }

    private fun fromItem(page: String, item: JSONObject, log: (String) -> Unit): VideoMeta {
        if ((item.optJSONArray("images")?.length() ?: 0) > 0) {
            throw ExtractError(Kind.UNSUPPORTED, "这是图文作品，暂不支持（只支持视频）")
        }
        val video = item.optJSONObject("video") ?: throw ExtractError(Kind.OTHER, "抖音数据里没有 video 字段")
        val play = video.optJSONObject("play_addr")
        val cover = (video.optJSONObject("cover") ?: video.optJSONObject("origin_cover"))
            ?.optJSONArray("url_list").strings().firstOrNull()
        val dur = video.optLong("duration").let { d -> if (d > 1000) d / 1000 else d }
        return build(
            page, item.optString("desc"), cover, play?.optJSONArray("url_list").strings(),
            play?.optString("uri").orEmpty(), video.optInt("width"), video.optInt("height"), dur, log,
        )
    }

    /** 最后的兜底：直接在页面文本里找 aweme/v1/play 地址 */
    private fun fromText(page: String, html: String, log: (String) -> Unit): VideoMeta? {
        val t = html.replace("\\u002F", "/").replace("\\/", "/").replace("&amp;", "&")
        val urls = Regex("""https?://[^"'\s<>\\]*aweme/v1/play[^"'\s<>\\]*""").findAll(t).map { it.value }.distinct().toList()
        if (urls.isEmpty()) return null
        log("→ 从页面文本里直接找到 ${urls.size} 个播放地址")
        val desc = Regex(""""desc"\s*:\s*"([^"]*)"""").find(t)?.groupValues?.get(1).orEmpty()
        return build(page, desc, null, urls, "", 0, 0, 0, log)
    }

    private fun fix(u: String) = if (u.startsWith("//")) "https:$u" else u

    /** 网页版（www.douyin.com）WebView 取到的结果：<video> 地址，或 RENDER_DATA 里的视频详情 */
    private fun webResult(page: String, got: String, log: (String) -> Unit): VideoMeta? {
        val root = runCatching { JSONObject(got) }.getOrNull() ?: return null
        val vs = root.optString("videoSrc")
        if (vs.startsWith("http")) {
            val cover = root.optString("poster").takeIf { it.startsWith("http") }
            return build(page, root.optString("title").removeSuffix(" - 抖音"), cover, listOf(vs), "", 0, 0, 0, log)
        }
        val o = findObj(root) {
            val v = it.optJSONObject("video")
            v != null && (v.has("playAddr") || v.has("play_addr"))
        } ?: return null
        val v = o.getJSONObject("video")
        val pa = v.optJSONArray("playAddr")
        val urls = ArrayList<String>()
        if (pa != null) for (i in 0 until pa.length()) {
            pa.optJSONObject(i)?.optString("src")?.takeIf { it.isNotBlank() }?.let { urls.add(fix(it)) }
        }
        v.optJSONObject("play_addr")?.optJSONArray("url_list").strings().forEach { urls.add(it) }
        val cover = (v.optString("cover").takeIf { it.isNotBlank() }
            ?: v.optJSONObject("cover")?.optJSONArray("url_list").strings().firstOrNull())?.let { fix(it) }
        val dur = v.optLong("duration").let { d -> if (d > 1000) d / 1000 else d }
        return build(page, o.optString("desc"), cover, urls.filter { it.startsWith("http") }, "", v.optInt("width"), v.optInt("height"), dur, log)
    }

    suspend fun resolve(ctx: Context, url: String, log: (String) -> Unit): VideoMeta {
        val s = HttpSession()
        val mobile = mapOf("User-Agent" to Http.UA_MOBILE)
        var id = idOf(url)
        if (id == null) {
            val r = Http.get(s, url, mobile)
            log("→ 短链已展开：${hostOf(url)} → ${hostOf(r.finalUrl)}")
            id = idOf(r.finalUrl)
            if (id == null) {
                throw ExtractError(Kind.UNSUPPORTED, "没能从抖音短链里找到视频编号（最终地址：${r.finalUrl.take(80)}）。图文/直播链接暂不支持")
            }
        }
        val page = "https://www.iesdouyin.com/share/video/$id/"

        var item: JSONObject? = null
        var text = ""
        val r = runCatching { Http.get(s, page, mobile) }.getOrNull()
        if (r != null) {
            text = r.body
            log("→ 抖音分享页 HTTP ${r.code}，${r.body.length} 字节，标题「${titleTag(r.body).take(30)}」")
            val j = jsonAfter(r.body, "_ROUTER_DATA")
            if (j != null) {
                log("→ 找到 _ROUTER_DATA（${j.length} 字符）")
                item = itemFrom(j, log)
            } else {
                log("→ 页面里没有 _ROUTER_DATA；疑似验证=${looksLikeCaptcha(r.body)}")
            }
        }

        if (item == null) {
            val api = runCatching {
                Http.get(s, "https://www.iesdouyin.com/web/api/v2/aweme/iteminfo/?item_ids=$id", mobile)
            }.getOrNull()
            if (api != null) {
                log("→ iteminfo 接口 HTTP ${api.code}，${api.body.length} 字节")
                val jo = runCatching { JSONObject(api.body) }.getOrNull()
                val list = jo?.optJSONArray("item_list")
                if (list != null && list.length() > 0) item = list.optJSONObject(0)
                else if (jo != null) { log("→ iteminfo 的 item_list 为空"); logFilter(jo, log) }
            }
        }

        if (item == null) {
            log("→ HTTP 方式没取到数据，改用 WebView 打开")
            val got = WebData.evalJson(ctx, page, Http.UA_MOBILE, "window._ROUTER_DATA")
            log("→ WebView 结果：${got?.let { "${it.length} 字符" } ?: "空（超时或页面没有数据）"}")
            if (got != null) item = itemFrom(got, log)
        }

        if (item == null) {
            log("→ 改用 WebView 打开网页版 www.douyin.com（电脑环境）")
            val js = "(function(){var v=document.querySelector('video');var s=null;" +
                "if(v){s=v.currentSrc||v.src;if(!s){var so=v.querySelector('source');if(so)s=so.src;}}" +
                "if(s&&s.indexOf('http')==0)return {videoSrc:s,title:document.title,poster:v.poster};" +
                "var r=document.getElementById('RENDER_DATA');" +
                "if(r){try{return JSON.parse(decodeURIComponent(r.textContent))}catch(e){}}" +
                "return null})()"
            val webPage = "https://www.douyin.com/video/$id"
            val got = WebData.evalJson(ctx, webPage, Http.UA_PC, js, 35_000L)
            log("→ 网页版结果：${got?.let { "${it.length} 字符：" + it.take(100) } ?: "空（超时，或需要验证码/登录）"}")
            if (got != null) webResult(page, got, log)?.let { return it }
        }

        val found = item
        if (found != null) return fromItem(page, found, log)
        fromText(page, text, log)?.let { return it }
        throw ExtractError(Kind.BLOCKED, "没有取到抖音视频数据（可能被平台验证拦截、已删除，或是图文）。请把日志发给开发者")
    }
}

// ───────────────────────── 快手 ─────────────────────────

private object Kuaishou {
    private val MARKERS = listOf("INIT_STATE", "pageData", "__INITIAL_STATE__", "__APOLLO_STATE__", "rawData", "__NEXT_DATA__")

    private fun hasVideoKey(o: JSONObject) =
        o.has("photoUrl") || o.has("mainMcUrl") || o.has("srcNoMark") || o.has("photoH265Url") ||
            (o.optString("url").contains(".mp4") && (o.has("poster") || o.has("caption")))

    /** 从任意 JSON 里找视频对象，返回 (标题, 视频地址列表, 封面, 宽, 高, 时长秒) */
    private class Found(val title: String, val urls: List<String>, val cover: String?, val w: Int, val h: Int, val dur: Long)

    private fun fromJson(json: String): Found? {
        val root = runCatching { JSONObject(json) }.getOrNull() ?: return null
        // WebView 兜底直接给出的 <video> 地址
        if (root.optString("videoSrc").startsWith("http")) {
            return Found(
                root.optString("title").ifBlank { "快手视频" }, listOf(root.optString("videoSrc")),
                root.optString("poster").takeIf { it.startsWith("http") }, 0, 0, 0,
            )
        }
        val v = findObj(root) { hasVideoKey(it) } ?: return null
        val urls = listOf("srcNoMark", "mainMcUrl", "photoUrl", "url")
            .mapNotNull { k -> v.optString(k).takeIf { u -> u.startsWith("http") } }.distinct()
        if (urls.isEmpty()) return null
        val caption = v.optString("caption").ifBlank { findObj(root) { it.has("caption") }?.optString("caption").orEmpty() }
        val cover = v.optJSONArray("coverUrls")?.optJSONObject(0)?.optString("url")?.takeIf { it.startsWith("http") }
            ?: listOf("coverUrl", "webpCoverUrl", "poster").map { k -> v.optString(k) }.firstOrNull { it.startsWith("http") }
        val dur = v.optLong("duration").let { d -> if (d > 1000) d / 1000 else d }
        return Found(caption.ifBlank { "快手视频" }, urls, cover, v.optInt("width"), v.optInt("height"), dur)
    }

    /** 最后的兜底：直接在页面文本里找 .mp4 地址 */
    private fun fromText(html: String): Found? {
        val t = html.replace("\\u002F", "/").replace("\\/", "/").replace("&amp;", "&")
        val urls = Regex("""https?://[^"'\s<>\\]+?\.mp4[^"'\s<>\\]*""").findAll(t).map { it.value }.distinct().toList()
        if (urls.isEmpty()) return null
        val cover = Regex("""<meta[^>]+og:image[^>]*content=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
            .find(t)?.groupValues?.get(1)
        return Found(titleTag(t).ifBlank { "快手视频" }.takeIf { it != "快手" } ?: "快手视频", urls, cover, 0, 0, 0)
    }

    private fun parseHtml(html: String): Found? {
        for (m in MARKERS) {
            jsonAfter(html, m)?.let { j -> fromJson(j)?.let { return it } }
        }
        return fromText(html)
    }

    suspend fun resolve(ctx: Context, url: String, log: (String) -> Unit): VideoMeta {
        val s = HttpSession()
        val mobile = mapOf("User-Agent" to Http.UA_MOBILE)
        val r = Http.get(s, url, mobile)
        log("→ 快手页面 HTTP ${r.code}，${hostOf(url)} → ${hostOf(r.finalUrl)}，${r.body.length} 字节，标题「${titleTag(r.body).take(30)}」")
        val names = Regex("""window\.([A-Za-z_$][\w$]*)\s*=""").findAll(r.body).map { it.groupValues[1] }.distinct().take(12).toList()
        log("→ 页面脚本变量：${names.joinToString(",").ifEmpty { "无" }}；含.mp4=${r.body.contains(".mp4")}；疑似验证=${looksLikeCaptcha(r.body)}")

        var f = parseHtml(r.body)
        if (f == null) {
            log("→ HTTP 方式没取到数据，改用 WebView 打开并等待视频加载")
            val js = "(function(){var v=document.querySelector('video');var s=v&&(v.currentSrc||v.src);" +
                "if(s&&s.indexOf('http')==0)return {videoSrc:s,title:document.title,poster:v.poster};" +
                "return window.INIT_STATE||window.pageData||window.__INITIAL_STATE__||window.rawData||null})()"
            val got = WebData.evalJson(ctx, r.finalUrl, Http.UA_MOBILE, js, 25_000L)
            log("→ WebView 结果：${got?.take(120) ?: "空（超时或页面没有视频）"}")
            if (got != null) f = fromJson(got)
        }
        val v = f ?: throw ExtractError(Kind.BLOCKED, "没有取到快手视频数据（可能被平台验证拦截，或是图文/已删除内容）")
        val short = if (v.w > 0 && v.h > 0) minOf(v.w, v.h) else 0
        log("→ 快手解析成功：${v.urls.size} 个候选地址")
        return VideoMeta(
            url = r.finalUrl, title = v.title, thumbnail = v.cover, durationSec = v.dur,
            heights = if (short > 0) listOf(short) else emptyList(), subLangs = emptyList(),
            streams = listOf(Stream(short, v.urls, null)),
            headers = mapOf("User-Agent" to Http.UA_MOBILE, "Referer" to "https://www.kuaishou.com/"),
        )
    }
}

// ───────────────────────── 其他网站：读 og:video ─────────────────────────

private object Generic {
    private fun meta(html: String, name: String): String? {
        val n = Regex.escape(name)
        val a = Regex("""<meta[^>]+(?:property|name)=["']$n["'][^>]*content=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
        val b = Regex("""<meta[^>]+content=["']([^"']+)["'][^>]*(?:property|name)=["']$n["']""", RegexOption.IGNORE_CASE)
        return (a.find(html) ?: b.find(html))?.groupValues?.get(1)?.replace("&amp;", "&")
    }

    fun resolve(url: String, log: (String) -> Unit): VideoMeta {
        val direct = Regex("""\.(mp4|m4v|mov|webm|m4a|mp3)(\?|$)""", RegexOption.IGNORE_CASE).containsMatchIn(url.substringBefore('#'))
        if (direct) {
            return VideoMeta(url, url.substringBefore('?').substringAfterLast('/').ifBlank { "video" }, null, 0, emptyList(), emptyList(),
                streams = listOf(Stream(0, listOf(url), null)))
        }
        val r = Http.get(null, url, mapOf("User-Agent" to Http.UA_PC))
        log("→ 通用解析：HTTP ${r.code}，${r.body.length} 字节")
        val v = listOf("og:video:secure_url", "og:video:url", "og:video", "twitter:player:stream")
            .firstNotNullOfOrNull { meta(r.body, it) }?.takeIf { it.startsWith("http") }
            ?: throw ExtractError(Kind.UNSUPPORTED, "暂不支持这个网站")
        return VideoMeta(
            url = url, title = (meta(r.body, "og:title") ?: titleTag(r.body)).ifBlank { "video" },
            thumbnail = meta(r.body, "og:image")?.takeIf { it.startsWith("http") }, durationSec = 0,
            heights = emptyList(), subLangs = emptyList(), streams = listOf(Stream(0, listOf(v), null)),
            headers = mapOf("Referer" to url),
        )
    }
}
