package com.grwtomb.extractor

import android.app.Application
import android.content.Context
import android.util.Log
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.coroutines.cancellation.CancellationException

/**
 * 解析引擎（yt-dlp）。接口失效全自动处理：
 *  1. 启动时静默更新引擎（6 小时一次）
 *  2. 解析/下载失败时自动：更新 stable 重试 → 更新 nightly 重试
 * 用户全程无感，只会看到"正在解析…"。
 */
object Engine {
    private const val TAG = "Engine"
    private const val AUTO_GAP = 6 * 3600_000L   // 启动自动更新间隔
    private const val RETRY_GAP = 20 * 60_000L   // 失败触发的更新，同一通道 20 分钟内不重复

    private val ready = CompletableDeferred<Boolean>()
    private val lock = Mutex()

    fun init(app: Application, scope: CoroutineScope) {
        scope.launch {
            val ok = try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                true
            } catch (t: Throwable) {
                Log.e(TAG, "init failed", t)
                false
            }
            ready.complete(ok)
        }
    }

    suspend fun awaitReady(): Boolean = ready.await()

    /** 更新 yt-dlp 本体；minGapMs 内更新过则跳过 */
    private suspend fun update(ctx: Context, nightly: Boolean, minGapMs: Long): Boolean =
        withContext(Dispatchers.IO) {
            if (!awaitReady()) return@withContext false
            lock.withLock {
                val prefs = ctx.getSharedPreferences("engine", Context.MODE_PRIVATE)
                val key = if (nightly) "last_nightly" else "last_stable"
                if (System.currentTimeMillis() - prefs.getLong(key, 0) < minGapMs) {
                    return@withLock false
                }
                try {
                    YoutubeDL.getInstance().updateYoutubeDL(
                        ctx,
                        if (nightly) YoutubeDL.UpdateChannel.NIGHTLY else YoutubeDL.UpdateChannel.STABLE,
                    )
                    prefs.edit().putLong(key, System.currentTimeMillis()).apply()
                    true
                } catch (t: Throwable) {
                    Log.w(TAG, "update failed", t)
                    false
                }
            }
        }

    /** App 启动时调用 */
    suspend fun autoUpdate(ctx: Context) = update(ctx, nightly = false, minGapMs = AUTO_GAP)

    /** 失败后重试前调用 */
    suspend fun retryUpdate(ctx: Context, nightly: Boolean) = update(ctx, nightly, RETRY_GAP)

    /**
     * 失败后的自动重试序列（解析和下载共用）：
     * 先直接执行；失败 → 更新 stable 再试；仍失败 → 更新 nightly 再试。
     * 明确的网络故障、登录要求、已删除内容和不支持链接会立刻返回。
     * “fresh cookies”等泛化 Cookie 提示不等于用户必须登录，先尝试更新引擎并重试。
     */
    suspend fun <T> withAutoFix(ctx: Context, log: (String) -> Unit, block: () -> T): T {
        if (!awaitReady()) throw ExtractError(Kind.ENGINE, "engine not ready")
        val preps = listOf<suspend () -> Unit>(
            { },
            { log("→ 更新引擎(stable)后重试"); retryUpdate(ctx, false) },
            { log("→ 更新引擎(nightly)后重试"); retryUpdate(ctx, true) },
        )
        var last: Throwable? = null
        for (prep in preps) {
            try {
                prep()
                return withContext(Dispatchers.IO) { block() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                log("✗ ${e.message?.take(300)}")
                last = e
                when (classify(e)) {
                    Kind.NETWORK, Kind.LOGIN, Kind.REMOVED, Kind.UNSUPPORTED -> throw e
                    else -> {}
                }
            }
        }
        throw last ?: ExtractError(Kind.OTHER, "unknown")
    }

    suspend fun resolve(ctx: Context, url: String, log: (String) -> Unit): VideoMeta {
        // 先由本应用 WebView 打开用户粘贴的原始链接；抖音 v.douyin.com 短链会在这里跟随跳转。
        // 使用跳转后的页面地址解析，避免把短链域名直接交给 yt-dlp。
        val session = CookieBridge.obtain(ctx, url)
        val resolvedUrl = session.resolvedUrl.ifBlank { url }
        val targetUrl = normalizeVideoUrl(resolvedUrl)
        if (resolvedUrl != url) {
            log("→ 分享链接已展开：${hostOf(url)} → ${hostOf(resolvedUrl)}")
        }
        if (targetUrl != resolvedUrl) {
            log("→ 已将抖音分享页转换为标准视频地址")
        }
        if (hostOf(targetUrl) == "v.douyin.com") {
            session.close()
            throw ExtractError(Kind.UNSUPPORTED, "抖音短链接未能展开，请稍后重试")
        }
        log(if (session.cookieCount > 0) "→ 网页会话已准备：${session.cookieCount} 条 Cookie" else "→ 未获取到网页 Cookie，继续尝试公开链接解析")
        return try {
            withAutoFix(ctx, log) {
                val req = YoutubeDLRequest(targetUrl)
                session.applyTo(req)
                req.addOption("--dump-single-json")
                req.addOption("--no-playlist")
                req.addOption("--no-warnings")
                req.addOption("--socket-timeout", "20")
                req.addOption("--retries", "2")
                parseInfo(targetUrl, YoutubeDL.getInstance().execute(req).out)
            }
        } finally {
            session.close()
        }
    }

    private fun langRank(l: String) = when {
        l.startsWith("zh") -> 0
        l.startsWith("en") -> 1
        else -> 2
    }

    private fun parseInfo(url: String, raw: String): VideoMeta {
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s < 0 || e <= s) throw ExtractError(Kind.OTHER, "引擎返回的内容无法解析")
        val j0 = JSONObject(raw.substring(s, e + 1))
        val j = if (j0.optString("_type") == "playlist") {
            j0.optJSONArray("entries")?.optJSONObject(0) ?: j0
        } else j0

        val title = j.optString("title").ifBlank { "video" }
        val thumb = j.optString("thumbnail").takeIf { it.isNotBlank() && it != "null" }
        val dur = j.optDouble("duration", 0.0).let { if (it.isNaN()) 0L else it.toLong() }

        val hs = sortedSetOf<Int>()
        j.optJSONArray("formats")?.let { arr ->
            for (i in 0 until arr.length()) {
                val f = arr.optJSONObject(i) ?: continue
                val h = f.optInt("height", 0)
                if (h >= 144 && f.optString("vcodec", "x") != "none") hs.add(h)
            }
        }
        val heights = hs.toList().sortedDescending().take(6)

        fun keys(o: JSONObject?): List<String> = o?.keys()?.asSequence()?.toList().orEmpty()
        val prefer = listOf("zh", "en", "ja", "ko", "es", "fr", "de", "ru", "pt", "ar")
        val manual = keys(j.optJSONObject("subtitles")).filter { it != "live_chat" }
        val auto = keys(j.optJSONObject("automatic_captions"))
            .filter { l -> prefer.any { l == it || l.startsWith("$it-") } }
        val langs = (manual + auto).distinct()
            .sortedWith(compareBy({ langRank(it) }, { it }))
            .take(8)

        return VideoMeta(url, title, thumb, dur, heights, langs)
    }
}
