# GRWTomb 视频提取

粘贴链接 → 自动解析 → 选画质 / 封面 / 字幕 → 保存到相册。制作者：GRWTomb

## 怎么运行
1. 安装 Android Studio（Koala 或更新），用它直接打开本文件夹，等待 Gradle 同步完成。
2. 手机开启 USB 调试后点 Run；或菜单 Build → Build APK(s) 生成安装包。
3. 通用安装包在 `app/build/outputs/apk/` 下，文件名带 `universal`。

## 接口失效怎么自动处理（无需任何手动操作）
- **自动更新引擎**：每次启动在后台静默更新 yt-dlp（6 小时一次）。
- **失败自动切换**：解析或下载失败时，自动「更新 stable 引擎 → 重试 → 更新 nightly 引擎 → 再重试」。
- 网络断开、视频已删除、需要登录这类换方案也没用的错误，会立刻给出明确提示，不白等。

## 自动使用
- 回到 App 时，剪贴板里有新链接会自动填入并解析。
- 在其他 App 点「分享 → GRWTomb」直接解析。
- 支持粘贴带文字的分享口令，会自动抽出其中的链接。

## 保存位置
视频在 `影片/GRWTomb`，音频在 `音乐/GRWTomb`，封面在 `图片/GRWTomb`，字幕(.srt)在 `下载/GRWTomb`。

## 已知限制（请先看）
- 代码在没有 Android SDK 的环境里写成，**还没有编译过**。第一次同步可能有小的报错，通常是库的类名或参数细节，把报错信息发给我就能修。
- 引擎更新需要访问 GitHub。网络访问不了 GitHub 时更新会失败，下次启动或下次失败时再试。
- 抖音、小红书等反爬很强的平台，要等 yt-dlp 社区修复，通常几天内。
- 最低支持 Android 10（API 29）。
- 请只下载自己有权保存的内容，并遵守各平台条款。这类 App 不适合上架 Google Play，建议用 APK 分发。

### 网页会话 / Cookie 处理
- 解析和下载共用同一套 WebView 会话获取逻辑。
- 页面完成后额外等待脚本执行，再读取 Cookie；同时记录重定向页面及 WebView 实际访问到的 HTTPS 子资源/API/子域主机（最多 80 个请求地址）。
- Cookie 以临时 Netscape cookie jar 传给 yt-dlp，按主机隔离；不再把一个 Cookie 请求头全局附加到所有下载域名。
- 同步使用 WebView User-Agent 和清理查询参数后的 Referer；临时 Cookie 文件在解析/下载结束后删除。
- Android CookieManager 不公开 Cookie 原始 Domain、Path、过期时间等完整元数据，因此该机制只能传递 WebView 可见的 Cookie，不能保证生成平台要求的签名/验证状态，也不会绕过登录或平台验证。
