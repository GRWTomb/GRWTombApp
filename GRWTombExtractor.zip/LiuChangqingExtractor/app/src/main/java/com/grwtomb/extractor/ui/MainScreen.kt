package com.grwtomb.extractor.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.grwtomb.extractor.Downloader
import com.grwtomb.extractor.MainViewModel
import com.grwtomb.extractor.Phase
import com.grwtomb.extractor.UiState
import com.grwtomb.extractor.VideoMeta
import com.grwtomb.extractor.formatDuration
import com.grwtomb.extractor.qualityLabel

@Composable
fun MainScreen(vm: MainViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current

    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
        ) {
            Spacer(Modifier.height(36.dp))
            Text(
                "刘长卿",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 2.sp,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "粘贴链接，自动提取",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(24.dp))

            OutlinedTextField(
                value = s.input,
                onValueChange = vm::onInput,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("粘贴视频链接") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                trailingIcon = {
                    TextButton(onClick = {
                        if (s.input.isEmpty()) {
                            clipboard.getText()?.text?.let(vm::onPaste)
                        } else {
                            vm.onInput("")
                        }
                    }) { Text(if (s.input.isEmpty()) "粘贴" else "清除") }
                },
            )
            Spacer(Modifier.height(16.dp))

            // 解析中
            AnimatedVisibility(
                visible = s.phase == Phase.Parsing,
                enter = fadeIn(tween(250)),
                exit = fadeOut(tween(150)),
            ) {
                Column {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)),
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "正在解析…",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }

            // 解析失败
            AnimatedVisibility(
                visible = s.phase == Phase.Error,
                enter = fadeIn(tween(250)) + slideInVertically(tween(250)) { it / 8 },
                exit = fadeOut(tween(150)),
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(16.dp),
                ) {
                    Text(s.error.orEmpty(), color = MaterialTheme.colorScheme.error)
                    if (s.log.isNotBlank()) {
                        TextButton(onClick = { clipboard.setText(AnnotatedString(s.log)) }) {
                            Text("复制日志")
                        }
                    }
                }
            }

            // 结果卡片
            AnimatedVisibility(
                visible = s.meta != null &&
                    (s.phase == Phase.Ready || s.phase == Phase.Downloading || s.phase == Phase.Done),
                enter = fadeIn(tween(280)) + slideInVertically(tween(280)) { it / 8 },
                exit = fadeOut(tween(150)),
            ) {
                s.meta?.let { ResultCard(it, s, vm) }
            }

            Spacer(Modifier.height(48.dp))
            Text(
                "制作者 刘长卿",
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            Spacer(Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ResultCard(meta: VideoMeta, s: UiState, vm: MainViewModel) {
    val locked = s.phase != Phase.Ready
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (meta.thumbnail != null) {
            Box(Modifier.clip(RoundedCornerShape(14.dp))) {
                AsyncImage(
                    model = meta.thumbnail,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant),
                )
                val d = formatDuration(meta.durationSec)
                if (d.isNotEmpty()) {
                    Text(
                        d,
                        color = Color.White,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(alpha = 0.6f))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                }
            }
        }
        Text(
            meta.title,
            maxLines = 2,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )

        // 提取内容：视频 / 封面 / 字幕
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = s.video, enabled = !locked, onClick = { vm.setVideo(!s.video) },
                label = { Text("视频") })
            FilterChip(selected = s.cover, enabled = !locked, onClick = { vm.setCover(!s.cover) },
                label = { Text("封面") })
            FilterChip(
                selected = s.subs,
                enabled = !locked && meta.subLangs.isNotEmpty(),
                onClick = { vm.setSubs(!s.subs) },
                label = { Text(if (meta.subLangs.isEmpty()) "字幕（无）" else "字幕") },
            )
        }

        // 画质
        AnimatedVisibility(visible = s.video) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                FilterChip(selected = s.quality == Downloader.AUTO, enabled = !locked,
                    onClick = { vm.setQuality(Downloader.AUTO) }, label = { Text("自动") })
                meta.heights.forEach { h ->
                    FilterChip(selected = s.quality == h, enabled = !locked,
                        onClick = { vm.setQuality(h) }, label = { Text(qualityLabel(h)) })
                }
                FilterChip(selected = s.quality == Downloader.AUDIO, enabled = !locked,
                    onClick = { vm.setQuality(Downloader.AUDIO) }, label = { Text("仅音频") })
            }
        }

        // 字幕语言
        AnimatedVisibility(visible = s.subs && meta.subLangs.isNotEmpty()) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                meta.subLangs.forEach { l ->
                    FilterChip(selected = s.subLang == l, enabled = !locked,
                        onClick = { vm.setSubLang(l) }, label = { Text(l) })
                }
            }
        }

        s.error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
        if (s.error != null && s.log.isNotBlank()) {
            val clipboard = LocalClipboardManager.current
            TextButton(onClick = { clipboard.setText(AnnotatedString(s.log)) }) { Text("复制日志") }
        }

        DownloadButton(
            phase = s.phase,
            progress = s.progress,
            canStart = s.video || s.cover || (s.subs && s.subLang != null),
            onClick = vm::download,
        )

        if (s.phase == Phase.Done) {
            Text(
                "已保存到 影片 / 图片 / 下载 里的 刘长卿 文件夹",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp,
            )
        }
    }
}

@Composable
private fun DownloadButton(
    phase: Phase,
    progress: Float,
    canStart: Boolean,
    onClick: () -> Unit,
) {
    val done = phase == Phase.Done
    val scale by animateFloatAsState(
        targetValue = if (done) 1.03f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = 300f),
        label = "bounce",
    )
    Button(
        onClick = { if (phase == Phase.Ready) onClick() },
        enabled = phase != Phase.Ready || canStart,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .scale(scale),
    ) {
        AnimatedContent(targetState = phase, label = "btn") { p ->
            when (p) {
                Phase.Downloading -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.5.dp,
                        color = LocalContentColor.current,
                        trackColor = LocalContentColor.current.copy(alpha = 0.25f),
                    )
                    Spacer(Modifier.size(10.dp))
                    Text("${(progress * 100).toInt()}%")
                }
                Phase.Done -> Text("已保存 ✓")
                else -> Text("下载")
            }
        }
    }
}
